import * as THREE from 'three';
import { BlockType, RaycastHit } from '../types';
import { VoxelWorld } from './world';

/**
 * High-performance Fast Voxel Traversal Algorithm (Amanatides & Woo DDA).
 * Operates directly on the discrete 3D voxel grid in O(steps) integer math,
 * executing in under 1 microsecond without testing complex 3D meshes or instance matrices.
 */
export function fastVoxelRaycast(
  world: VoxelWorld,
  origin: THREE.Vector3,
  direction: THREE.Vector3,
  maxDistance: number = 5.2
): RaycastHit | null {
  let x = Math.floor(origin.x);
  let y = Math.floor(origin.y);
  let z = Math.floor(origin.z);

  const stepX = Math.sign(direction.x);
  const stepY = Math.sign(direction.y);
  const stepZ = Math.sign(direction.z);

  const dx = direction.x;
  const dy = direction.y;
  const dz = direction.z;

  const tDeltaX = stepX !== 0 ? Math.abs(1 / dx) : Infinity;
  const tDeltaY = stepY !== 0 ? Math.abs(1 / dy) : Infinity;
  const tDeltaZ = stepZ !== 0 ? Math.abs(1 / dz) : Infinity;

  let tMaxX = stepX === 0 ? Infinity : stepX > 0 ? (x + 1 - origin.x) * tDeltaX : (origin.x - x) * tDeltaX;
  let tMaxY = stepY === 0 ? Infinity : stepY > 0 ? (y + 1 - origin.y) * tDeltaY : (origin.y - y) * tDeltaY;
  let tMaxZ = stepZ === 0 ? Infinity : stepZ > 0 ? (z + 1 - origin.z) * tDeltaZ : (origin.z - z) * tDeltaZ;

  // Guard against any 0 * Infinity = NaN edge cases
  if (Number.isNaN(tMaxX)) tMaxX = Infinity;
  if (Number.isNaN(tMaxY)) tMaxY = Infinity;
  if (Number.isNaN(tMaxZ)) tMaxZ = Infinity;

  let normalX = 0;
  let normalY = 0;
  let normalZ = 0;
  let distance = 0;

  while (distance <= maxDistance) {
    if (tMaxX < tMaxY) {
      if (tMaxX < tMaxZ) {
        x += stepX;
        distance = tMaxX;
        tMaxX += tDeltaX;
        normalX = -stepX;
        normalY = 0;
        normalZ = 0;
      } else {
        z += stepZ;
        distance = tMaxZ;
        tMaxZ += tDeltaZ;
        normalX = 0;
        normalY = 0;
        normalZ = -stepZ;
      }
    } else {
      if (tMaxY < tMaxZ) {
        y += stepY;
        distance = tMaxY;
        tMaxY += tDeltaY;
        normalX = 0;
        normalY = -stepY;
        normalZ = 0;
      } else {
        z += stepZ;
        distance = tMaxZ;
        tMaxZ += tDeltaZ;
        normalX = 0;
        normalY = 0;
        normalZ = -stepZ;
      }
    }

    if (distance > maxDistance) break;

    const blockType = world.getBlock(x, y, z);
    if (blockType !== BlockType.AIR && blockType !== BlockType.WATER) {
      return {
        blockPos: [x, y, z],
        normal: [normalX, normalY, normalZ],
        hitPos: [
          origin.x + direction.x * distance,
          origin.y + direction.y * distance,
          origin.z + direction.z * distance,
        ],
        blockType,
        distance,
      };
    }
  }

  return null;
}
