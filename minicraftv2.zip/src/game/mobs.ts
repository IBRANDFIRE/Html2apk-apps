import * as THREE from 'three';
import { BlockType } from '../types';
import { BLOCK_REGISTRY } from './blocks';
import { soundManager } from './audio';
import { VoxelWorld } from './world';

export type MobType = 'cow' | 'pig' | 'sheep' | 'chicken';

export interface MobDrop {
  blockType: BlockType;
  min: number;
  max: number;
}

export interface MobConfig {
  type: MobType;
  name: string;
  maxHealth: number;
  walkSpeed: number;
  width: number;
  height: number;
  depth: number;
  drops: MobDrop[];
}

export const MOB_CONFIGS: Record<MobType, MobConfig> = {
  cow: {
    type: 'cow',
    name: 'Cow',
    maxHealth: 10,
    walkSpeed: 1.4,
    width: 0.9,
    height: 1.3,
    depth: 1.4,
    drops: [
      { blockType: BlockType.RAW_BEEF, min: 1, max: 3 },
      { blockType: BlockType.LEATHER, min: 0, max: 2 },
    ],
  },
  pig: {
    type: 'pig',
    name: 'Pig',
    maxHealth: 10,
    walkSpeed: 1.5,
    width: 0.85,
    height: 0.9,
    depth: 1.2,
    drops: [{ blockType: BlockType.RAW_PORKCHOP, min: 1, max: 3 }],
  },
  sheep: {
    type: 'sheep',
    name: 'Sheep',
    maxHealth: 8,
    walkSpeed: 1.4,
    width: 0.9,
    height: 1.2,
    depth: 1.3,
    drops: [
      { blockType: BlockType.WHITE_WOOL, min: 1, max: 2 },
      { blockType: BlockType.RAW_BEEF, min: 1, max: 2 },
    ],
  },
  chicken: {
    type: 'chicken',
    name: 'Chicken',
    maxHealth: 4,
    walkSpeed: 1.8,
    width: 0.5,
    height: 0.7,
    depth: 0.5,
    drops: [
      { blockType: BlockType.RAW_CHICKEN, min: 1, max: 1 },
      { blockType: BlockType.FEATHER, min: 1, max: 2 },
    ],
  },
};

export interface DroppedItemEntity {
  id: string;
  blockType: BlockType;
  x: number;
  y: number;
  z: number;
  vy: number;
  mesh: THREE.Mesh;
  createdAt: number;
}

export class Mob {
  public id: string;
  public type: MobType;
  public x: number;
  public y: number;
  public z: number;
  public vx: number = 0;
  public vy: number = 0;
  public vz: number = 0;
  public yaw: number = 0; // facing direction in radians
  public health: number;
  public maxHealth: number;

  public isGrounded: boolean = false;
  public state: 'idle' | 'walking' = 'idle';
  public stateTimer: number = 0;
  public soundTimer: number = 0;
  public hurtTimer: number = 0;
  public walkAnimTime: number = 0;

  public group: THREE.Group;
  public legs: THREE.Mesh[] = [];
  public head?: THREE.Mesh;
  public originalMaterials: THREE.Material[] = [];

  constructor(type: MobType, x: number, y: number, z: number) {
    this.id = Math.random().toString(36).substring(2, 9);
    this.type = type;
    this.x = x;
    this.y = y;
    this.z = z;

    const config = MOB_CONFIGS[type];
    this.health = config.maxHealth;
    this.maxHealth = config.maxHealth;
    this.yaw = Math.random() * Math.PI * 2;
    this.stateTimer = Math.random() * 3 + 1;
    this.soundTimer = Math.random() * 10 + 5;

    this.group = this.createMobMesh(type);
    this.group.position.set(x, y, z);
  }

  private createMobMesh(type: MobType): THREE.Group {
    const group = new THREE.Group();

    if (type === 'cow') {
      const bodyMat = new THREE.MeshLambertMaterial({ color: 0x5c3d22 });
      const spotMat = new THREE.MeshLambertMaterial({ color: 0xefefef });
      const legMat = new THREE.MeshLambertMaterial({ color: 0x4a301a });
      const headMat = new THREE.MeshLambertMaterial({ color: 0x5c3d22 });
      const snoutMat = new THREE.MeshLambertMaterial({ color: 0xa68363 });
      const hornMat = new THREE.MeshLambertMaterial({ color: 0xdddddd });

      // Body
      const body = new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.8, 1.2), bodyMat);
      body.position.set(0, 0.7, 0);
      group.add(body);

      // Spots
      const spot1 = new THREE.Mesh(new THREE.BoxGeometry(0.81, 0.35, 0.4), spotMat);
      spot1.position.set(0, 0.7, 0.1);
      group.add(spot1);

      // Head
      const headGroup = new THREE.Group();
      headGroup.position.set(0, 1.1, 0.65);
      const head = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.5, 0.5), headMat);
      headGroup.add(head);

      const snout = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.25, 0.2), snoutMat);
      snout.position.set(0, -0.1, 0.25);
      headGroup.add(snout);

      const hornL = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.2, 0.1), hornMat);
      hornL.position.set(-0.28, 0.3, -0.05);
      const hornR = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.2, 0.1), hornMat);
      hornR.position.set(0.28, 0.3, -0.05);
      headGroup.add(hornL);
      headGroup.add(hornR);
      group.add(headGroup);

      // 4 Legs
      const legPositions = [
        [-0.3, 0.3, 0.4],
        [0.3, 0.3, 0.4],
        [-0.3, 0.3, -0.4],
        [0.3, 0.3, -0.4],
      ];
      legPositions.forEach(([lx, ly, lz]) => {
        const leg = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.6, 0.24), legMat);
        leg.position.set(lx, ly, lz);
        group.add(leg);
        this.legs.push(leg);
      });
    } else if (type === 'pig') {
      const pigMat = new THREE.MeshLambertMaterial({ color: 0xf2a2a2 });
      const snoutMat = new THREE.MeshLambertMaterial({ color: 0xe07b7b });

      // Body
      const body = new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.75, 1.1), pigMat);
      body.position.set(0, 0.6, 0);
      group.add(body);

      // Head
      const headGroup = new THREE.Group();
      headGroup.position.set(0, 0.85, 0.55);
      const head = new THREE.Mesh(new THREE.BoxGeometry(0.48, 0.48, 0.48), pigMat);
      headGroup.add(head);

      const snout = new THREE.Mesh(new THREE.BoxGeometry(0.26, 0.18, 0.15), snoutMat);
      snout.position.set(0, -0.08, 0.26);
      headGroup.add(snout);
      group.add(headGroup);

      // 4 Legs
      const legPositions = [
        [-0.28, 0.25, 0.38],
        [0.28, 0.25, 0.38],
        [-0.28, 0.25, -0.38],
        [0.28, 0.25, -0.38],
      ];
      legPositions.forEach(([lx, ly, lz]) => {
        const leg = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.5, 0.22), pigMat);
        leg.position.set(lx, ly, lz);
        group.add(leg);
        this.legs.push(leg);
      });
    } else if (type === 'sheep') {
      const woolMat = new THREE.MeshLambertMaterial({ color: 0xededed });
      const faceMat = new THREE.MeshLambertMaterial({ color: 0xd1b09b });

      // Wool Body
      const body = new THREE.Mesh(new THREE.BoxGeometry(0.85, 0.85, 1.2), woolMat);
      body.position.set(0, 0.68, 0);
      group.add(body);

      // Head
      const headGroup = new THREE.Group();
      headGroup.position.set(0, 0.95, 0.62);
      const headWool = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.42, 0.35), woolMat);
      headGroup.add(headWool);
      const face = new THREE.Mesh(new THREE.BoxGeometry(0.38, 0.38, 0.2), faceMat);
      face.position.set(0, -0.05, 0.18);
      headGroup.add(face);
      group.add(headGroup);

      // 4 Legs
      const legPositions = [
        [-0.28, 0.25, 0.4],
        [0.28, 0.25, 0.4],
        [-0.28, 0.25, -0.4],
        [0.28, 0.25, -0.4],
      ];
      legPositions.forEach(([lx, ly, lz]) => {
        const leg = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.5, 0.2), faceMat);
        leg.position.set(lx, ly, lz);
        group.add(leg);
        this.legs.push(leg);
      });
    } else {
      // Chicken
      const bodyMat = new THREE.MeshLambertMaterial({ color: 0xffffff });
      const wattleMat = new THREE.MeshLambertMaterial({ color: 0xcc2222 });
      const beakMat = new THREE.MeshLambertMaterial({ color: 0xf0a800 });

      // Body
      const body = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.4, 0.5), bodyMat);
      body.position.set(0, 0.4, 0);
      group.add(body);

      // Head
      const headGroup = new THREE.Group();
      headGroup.position.set(0, 0.65, 0.22);
      const head = new THREE.Mesh(new THREE.BoxGeometry(0.25, 0.3, 0.25), bodyMat);
      headGroup.add(head);

      const beak = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.1, 0.12), beakMat);
      beak.position.set(0, 0, 0.15);
      headGroup.add(beak);

      const wattle = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.12, 0.08), wattleMat);
      wattle.position.set(0, -0.15, 0.12);
      headGroup.add(wattle);
      group.add(headGroup);

      // 2 Legs
      const legL = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.3, 0.08), beakMat);
      legL.position.set(-0.1, 0.15, 0);
      const legR = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.3, 0.08), beakMat);
      legR.position.set(0.1, 0.15, 0);
      group.add(legL);
      group.add(legR);
      this.legs.push(legL, legR);
    }

    // Cache original materials for hurt flash
    group.traverse((child) => {
      if (child instanceof THREE.Mesh) {
        if (Array.isArray(child.material)) {
          this.originalMaterials.push(...child.material);
        } else {
          this.originalMaterials.push(child.material);
        }
      }
    });

    return group;
  }
}

export class MobManager {
  public mobs: Mob[] = [];
  public droppedItems: DroppedItemEntity[] = [];
  private scene: THREE.Scene;
  private world: VoxelWorld;
  private spawnCheckTimer: number = 0;
  private hurtMaterial = new THREE.MeshLambertMaterial({ color: 0xff3333 });
  private maxMobs = 16;

  constructor(scene: THREE.Scene, world: VoxelWorld) {
    this.scene = scene;
    this.world = world;
  }

  public update(
    dt: number,
    playerX: number,
    playerY: number,
    playerZ: number,
    onCollectItem: (blockType: BlockType, count: number) => void
  ) {
    // 1. Spawning / Despawning loop (every 3s)
    this.spawnCheckTimer += dt;
    if (this.spawnCheckTimer >= 3.0) {
      this.spawnCheckTimer = 0;

      // Despawn far mobs (> 90 blocks away or fallen in void)
      for (let i = this.mobs.length - 1; i >= 0; i--) {
        const mob = this.mobs[i];
        const distSq = (mob.x - playerX) ** 2 + (mob.z - playerZ) ** 2;
        if (distSq > 90 * 90 || mob.y < -5) {
          this.scene.remove(mob.group);
          this.mobs.splice(i, 1);
        }
      }

      // Spawn new mobs if under cap
      if (this.mobs.length < this.maxMobs) {
        this.spawnMobNearPlayer(playerX, playerZ);
      }
    }

    // 2. Update existing mobs
    const mobTypes: MobType[] = ['cow', 'pig', 'sheep', 'chicken'];
    this.mobs.forEach((mob) => {
      mob.stateTimer -= dt;
      mob.soundTimer -= dt;

      // Ambient sounds
      if (mob.soundTimer <= 0) {
        mob.soundTimer = Math.random() * 12 + 6;
        const distSq = (mob.x - playerX) ** 2 + (mob.z - playerZ) ** 2;
        if (distSq < 28 * 28) {
          if (mob.type === 'cow') soundManager.playCowSound();
          else if (mob.type === 'pig') soundManager.playPigSound();
          else if (mob.type === 'sheep') soundManager.playSheepSound();
          else if (mob.type === 'chicken') soundManager.playChickenSound();
        }
      }

      // AI State switching
      if (mob.stateTimer <= 0) {
        if (mob.state === 'idle') {
          mob.state = 'walking';
          mob.stateTimer = Math.random() * 3 + 2;
          mob.yaw = Math.random() * Math.PI * 2;
        } else {
          mob.state = 'idle';
          mob.stateTimer = Math.random() * 4 + 1.5;
          mob.vx = 0;
          mob.vz = 0;
        }
      }

      // Movement & Physics
      const config = MOB_CONFIGS[mob.type];
      if (mob.state === 'walking') {
        const speed = config.walkSpeed;
        mob.vx = Math.sin(mob.yaw) * speed;
        mob.vz = Math.cos(mob.yaw) * speed;
        mob.walkAnimTime += dt * 10;
      } else {
        mob.vx *= 0.8;
        mob.vz *= 0.8;
      }

      // Terrain Surface Alignment & Gravity
      const nextX = mob.x + mob.vx * dt;
      const nextZ = mob.z + mob.vz * dt;
      const highestY = this.world.getHighestSolidY(Math.floor(nextX), Math.floor(nextZ));

      // Auto-step / jump up 1 block if obstacle
      if (highestY > mob.y + 0.1 && highestY <= mob.y + 1.2) {
        mob.vy = 4.2;
      }

      // Apply gravity
      mob.vy -= 18 * dt;
      mob.y += mob.vy * dt;

      if (mob.y <= highestY + 1.0) {
        mob.y = highestY + 1.0;
        mob.vy = 0;
        mob.isGrounded = true;
      } else {
        mob.isGrounded = false;
      }

      mob.x = nextX;
      mob.z = nextZ;

      // Sync 3D Mesh
      mob.group.position.set(mob.x, mob.y, mob.z);
      mob.group.rotation.y = mob.yaw;

      // Animate Legs
      if (mob.state === 'walking') {
        mob.legs.forEach((leg, idx) => {
          leg.rotation.x = Math.sin(mob.walkAnimTime + (idx % 2 === 0 ? 0 : Math.PI)) * 0.5;
        });
      } else {
        mob.legs.forEach((leg) => {
          leg.rotation.x = 0;
        });
      }

      // Hurt Red Flash Effect
      if (mob.hurtTimer > 0) {
        mob.hurtTimer -= dt;
        mob.group.traverse((child) => {
          if (child instanceof THREE.Mesh) {
            child.material = this.hurtMaterial;
          }
        });
      } else if (mob.hurtTimer <= 0 && mob.hurtTimer > -1) {
        // Restore materials
        let matIdx = 0;
        mob.group.traverse((child) => {
          if (child instanceof THREE.Mesh && mob.originalMaterials[matIdx]) {
            child.material = mob.originalMaterials[matIdx];
            matIdx++;
          }
        });
        mob.hurtTimer = -1;
      }
    });

    // 3. Update Dropped Items (Float, Spin & Auto-Pickup)
    for (let i = this.droppedItems.length - 1; i >= 0; i--) {
      const item = this.droppedItems[i];

      // Block top face is highestSolidY + 1.0; item rests at +1.15
      const highestBlockY = this.world.getHighestSolidY(Math.floor(item.x), Math.floor(item.z));
      const groundY = highestBlockY + 1.15;

      if (item.y > groundY) {
        item.vy -= 16 * dt;
        item.y += item.vy * dt;
        if (item.y <= groundY) {
          item.y = groundY;
          item.vy = 0;
        }
      } else {
        item.y = groundY;
        item.vy = 0;
      }

      const age = (Date.now() - item.createdAt) / 1000;
      item.mesh.position.set(item.x, item.y + Math.abs(Math.sin(age * 3)) * 0.05, item.z);
      item.mesh.rotation.y += dt * 2.5;

      // Check distance to player for auto-pickup
      const distToPlayer = Math.hypot(item.x - playerX, item.z - playerZ);
      const dyToPlayer = Math.abs(item.y - playerY);

      if (distToPlayer < 1.8 && dyToPlayer < 2.2) {
        soundManager.playPop();
        onCollectItem(item.blockType, 1);
        this.scene.remove(item.mesh);
        this.droppedItems.splice(i, 1);
      } else if (age > 180) {
        // Despawn old items after 3 mins
        this.scene.remove(item.mesh);
        this.droppedItems.splice(i, 1);
      }
    }
  }

  // Raycast attack check when player mines/hits
  public checkHitMob(
    rayOrigin: THREE.Vector3,
    rayDir: THREE.Vector3,
    maxDistance: number = 4.5
  ): Mob | null {
    let closestMob: Mob | null = null;
    let closestDist = maxDistance;

    for (const mob of this.mobs) {
      const mobPos = new THREE.Vector3(mob.x, mob.y + 0.5, mob.z);
      const config = MOB_CONFIGS[mob.type];
      const radius = Math.max(config.width, config.depth) * 0.7;

      // Project mob center onto ray
      const mobVec = mobPos.clone().sub(rayOrigin);
      const projDist = mobVec.dot(rayDir);

      if (projDist > 0 && projDist <= maxDistance) {
        const projPoint = rayOrigin.clone().add(rayDir.clone().multiplyScalar(projDist));
        const perpDist = projPoint.distanceTo(mobPos);

        if (perpDist <= radius && projDist < closestDist) {
          closestDist = projDist;
          closestMob = mob;
        }
      }
    }

    if (closestMob) {
      this.damageMob(closestMob, 3, rayDir);
      return closestMob;
    }

    return null;
  }

  public damageMob(mob: Mob, damage: number, knockbackDir: THREE.Vector3) {
    mob.health -= damage;
    mob.hurtTimer = 0.35;
    soundManager.playMobHurt();

    // Knockback
    mob.vx += knockbackDir.x * 4;
    mob.vz += knockbackDir.z * 4;
    mob.vy = 2.5;

    if (mob.health <= 0) {
      this.killMob(mob);
    }
  }

  private killMob(mob: Mob) {
    const config = MOB_CONFIGS[mob.type];

    // Spawn drops
    config.drops.forEach((drop) => {
      const count = Math.floor(Math.random() * (drop.max - drop.min + 1)) + drop.min;
      for (let i = 0; i < count; i++) {
        this.spawnDroppedItem(
          drop.blockType,
          mob.x + (Math.random() - 0.5) * 0.4,
          mob.y + 0.4,
          mob.z + (Math.random() - 0.5) * 0.4
        );
      }
    });

    // Remove mob from scene & array
    this.scene.remove(mob.group);
    const idx = this.mobs.indexOf(mob);
    if (idx !== -1) {
      this.mobs.splice(idx, 1);
    }
  }

  public spawnDroppedItem(blockType: BlockType, x: number, y: number, z: number) {
    const blockConf = BLOCK_REGISTRY[blockType];
    const colorHex = blockConf?.color && blockConf.color !== 'transparent' ? blockConf.color : '#a83232';

    const geo = new THREE.BoxGeometry(0.25, 0.25, 0.25);
    const mat = new THREE.MeshLambertMaterial({ color: new THREE.Color(colorHex) });
    const mesh = new THREE.Mesh(geo, mat);
    mesh.position.set(x, y, z);
    this.scene.add(mesh);

    this.droppedItems.push({
      id: Math.random().toString(36).substring(2, 9),
      blockType,
      x,
      y,
      z,
      vy: 2.0,
      mesh,
      createdAt: Date.now(),
    });
  }

  private spawnMobNearPlayer(playerX: number, playerZ: number) {
    const mobTypes: MobType[] = ['cow', 'pig', 'sheep', 'chicken'];
    const selectedType = mobTypes[Math.floor(Math.random() * mobTypes.length)];

    // Random distance between 35 and 55 blocks away (out of direct view)
    const angle = Math.random() * Math.PI * 2;
    const radius = Math.random() * 20 + 35;
    const sx = playerX + Math.cos(angle) * radius;
    const sz = playerZ + Math.sin(angle) * radius;

    const surfaceY = this.world.getHighestSolidY(Math.floor(sx), Math.floor(sz));

    // Ensure valid land surface (not water or high mountain boundary)
    if (surfaceY > 1 && surfaceY < 58) {
      const surfaceBlock = this.world.getBlock(Math.floor(sx), surfaceY, Math.floor(sz));
      if (surfaceBlock !== BlockType.WATER && surfaceBlock !== BlockType.AIR) {
        const mob = new Mob(selectedType, sx, surfaceY + 1.0, sz);
        this.scene.add(mob.group);
        this.mobs.push(mob);
      }
    }
  }

  public destroy() {
    this.mobs.forEach((m) => this.scene.remove(m.group));
    this.droppedItems.forEach((item) => this.scene.remove(item.mesh));
    this.mobs = [];
    this.droppedItems = [];
  }
}
