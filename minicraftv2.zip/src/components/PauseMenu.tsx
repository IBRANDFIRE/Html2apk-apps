import React, { useState } from 'react';
import { GameSettings } from '../types';
import { soundManager } from '../game/audio';
import { Play, Save, LogOut, Settings as SettingsIcon, Volume2, Eye, Sun, Check, Cloud } from 'lucide-react';

interface PauseMenuProps {
  isOpen: boolean;
  onResume: () => void;
  onSaveWorld: () => void;
  onSaveAndQuit: () => void;
  settings: GameSettings;
  onUpdateSettings: (settings: Partial<GameSettings>) => void;
  saveFeedback: string | null;
}

export const PauseMenu: React.FC<PauseMenuProps> = ({
  isOpen,
  onResume,
  onSaveWorld,
  onSaveAndQuit,
  settings,
  onUpdateSettings,
  saveFeedback,
}) => {
  const [showSettingsTab, setShowSettingsTab] = useState(false);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm select-none p-4 font-sans text-white animate-fadeIn">
      <div className="w-full max-w-md bg-neutral-900/95 border border-neutral-700/80 rounded-2xl shadow-2xl p-6 flex flex-col items-center">
        {/* Header */}
        <h2 className="text-2xl font-black tracking-widest text-amber-400 uppercase mb-5 drop-shadow-md">
          {showSettingsTab ? 'Game Settings' : 'Game Paused'}
        </h2>

        {saveFeedback && (
          <div className="w-full mb-4 py-2 px-3 bg-emerald-600/90 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-2 border border-emerald-400/60 shadow-lg animate-pulse">
            <Check className="w-4 h-4" />
            <span>{saveFeedback}</span>
          </div>
        )}

        {!showSettingsTab ? (
          <div className="w-full flex flex-col gap-3">
            {/* Resume Button */}
            <button
              onClick={() => {
                soundManager.playUiClick();
                onResume();
              }}
              className="w-full py-3.5 px-4 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold rounded-xl shadow-lg border border-emerald-400/40 flex items-center justify-center gap-2.5 active:scale-98 transition-all"
            >
              <Play className="w-5 h-5 fill-current" />
              <span>RESUME GAME</span>
            </button>

            {/* Save World Button */}
            <button
              onClick={() => {
                soundManager.playUiClick();
                onSaveWorld();
              }}
              className="w-full py-3.5 px-4 bg-neutral-800 hover:bg-neutral-700 text-white font-semibold rounded-xl border border-neutral-600 shadow-md flex items-center justify-center gap-2.5 active:scale-98 transition-all"
            >
              <Save className="w-5 h-5 text-emerald-400" />
              <span>SAVE WORLD</span>
            </button>

            {/* Settings Button */}
            <button
              onClick={() => {
                soundManager.playUiClick();
                setShowSettingsTab(true);
              }}
              className="w-full py-3.5 px-4 bg-neutral-800 hover:bg-neutral-700 text-white font-semibold rounded-xl border border-neutral-600 shadow-md flex items-center justify-center gap-2.5 active:scale-98 transition-all"
            >
              <SettingsIcon className="w-5 h-5 text-amber-400" />
              <span>SETTINGS & GRAPHICS</span>
            </button>

            {/* Save and Quit Button */}
            <button
              onClick={() => {
                soundManager.playUiClick();
                onSaveAndQuit();
              }}
              className="w-full mt-2 py-3.5 px-4 bg-rose-700 hover:bg-rose-600 text-white font-bold rounded-xl border border-rose-500 shadow-lg flex items-center justify-center gap-2.5 active:scale-98 transition-all"
            >
              <LogOut className="w-5 h-5" />
              <span>SAVE AND QUIT TO TITLE</span>
            </button>
          </div>
        ) : (
          <div className="w-full flex flex-col gap-4">
            {/* Sound Volume Slider */}
            <div>
              <div className="flex justify-between items-center text-xs font-mono text-neutral-300 mb-1.5">
                <span className="flex items-center gap-1.5">
                  <Volume2 className="w-4 h-4 text-amber-400" /> Sound Volume
                </span>
                <span className="font-bold">{Math.round(settings.soundVolume * 100)}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="1"
                step="0.05"
                value={settings.soundVolume}
                onChange={(e) => {
                  const val = parseFloat(e.target.value);
                  soundManager.volume = val;
                  onUpdateSettings({ soundVolume: val });
                }}
                className="w-full accent-amber-400 cursor-pointer"
              />
            </div>

            {/* Render Distance Slider */}
            <div>
              <div className="flex justify-between items-center text-xs font-mono text-neutral-300 mb-1.5">
                <span className="flex items-center gap-1.5">
                  <Eye className="w-4 h-4 text-sky-400" /> Render Distance
                </span>
                <span className="font-bold">{settings.renderDistance} Chunks</span>
              </div>
              <input
                type="range"
                min="2"
                max="6"
                step="1"
                value={settings.renderDistance}
                onChange={(e) => onUpdateSettings({ renderDistance: parseInt(e.target.value, 10) })}
                className="w-full accent-sky-400 cursor-pointer"
              />
            </div>

            {/* Field of View (FOV) */}
            <div>
              <div className="flex justify-between items-center text-xs font-mono text-neutral-300 mb-1.5">
                <span>Field of View (FOV)</span>
                <span className="font-bold">{settings.fov}&deg;</span>
              </div>
              <input
                type="range"
                min="60"
                max="100"
                step="5"
                value={settings.fov}
                onChange={(e) => onUpdateSettings({ fov: parseInt(e.target.value, 10) })}
                className="w-full accent-amber-400 cursor-pointer"
              />
            </div>

            {/* Clouds & Coordinates Toggles */}
            <div className="grid grid-cols-2 gap-2 mt-1">
              <button
                type="button"
                onClick={() => {
                  soundManager.playUiClick();
                  onUpdateSettings({ cloudsEnabled: !settings.cloudsEnabled });
                }}
                className={`py-2 px-3 rounded-lg border text-xs font-semibold flex items-center justify-center gap-2 transition-all ${
                  settings.cloudsEnabled
                    ? 'bg-sky-600 border-sky-400 text-white'
                    : 'bg-neutral-950 border-neutral-800 text-neutral-400'
                }`}
              >
                <Cloud className="w-4 h-4" />
                <span>Clouds: {settings.cloudsEnabled ? 'ON' : 'OFF'}</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  soundManager.playUiClick();
                  onUpdateSettings({ showCoordinates: !settings.showCoordinates });
                }}
                className={`py-2 px-3 rounded-lg border text-xs font-semibold flex items-center justify-center gap-2 transition-all ${
                  settings.showCoordinates
                    ? 'bg-amber-600 border-amber-400 text-white'
                    : 'bg-neutral-950 border-neutral-800 text-neutral-400'
                }`}
              >
                <span>Coords: {settings.showCoordinates ? 'ON' : 'OFF'}</span>
              </button>
            </div>

            {/* Back to Pause Menu */}
            <button
              onClick={() => {
                soundManager.playUiClick();
                setShowSettingsTab(false);
              }}
              className="w-full mt-2 py-2.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 font-semibold rounded-xl text-sm"
            >
              Back to Menu
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
