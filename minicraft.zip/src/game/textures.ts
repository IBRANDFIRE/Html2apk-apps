import * as THREE from 'three';
import { BlockType } from '../types';
import { BLOCK_REGISTRY } from './blocks';

const ATLAS_TILES_PER_ROW = 32;
const TILE_SIZE_NORM = 1 / ATLAS_TILES_PER_ROW; // 0.03125
const HALF_PIXEL = 0.5 / 512;

// Pseudo-random noise helper for pixel textures
function seedNoise(x: number, y: number, seed: number = 42): number {
  const n = Math.sin(x * 12.9898 + y * 78.233 + seed) * 43758.5453;
  return n - Math.floor(n);
}

// Draw noise pattern with base color and slight variations
function fillNoise(
  ctx: CanvasRenderingContext2D,
  ox: number,
  oy: number,
  baseColor: [number, number, number],
  variance: number = 15,
  seed: number = 1
) {
  for (let x = 0; x < 16; x++) {
    for (let y = 0; y < 16; y++) {
      const v = (seedNoise(x, y, seed) - 0.5) * variance * 2;
      const r = Math.min(255, Math.max(0, Math.round(baseColor[0] + v)));
      const g = Math.min(255, Math.max(0, Math.round(baseColor[1] + v)));
      const b = Math.min(255, Math.max(0, Math.round(baseColor[2] + v)));
      ctx.fillStyle = `rgb(${r},${g},${b})`;
      ctx.fillRect(ox + x, oy + y, 1, 1);
    }
  }
}

// Draw ore flecks over background
function drawOre(
  ctx: CanvasRenderingContext2D,
  ox: number,
  oy: number,
  fleckColor: [number, number, number],
  highlight: [number, number, number],
  seed: number
) {
  fillNoise(ctx, ox, oy, [125, 125, 125], 25, 404);
  for (let x = 0; x < 16; x++) {
    for (let y = 0; y < 16; y++) {
      const n = seedNoise(x, y, seed);
      if (n > 0.72) {
        ctx.fillStyle = `rgb(${fleckColor[0]}, ${fleckColor[1]}, ${fleckColor[2]})`;
        ctx.fillRect(ox + x, oy + y, 1, 1);
        if (n > 0.88) {
          ctx.fillStyle = `rgb(${highlight[0]}, ${highlight[1]}, ${highlight[2]})`;
          ctx.fillRect(ox + x, oy + y, 1, 1);
        }
      }
    }
  }
}

// Draw wool / fabric texture
function drawWool(
  ctx: CanvasRenderingContext2D,
  ox: number,
  oy: number,
  baseColor: [number, number, number],
  seed: number
) {
  fillNoise(ctx, ox, oy, baseColor, 12, seed);
  ctx.fillStyle = 'rgba(255,255,255,0.08)';
  for (let x = 0; x < 16; x += 2) {
    for (let y = 0; y < 16; y += 2) {
      ctx.fillRect(ox + x, oy + y, 1, 1);
    }
  }
}

export interface TextureAtlasData {
  texture: THREE.CanvasTexture;
  opaqueMaterial: THREE.MeshLambertMaterial;
  transparentMaterial: THREE.MeshLambertMaterial;
  materialsMap: Record<BlockType, THREE.Material>;
  getTileUVs: (tileId: number) => [number, number, number, number];
  getBlockFaceTileId: (blockType: BlockType, faceIndex: number) => number;
}

let cachedAtlas: TextureAtlasData | null = null;

export function getTextureAtlas(): TextureAtlasData {
  if (cachedAtlas) return cachedAtlas;

  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;
  ctx.imageSmoothingEnabled = false;

  // Clear background (transparent)
  ctx.clearRect(0, 0, 512, 512);

  const drawTile = (tileId: number, fn: (ox: number, oy: number) => void) => {
    const col = tileId % ATLAS_TILES_PER_ROW;
    const row = Math.floor(tileId / ATLAS_TILES_PER_ROW);
    fn(col * 16, row * 16);
  };

  // Tile IDs
  const T = {
    DIRT: 1,
    GRASS_TOP: 2,
    GRASS_SIDE: 3,
    STONE: 4,
    COBBLESTONE: 5,
    OAK_LOG_SIDE: 6,
    OAK_LOG_TOP: 7,
    OAK_LEAVES: 8,
    OAK_PLANKS: 9,
    SAND: 10,
    WATER: 11,
    GLASS: 12,
    BRICK: 13,
    BEDROCK: 14,
    COAL_ORE: 15,
    IRON_ORE: 16,
    GOLD_ORE: 17,
    DIAMOND_ORE: 18,
    REDSTONE_ORE: 19,
    EMERALD_ORE: 20,
    LAPIS_ORE: 21,
    DIAMOND_BLOCK: 22,
    GOLD_BLOCK: 23,
    IRON_BLOCK: 24,
    EMERALD_BLOCK: 25,
    NETHERITE_BLOCK: 26,
    CRAFTING_TOP: 27,
    CRAFTING_SIDE: 28,
    TNT_SIDE: 29,
    TNT_TOP: 30,
    SNOW: 31,
    OBSIDIAN: 32,
    BOOKSHELF_SIDE: 33,
    GLOWSTONE: 34,
    SANDSTONE_SIDE: 35,
    CACTUS_SIDE: 36,
    BIRCH_LOG_SIDE: 37,
    BIRCH_LOG_TOP: 38,
    BIRCH_LEAVES: 39,
    BIRCH_PLANKS: 40,
    CHERRY_LOG_SIDE: 41,
    CHERRY_LOG_TOP: 42,
    CHERRY_LEAVES: 43,
    CHERRY_PLANKS: 44,
    DARK_OAK_LOG_SIDE: 45,
    DARK_OAK_LOG_TOP: 46,
    DARK_OAK_LEAVES: 47,
    DARK_OAK_PLANKS: 48,
    ICE: 49,
    PACKED_ICE: 50,
    MOSS_BLOCK: 51,
    CLAY: 52,
    RED_MUSHROOM_BLOCK: 53,
    STONE_BRICKS: 54,
    MOSSY_STONE_BRICKS: 55,
    SMOOTH_STONE: 56,
    NETHERRACK: 57,
    NETHER_BRICKS: 58,
    SOUL_SAND: 59,
    QUARTZ_BLOCK: 60,
    PRISMARINE: 61,
    SEA_LANTERN: 62,
    RED_WOOL: 63,
    BLUE_WOOL: 64,
    GREEN_WOOL: 65,
    YELLOW_WOOL: 66,
    PURPLE_WOOL: 67,
    ORANGE_WOOL: 68,
    WHITE_WOOL: 69,
    BLACK_WOOL: 70,
    TERRACOTTA: 71,
    TARGET_BLOCK: 72,
    POPPY: 73,
    DANDELION: 74,
    SHORT_GRASS: 75,
    TALL_GRASS: 76,
    RED_MUSHROOM: 77,
    BROWN_MUSHROOM: 78,
    SPRUCE_LOG_SIDE: 79,
    SPRUCE_LOG_TOP: 80,
    SPRUCE_LEAVES: 81,
    SPRUCE_PLANKS: 82,
    JUNGLE_LOG_SIDE: 83,
    JUNGLE_LOG_TOP: 84,
    JUNGLE_LEAVES: 85,
    JUNGLE_PLANKS: 86,
    ACACIA_LOG_SIDE: 87,
    ACACIA_LOG_TOP: 88,
    ACACIA_LEAVES: 89,
    ACACIA_PLANKS: 90,
    GRANITE: 91,
    DIORITE: 92,
    ANDESITE: 93,
    DEEPSLATE: 94,
    TUFF: 95,
    BASALT: 96,
  };

  // Draw Dirt
  drawTile(T.DIRT, (ox, oy) => fillNoise(ctx, ox, oy, [134, 96, 67], 20, 101));

  // Draw Grass Top
  drawTile(T.GRASS_TOP, (ox, oy) => fillNoise(ctx, ox, oy, [92, 160, 48], 22, 202));

  // Draw Grass Side
  drawTile(T.GRASS_SIDE, (ox, oy) => {
    fillNoise(ctx, ox, oy, [134, 96, 67], 20, 101);
    for (let x = 0; x < 16; x++) {
      const h = 3 + Math.floor(seedNoise(x, 0, 303) * 3);
      for (let y = 0; y < h; y++) {
        const v = (seedNoise(x, y, 202) - 0.5) * 25;
        ctx.fillStyle = `rgb(${Math.round(92 + v)}, ${Math.round(160 + v)}, ${Math.round(48 + v)})`;
        ctx.fillRect(ox + x, oy + y, 1, 1);
      }
    }
  });

  // Draw Stone
  drawTile(T.STONE, (ox, oy) => fillNoise(ctx, ox, oy, [125, 125, 125], 25, 404));

  // Draw Cobblestone
  drawTile(T.COBBLESTONE, (ox, oy) => {
    fillNoise(ctx, ox, oy, [115, 115, 115], 35, 505);
    ctx.fillStyle = 'rgba(40,40,40,0.3)';
    ctx.fillRect(ox, oy, 16, 1);
    ctx.fillRect(ox, oy + 8, 16, 1);
    ctx.fillRect(ox + 7, oy, 1, 8);
    ctx.fillRect(ox + 15, oy + 8, 1, 8);
  });

  // Oak Log Side
  drawTile(T.OAK_LOG_SIDE, (ox, oy) => {
    for (let x = 0; x < 16; x++) {
      for (let y = 0; y < 16; y++) {
        const stripe = (x % 4 === 0 || x % 5 === 0) ? -20 : 0;
        const v = (seedNoise(x, y, 606) - 0.5) * 15 + stripe;
        ctx.fillStyle = `rgb(${Math.round(103 + v)},${Math.round(82 + v * 0.8)},${Math.round(49 + v * 0.5)})`;
        ctx.fillRect(ox + x, oy + y, 1, 1);
      }
    }
  });

  // Oak Log Top
  drawTile(T.OAK_LOG_TOP, (ox, oy) => {
    fillNoise(ctx, ox, oy, [180, 145, 95], 12, 707);
    ctx.strokeStyle = 'rgb(120,95,60)';
    ctx.lineWidth = 1;
    ctx.strokeRect(ox + 3.5, oy + 3.5, 9, 9);
    ctx.strokeRect(ox + 6.5, oy + 6.5, 3, 3);
  });

  // Oak Leaves
  drawTile(T.OAK_LEAVES, (ox, oy) => {
    for (let x = 0; x < 16; x++) {
      for (let y = 0; y < 16; y++) {
        const noise = seedNoise(x, y, 808);
        if (noise > 0.2) {
          const v = (noise - 0.5) * 35;
          ctx.fillStyle = `rgb(${Math.round(55 + v)}, ${Math.round(135 + v)}, ${Math.round(35 + v)})`;
          ctx.fillRect(ox + x, oy + y, 1, 1);
        } else {
          ctx.fillStyle = 'rgb(30, 80, 20)';
          ctx.fillRect(ox + x, oy + y, 1, 1);
        }
      }
    }
  });

  // Oak Planks
  drawTile(T.OAK_PLANKS, (ox, oy) => {
    fillNoise(ctx, ox, oy, [168, 130, 80], 15, 909);
    ctx.fillStyle = 'rgba(70, 50, 25, 0.4)';
    ctx.fillRect(ox, oy, 16, 1);
    ctx.fillRect(ox, oy + 4, 16, 1);
    ctx.fillRect(ox, oy + 8, 16, 1);
    ctx.fillRect(ox, oy + 12, 16, 1);
  });

  // Sand
  drawTile(T.SAND, (ox, oy) => fillNoise(ctx, ox, oy, [218, 206, 150], 18, 1010));

  // Water
  drawTile(T.WATER, (ox, oy) => {
    ctx.fillStyle = 'rgb(44, 110, 215)';
    ctx.fillRect(ox, oy, 16, 16);
    ctx.fillStyle = 'rgba(120, 180, 255, 0.4)';
    for (let x = 0; x < 16; x++) {
      for (let y = 0; y < 16; y++) {
        if ((x + y) % 4 === 0) ctx.fillRect(ox + x, oy + y, 1, 1);
      }
    }
  });

  // Glass
  drawTile(T.GLASS, (ox, oy) => {
    ctx.fillStyle = 'rgba(210, 230, 255, 0.35)';
    ctx.fillRect(ox, oy, 16, 16);
    ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
    ctx.strokeRect(ox + 0.5, oy + 0.5, 15, 15);
    ctx.fillRect(ox + 3, oy + 3, 2, 2);
    ctx.fillRect(ox + 5, oy + 5, 2, 2);
  });

  // Bricks
  drawTile(T.BRICK, (ox, oy) => {
    fillNoise(ctx, ox, oy, [160, 60, 50], 25, 1111);
    ctx.fillStyle = 'rgb(205, 195, 185)';
    ctx.fillRect(ox, oy, 16, 1);
    ctx.fillRect(ox, oy + 8, 16, 1);
    ctx.fillRect(ox + 7, oy, 1, 8);
    ctx.fillRect(ox + 15, oy + 8, 1, 8);
  });

  // Bedrock
  drawTile(T.BEDROCK, (ox, oy) => fillNoise(ctx, ox, oy, [55, 55, 55], 40, 1212));

  // Ores
  drawTile(T.COAL_ORE, (ox, oy) => drawOre(ctx, ox, oy, [25, 25, 25], [50, 50, 50], 1313));
  drawTile(T.IRON_ORE, (ox, oy) => drawOre(ctx, ox, oy, [215, 185, 155], [235, 205, 175], 1414));
  drawTile(T.GOLD_ORE, (ox, oy) => drawOre(ctx, ox, oy, [245, 215, 60], [255, 240, 130], 1515));
  drawTile(T.DIAMOND_ORE, (ox, oy) => drawOre(ctx, ox, oy, [75, 230, 225], [175, 255, 250], 1616));
  drawTile(T.REDSTONE_ORE, (ox, oy) => drawOre(ctx, ox, oy, [230, 30, 30], [255, 100, 100], 1717));
  drawTile(T.EMERALD_ORE, (ox, oy) => drawOre(ctx, ox, oy, [25, 220, 90], [140, 255, 170], 1818));
  drawTile(T.LAPIS_ORE, (ox, oy) => drawOre(ctx, ox, oy, [30, 75, 200], [80, 140, 255], 1919));

  // Mineral Blocks
  drawTile(T.DIAMOND_BLOCK, (ox, oy) => {
    fillNoise(ctx, ox, oy, [100, 240, 234], 15, 2001);
    ctx.fillStyle = 'rgba(255,255,255,0.6)';
    ctx.strokeRect(ox + 1.5, oy + 1.5, 13, 13);
  });
  drawTile(T.GOLD_BLOCK, (ox, oy) => {
    fillNoise(ctx, ox, oy, [255, 215, 0], 15, 2002);
    ctx.fillStyle = 'rgba(255,255,255,0.6)';
    ctx.strokeRect(ox + 1.5, oy + 1.5, 13, 13);
  });
  drawTile(T.IRON_BLOCK, (ox, oy) => {
    fillNoise(ctx, ox, oy, [224, 224, 224], 12, 2003);
    ctx.fillStyle = 'rgba(150,150,150,0.5)';
    ctx.strokeRect(ox + 1.5, oy + 1.5, 13, 13);
  });
  drawTile(T.EMERALD_BLOCK, (ox, oy) => {
    fillNoise(ctx, ox, oy, [46, 240, 119], 15, 2004);
    ctx.fillStyle = 'rgba(255,255,255,0.5)';
    ctx.strokeRect(ox + 1.5, oy + 1.5, 13, 13);
  });
  drawTile(T.NETHERITE_BLOCK, (ox, oy) => {
    fillNoise(ctx, ox, oy, [68, 59, 61], 15, 2005);
    ctx.fillStyle = 'rgba(30,25,26,0.7)';
    ctx.strokeRect(ox + 1.5, oy + 1.5, 13, 13);
  });

  // Crafting Table
  drawTile(T.CRAFTING_TOP, (ox, oy) => {
    fillNoise(ctx, ox, oy, [168, 130, 80], 15, 909);
    ctx.fillStyle = 'rgba(40, 25, 10, 0.6)';
    ctx.strokeRect(ox + 2.5, oy + 2.5, 11, 11);
    ctx.fillRect(ox + 2, oy + 2, 4, 4);
    ctx.fillRect(ox + 10, oy + 2, 4, 4);
  });
  drawTile(T.CRAFTING_SIDE, (ox, oy) => {
    fillNoise(ctx, ox, oy, [168, 130, 80], 15, 909);
    ctx.fillStyle = 'rgba(60, 40, 20, 0.7)';
    ctx.fillRect(ox + 4, oy + 3, 2, 10);
    ctx.fillRect(ox + 2, oy + 3, 6, 2);
  });

  // TNT
  drawTile(T.TNT_SIDE, (ox, oy) => {
    fillNoise(ctx, ox, oy, [210, 45, 30], 15, 1818);
    ctx.fillStyle = 'rgb(240, 230, 210)';
    ctx.fillRect(ox, oy + 5, 16, 6);
    ctx.fillStyle = 'black';
    ctx.font = 'bold 5px monospace';
    ctx.fillText('TNT', ox + 2, oy + 10);
  });
  drawTile(T.TNT_TOP, (ox, oy) => {
    fillNoise(ctx, ox, oy, [210, 45, 30], 15, 1819);
    ctx.fillStyle = 'rgb(50, 50, 50)';
    ctx.fillRect(ox + 7, oy + 7, 2, 2);
  });

  // Nature / Building
  drawTile(T.SNOW, (ox, oy) => fillNoise(ctx, ox, oy, [245, 248, 255], 10, 1919));
  drawTile(T.OBSIDIAN, (ox, oy) => {
    fillNoise(ctx, ox, oy, [20, 15, 30], 15, 2020);
    ctx.fillStyle = 'rgba(100, 60, 140, 0.4)';
    for (let x = 0; x < 16; x++) {
      for (let y = 0; y < 16; y++) {
        if (seedNoise(x, y, 2021) > 0.85) ctx.fillRect(ox + x, oy + y, 1, 1);
      }
    }
  });
  drawTile(T.BOOKSHELF_SIDE, (ox, oy) => {
    fillNoise(ctx, ox, oy, [168, 130, 80], 15, 909);
    const colors = ['#b32020', '#2060b3', '#209040', '#803090', '#c09020'];
    for (let shelf = 0; shelf < 2; shelf++) {
      const yBase = shelf * 8 + 1;
      ctx.fillStyle = '#20150d';
      ctx.fillRect(ox + 1, oy + yBase, 14, 6);
      for (let b = 0; b < 6; b++) {
        ctx.fillStyle = colors[(b + shelf * 3) % colors.length];
        ctx.fillRect(ox + 2 + b * 2, oy + yBase + 1, 2, 5);
      }
    }
  });
  drawTile(T.GLOWSTONE, (ox, oy) => fillNoise(ctx, ox, oy, [240, 200, 120], 35, 2222));
  drawTile(T.SANDSTONE_SIDE, (ox, oy) => {
    fillNoise(ctx, ox, oy, [210, 195, 140], 12, 2323);
    ctx.fillStyle = 'rgba(160, 145, 90, 0.4)';
    ctx.fillRect(ox, oy + 12, 16, 4);
    ctx.fillRect(ox, oy, 16, 2);
  });
  drawTile(T.CACTUS_SIDE, (ox, oy) => {
    fillNoise(ctx, ox, oy, [60, 130, 45], 15, 2424);
    ctx.fillStyle = '#1e3816';
    ctx.fillRect(ox, oy, 2, 16);
    ctx.fillRect(ox + 14, oy, 2, 16);
  });

  // Birch Wood
  drawTile(T.BIRCH_LOG_SIDE, (ox, oy) => {
    fillNoise(ctx, ox, oy, [220, 215, 197], 15, 3001);
    ctx.fillStyle = '#222222';
    ctx.fillRect(ox + 3, oy + 4, 3, 2);
    ctx.fillRect(ox + 10, oy + 11, 4, 2);
  });
  drawTile(T.BIRCH_LOG_TOP, (ox, oy) => {
    fillNoise(ctx, ox, oy, [214, 194, 154], 12, 3002);
    ctx.strokeStyle = '#9e8966';
    ctx.strokeRect(ox + 3.5, oy + 3.5, 9, 9);
  });
  drawTile(T.BIRCH_LEAVES, (ox, oy) => fillNoise(ctx, ox, oy, [128, 167, 85], 25, 3003));
  drawTile(T.BIRCH_PLANKS, (ox, oy) => {
    fillNoise(ctx, ox, oy, [214, 194, 154], 12, 3004);
    ctx.fillStyle = 'rgba(100, 80, 50, 0.3)';
    ctx.fillRect(ox, oy + 4, 16, 1);
    ctx.fillRect(ox, oy + 12, 16, 1);
  });

  // Cherry Wood
  drawTile(T.CHERRY_LOG_SIDE, (ox, oy) => fillNoise(ctx, ox, oy, [92, 50, 55], 20, 4001));
  drawTile(T.CHERRY_LOG_TOP, (ox, oy) => fillNoise(ctx, ox, oy, [232, 181, 181], 15, 4002));
  drawTile(T.CHERRY_LEAVES, (ox, oy) => fillNoise(ctx, ox, oy, [254, 158, 203], 25, 4003));
  drawTile(T.CHERRY_PLANKS, (ox, oy) => fillNoise(ctx, ox, oy, [232, 181, 181], 15, 4004));

  // Dark Oak Wood
  drawTile(T.DARK_OAK_LOG_SIDE, (ox, oy) => fillNoise(ctx, ox, oy, [52, 38, 23], 15, 5001));
  drawTile(T.DARK_OAK_LOG_TOP, (ox, oy) => fillNoise(ctx, ox, oy, [70, 50, 30], 12, 5002));
  drawTile(T.DARK_OAK_LEAVES, (ox, oy) => fillNoise(ctx, ox, oy, [40, 70, 20], 25, 5003));
  drawTile(T.DARK_OAK_PLANKS, (ox, oy) => fillNoise(ctx, ox, oy, [70, 50, 30], 12, 5004));

  // Ice & Moss
  drawTile(T.ICE, (ox, oy) => fillNoise(ctx, ox, oy, [145, 191, 255], 15, 6001));
  drawTile(T.PACKED_ICE, (ox, oy) => fillNoise(ctx, ox, oy, [160, 205, 255], 10, 6002));
  drawTile(T.MOSS_BLOCK, (ox, oy) => fillNoise(ctx, ox, oy, [89, 112, 51], 20, 6003));
  drawTile(T.CLAY, (ox, oy) => fillNoise(ctx, ox, oy, [154, 163, 180], 12, 6004));
  drawTile(T.RED_MUSHROOM_BLOCK, (ox, oy) => {
    fillNoise(ctx, ox, oy, [182, 35, 35], 15, 6005);
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(ox + 3, oy + 3, 3, 3);
    ctx.fillRect(ox + 10, oy + 9, 3, 3);
  });

  // Stonework
  drawTile(T.STONE_BRICKS, (ox, oy) => {
    fillNoise(ctx, ox, oy, [115, 115, 115], 15, 7001);
    ctx.fillStyle = '#333333';
    ctx.fillRect(ox, oy, 16, 1);
    ctx.fillRect(ox, oy + 8, 16, 1);
    ctx.fillRect(ox + 8, oy, 1, 8);
    ctx.fillRect(ox + 4, oy + 8, 1, 8);
  });
  drawTile(T.MOSSY_STONE_BRICKS, (ox, oy) => {
    fillNoise(ctx, ox, oy, [115, 115, 115], 15, 7001);
    ctx.fillStyle = '#333333';
    ctx.fillRect(ox, oy, 16, 1);
    ctx.fillRect(ox, oy + 8, 16, 1);
    ctx.fillStyle = 'rgba(80, 130, 50, 0.7)';
    ctx.fillRect(ox + 2, oy + 2, 4, 4);
    ctx.fillRect(ox + 10, oy + 9, 4, 3);
  });
  drawTile(T.SMOOTH_STONE, (ox, oy) => {
    fillNoise(ctx, ox, oy, [160, 160, 160], 10, 7002);
    ctx.fillStyle = '#666666';
    ctx.strokeRect(ox + 0.5, oy + 0.5, 15, 15);
  });
  drawTile(T.NETHERRACK, (ox, oy) => fillNoise(ctx, ox, oy, [105, 37, 37], 25, 7003));
  drawTile(T.NETHER_BRICKS, (ox, oy) => {
    fillNoise(ctx, ox, oy, [46, 20, 26], 15, 7004);
    ctx.fillStyle = '#140508';
    ctx.fillRect(ox, oy, 16, 1);
    ctx.fillRect(ox, oy + 8, 16, 1);
  });
  drawTile(T.SOUL_SAND, (ox, oy) => fillNoise(ctx, ox, oy, [81, 62, 52], 20, 7005));
  drawTile(T.QUARTZ_BLOCK, (ox, oy) => fillNoise(ctx, ox, oy, [234, 229, 223], 8, 7006));
  drawTile(T.PRISMARINE, (ox, oy) => fillNoise(ctx, ox, oy, [91, 160, 152], 20, 7007));
  drawTile(T.SEA_LANTERN, (ox, oy) => {
    fillNoise(ctx, ox, oy, [194, 227, 222], 12, 7008);
    ctx.fillStyle = 'rgba(255,255,255,0.7)';
    ctx.strokeRect(ox + 2.5, oy + 2.5, 11, 11);
  });

  // Wools
  drawTile(T.RED_WOOL, (ox, oy) => drawWool(ctx, ox, oy, [160, 32, 32], 8001));
  drawTile(T.BLUE_WOOL, (ox, oy) => drawWool(ctx, ox, oy, [42, 68, 176], 8002));
  drawTile(T.GREEN_WOOL, (ox, oy) => drawWool(ctx, ox, oy, [66, 120, 32], 8003));
  drawTile(T.YELLOW_WOOL, (ox, oy) => drawWool(ctx, ox, oy, [212, 180, 36], 8004));
  drawTile(T.PURPLE_WOOL, (ox, oy) => drawWool(ctx, ox, oy, [123, 43, 176], 8005));
  drawTile(T.ORANGE_WOOL, (ox, oy) => drawWool(ctx, ox, oy, [224, 114, 27], 8006));
  drawTile(T.WHITE_WOOL, (ox, oy) => drawWool(ctx, ox, oy, [232, 232, 232], 8007));
  drawTile(T.BLACK_WOOL, (ox, oy) => drawWool(ctx, ox, oy, [27, 27, 32], 8008));
  drawTile(T.TERRACOTTA, (ox, oy) => fillNoise(ctx, ox, oy, [153, 92, 67], 15, 8009));
  drawTile(T.TARGET_BLOCK, (ox, oy) => {
    fillNoise(ctx, ox, oy, [226, 207, 180], 10, 8010);
    ctx.strokeStyle = '#b81c1c';
    ctx.lineWidth = 2;
    ctx.strokeRect(ox + 2, oy + 2, 12, 12);
    ctx.fillRect(ox + 7, oy + 7, 2, 2);
  });

  // Flowers & Plants
  drawTile(T.POPPY, (ox, oy) => {
    ctx.fillStyle = '#1e6612';
    ctx.fillRect(ox + 7, oy + 6, 2, 10);
    ctx.fillStyle = '#dc2222';
    ctx.fillRect(ox + 5, oy + 2, 6, 5);
    ctx.fillStyle = '#ff5555';
    ctx.fillRect(ox + 6, oy + 3, 4, 3);
    ctx.fillStyle = '#111';
    ctx.fillRect(ox + 7, oy + 4, 2, 2);
  });
  drawTile(T.DANDELION, (ox, oy) => {
    ctx.fillStyle = '#1e6612';
    ctx.fillRect(ox + 7, oy + 7, 2, 9);
    ctx.fillStyle = '#f5c818';
    ctx.fillRect(ox + 5, oy + 3, 6, 5);
    ctx.fillStyle = '#ffe040';
    ctx.fillRect(ox + 6, oy + 4, 4, 3);
  });
  drawTile(T.SHORT_GRASS, (ox, oy) => {
    ctx.fillStyle = '#4cb72e';
    ctx.fillRect(ox + 3, oy + 8, 2, 8);
    ctx.fillRect(ox + 6, oy + 4, 2, 12);
    ctx.fillRect(ox + 9, oy + 6, 2, 10);
    ctx.fillRect(ox + 12, oy + 10, 2, 6);
    ctx.fillStyle = '#378d1f';
    ctx.fillRect(ox + 4, oy + 10, 1, 6);
    ctx.fillRect(ox + 7, oy + 6, 1, 10);
    ctx.fillRect(ox + 10, oy + 8, 1, 8);
  });
  drawTile(T.TALL_GRASS, (ox, oy) => {
    ctx.fillStyle = '#3da524';
    ctx.fillRect(ox + 2, oy + 4, 2, 12);
    ctx.fillRect(ox + 5, oy + 1, 2, 15);
    ctx.fillRect(ox + 8, oy + 3, 2, 13);
    ctx.fillRect(ox + 11, oy + 5, 2, 11);
    ctx.fillStyle = '#2c7a18';
    ctx.fillRect(ox + 6, oy + 3, 1, 13);
    ctx.fillRect(ox + 9, oy + 5, 1, 11);
  });
  drawTile(T.RED_MUSHROOM, (ox, oy) => {
    ctx.fillStyle = '#d6cbba';
    ctx.fillRect(ox + 7, oy + 9, 2, 7);
    ctx.fillStyle = '#d42222';
    ctx.fillRect(ox + 4, oy + 5, 8, 5);
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(ox + 5, oy + 6, 2, 2);
    ctx.fillRect(ox + 9, oy + 7, 2, 2);
  });
  drawTile(T.BROWN_MUSHROOM, (ox, oy) => {
    ctx.fillStyle = '#d6cbba';
    ctx.fillRect(ox + 7, oy + 9, 2, 7);
    ctx.fillStyle = '#946338';
    ctx.fillRect(ox + 4, oy + 5, 8, 5);
    ctx.fillStyle = '#c79d71';
    ctx.fillRect(ox + 6, oy + 6, 3, 2);
  });

  // Spruce Wood
  drawTile(T.SPRUCE_LOG_SIDE, (ox, oy) => {
    for (let x = 0; x < 16; x++) {
      for (let y = 0; y < 16; y++) {
        const stripe = (x % 3 === 0) ? -18 : 0;
        const v = (seedNoise(x, y, 901) - 0.5) * 12 + stripe;
        ctx.fillStyle = `rgb(${Math.round(59 + v)},${Math.round(40 + v * 0.8)},${Math.round(21 + v * 0.5)})`;
        ctx.fillRect(ox + x, oy + y, 1, 1);
      }
    }
  });
  drawTile(T.SPRUCE_LOG_TOP, (ox, oy) => {
    fillNoise(ctx, ox, oy, [105, 75, 45], 12, 902);
    ctx.strokeStyle = 'rgb(59,40,21)';
    ctx.lineWidth = 1;
    ctx.strokeRect(ox + 3.5, oy + 3.5, 9, 9);
    ctx.strokeRect(ox + 6.5, oy + 6.5, 3, 3);
  });
  drawTile(T.SPRUCE_LEAVES, (ox, oy) => fillNoise(ctx, ox, oy, [40, 70, 45], 25, 903));
  drawTile(T.SPRUCE_PLANKS, (ox, oy) => {
    fillNoise(ctx, ox, oy, [101, 71, 42], 15, 904);
    ctx.fillStyle = 'rgba(35, 20, 10, 0.4)';
    ctx.fillRect(ox, oy, 16, 1);
    ctx.fillRect(ox, oy + 4, 16, 1);
    ctx.fillRect(ox, oy + 8, 16, 1);
    ctx.fillRect(ox, oy + 12, 16, 1);
  });

  // Jungle Wood
  drawTile(T.JUNGLE_LOG_SIDE, (ox, oy) => {
    for (let x = 0; x < 16; x++) {
      for (let y = 0; y < 16; y++) {
        const stripe = (x % 5 === 0) ? -15 : 0;
        const v = (seedNoise(x, y, 910) - 0.5) * 15 + stripe;
        ctx.fillStyle = `rgb(${Math.round(86 + v)},${Math.round(66 + v * 0.8)},${Math.round(25 + v * 0.5)})`;
        ctx.fillRect(ox + x, oy + y, 1, 1);
      }
    }
  });
  drawTile(T.JUNGLE_LOG_TOP, (ox, oy) => {
    fillNoise(ctx, ox, oy, [160, 116, 71], 12, 911);
    ctx.strokeStyle = 'rgb(86,66,25)';
    ctx.lineWidth = 1;
    ctx.strokeRect(ox + 3.5, oy + 3.5, 9, 9);
  });
  drawTile(T.JUNGLE_LEAVES, (ox, oy) => fillNoise(ctx, ox, oy, [36, 143, 29], 30, 912));
  drawTile(T.JUNGLE_PLANKS, (ox, oy) => {
    fillNoise(ctx, ox, oy, [160, 116, 71], 15, 913);
    ctx.fillStyle = 'rgba(60, 40, 15, 0.4)';
    ctx.fillRect(ox, oy, 16, 1);
    ctx.fillRect(ox, oy + 4, 16, 1);
    ctx.fillRect(ox, oy + 8, 16, 1);
    ctx.fillRect(ox, oy + 12, 16, 1);
  });

  // Acacia Wood
  drawTile(T.ACACIA_LOG_SIDE, (ox, oy) => fillNoise(ctx, ox, oy, [103, 95, 86], 15, 920));
  drawTile(T.ACACIA_LOG_TOP, (ox, oy) => {
    fillNoise(ctx, ox, oy, [186, 92, 48], 12, 921);
    ctx.strokeStyle = 'rgb(103,95,86)';
    ctx.lineWidth = 1;
    ctx.strokeRect(ox + 3.5, oy + 3.5, 9, 9);
  });
  drawTile(T.ACACIA_LEAVES, (ox, oy) => fillNoise(ctx, ox, oy, [70, 128, 25], 25, 922));
  drawTile(T.ACACIA_PLANKS, (ox, oy) => {
    fillNoise(ctx, ox, oy, [186, 92, 48], 15, 923);
    ctx.fillStyle = 'rgba(70, 30, 10, 0.4)';
    ctx.fillRect(ox, oy, 16, 1);
    ctx.fillRect(ox, oy + 4, 16, 1);
    ctx.fillRect(ox, oy + 8, 16, 1);
    ctx.fillRect(ox, oy + 12, 16, 1);
  });

  // Underground Special Stones
  drawTile(T.GRANITE, (ox, oy) => fillNoise(ctx, ox, oy, [149, 103, 86], 22, 924));
  drawTile(T.DIORITE, (ox, oy) => fillNoise(ctx, ox, oy, [191, 191, 191], 30, 925));
  drawTile(T.ANDESITE, (ox, oy) => fillNoise(ctx, ox, oy, [135, 135, 135], 18, 926));
  drawTile(T.DEEPSLATE, (ox, oy) => {
    fillNoise(ctx, ox, oy, [54, 54, 60], 15, 927);
    ctx.fillStyle = 'rgba(20, 20, 25, 0.4)';
    ctx.fillRect(ox, oy + 3, 16, 2);
    ctx.fillRect(ox, oy + 9, 16, 2);
  });
  drawTile(T.TUFF, (ox, oy) => fillNoise(ctx, ox, oy, [107, 115, 100], 20, 928));
  drawTile(T.BASALT, (ox, oy) => {
    fillNoise(ctx, ox, oy, [78, 78, 82], 12, 929);
    ctx.fillStyle = 'rgba(40, 40, 45, 0.3)';
    ctx.fillRect(ox + 4, oy, 2, 16);
    ctx.fillRect(ox + 10, oy, 2, 16);
  });

  const texture = new THREE.CanvasTexture(canvas);
  texture.magFilter = THREE.NearestFilter;
  texture.minFilter = THREE.NearestFilter;
  texture.generateMipmaps = false;
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.needsUpdate = true;

  const opaqueMaterial = new THREE.MeshLambertMaterial({
    map: texture,
    side: THREE.FrontSide,
    vertexColors: true,
  });

  const transparentMaterial = new THREE.MeshLambertMaterial({
    map: texture,
    transparent: true,
    alphaTest: 0.5,
    depthWrite: true,
    side: THREE.DoubleSide,
    vertexColors: true,
  });

  const getTileUVs = (tileId: number): [number, number, number, number] => {
    const col = tileId % ATLAS_TILES_PER_ROW;
    const row = Math.floor(tileId / ATLAS_TILES_PER_ROW);
    const u0 = col * TILE_SIZE_NORM + HALF_PIXEL;
    const u1 = (col + 1) * TILE_SIZE_NORM - HALF_PIXEL;
    const v1 = 1.0 - row * TILE_SIZE_NORM - HALF_PIXEL;
    const v0 = 1.0 - (row + 1) * TILE_SIZE_NORM + HALF_PIXEL;
    return [u0, v0, u1, v1];
  };

  const FACE_TILE_MAP: Partial<Record<BlockType, number[]>> = {
    [BlockType.GRASS]: [T.GRASS_SIDE, T.GRASS_SIDE, T.GRASS_TOP, T.DIRT, T.GRASS_SIDE, T.GRASS_SIDE],
    [BlockType.DIRT]: [T.DIRT, T.DIRT, T.DIRT, T.DIRT, T.DIRT, T.DIRT],
    [BlockType.STONE]: [T.STONE, T.STONE, T.STONE, T.STONE, T.STONE, T.STONE],
    [BlockType.COBBLESTONE]: [T.COBBLESTONE, T.COBBLESTONE, T.COBBLESTONE, T.COBBLESTONE, T.COBBLESTONE, T.COBBLESTONE],
    [BlockType.OAK_LOG]: [T.OAK_LOG_SIDE, T.OAK_LOG_SIDE, T.OAK_LOG_TOP, T.OAK_LOG_TOP, T.OAK_LOG_SIDE, T.OAK_LOG_SIDE],
    [BlockType.OAK_LEAVES]: [T.OAK_LEAVES, T.OAK_LEAVES, T.OAK_LEAVES, T.OAK_LEAVES, T.OAK_LEAVES, T.OAK_LEAVES],
    [BlockType.OAK_PLANKS]: [T.OAK_PLANKS, T.OAK_PLANKS, T.OAK_PLANKS, T.OAK_PLANKS, T.OAK_PLANKS, T.OAK_PLANKS],
    [BlockType.SAND]: [T.SAND, T.SAND, T.SAND, T.SAND, T.SAND, T.SAND],
    [BlockType.WATER]: [T.WATER, T.WATER, T.WATER, T.WATER, T.WATER, T.WATER],
    [BlockType.GLASS]: [T.GLASS, T.GLASS, T.GLASS, T.GLASS, T.GLASS, T.GLASS],
    [BlockType.BRICK]: [T.BRICK, T.BRICK, T.BRICK, T.BRICK, T.BRICK, T.BRICK],
    [BlockType.BEDROCK]: [T.BEDROCK, T.BEDROCK, T.BEDROCK, T.BEDROCK, T.BEDROCK, T.BEDROCK],
    [BlockType.COAL_ORE]: [T.COAL_ORE, T.COAL_ORE, T.COAL_ORE, T.COAL_ORE, T.COAL_ORE, T.COAL_ORE],
    [BlockType.IRON_ORE]: [T.IRON_ORE, T.IRON_ORE, T.IRON_ORE, T.IRON_ORE, T.IRON_ORE, T.IRON_ORE],
    [BlockType.GOLD_ORE]: [T.GOLD_ORE, T.GOLD_ORE, T.GOLD_ORE, T.GOLD_ORE, T.GOLD_ORE, T.GOLD_ORE],
    [BlockType.DIAMOND_ORE]: [T.DIAMOND_ORE, T.DIAMOND_ORE, T.DIAMOND_ORE, T.DIAMOND_ORE, T.DIAMOND_ORE, T.DIAMOND_ORE],
    [BlockType.REDSTONE_ORE]: [T.REDSTONE_ORE, T.REDSTONE_ORE, T.REDSTONE_ORE, T.REDSTONE_ORE, T.REDSTONE_ORE, T.REDSTONE_ORE],
    [BlockType.EMERALD_ORE]: [T.EMERALD_ORE, T.EMERALD_ORE, T.EMERALD_ORE, T.EMERALD_ORE, T.EMERALD_ORE, T.EMERALD_ORE],
    [BlockType.LAPIS_ORE]: [T.LAPIS_ORE, T.LAPIS_ORE, T.LAPIS_ORE, T.LAPIS_ORE, T.LAPIS_ORE, T.LAPIS_ORE],
    [BlockType.DIAMOND_BLOCK]: [T.DIAMOND_BLOCK, T.DIAMOND_BLOCK, T.DIAMOND_BLOCK, T.DIAMOND_BLOCK, T.DIAMOND_BLOCK, T.DIAMOND_BLOCK],
    [BlockType.GOLD_BLOCK]: [T.GOLD_BLOCK, T.GOLD_BLOCK, T.GOLD_BLOCK, T.GOLD_BLOCK, T.GOLD_BLOCK, T.GOLD_BLOCK],
    [BlockType.IRON_BLOCK]: [T.IRON_BLOCK, T.IRON_BLOCK, T.IRON_BLOCK, T.IRON_BLOCK, T.IRON_BLOCK, T.IRON_BLOCK],
    [BlockType.EMERALD_BLOCK]: [T.EMERALD_BLOCK, T.EMERALD_BLOCK, T.EMERALD_BLOCK, T.EMERALD_BLOCK, T.EMERALD_BLOCK, T.EMERALD_BLOCK],
    [BlockType.NETHERITE_BLOCK]: [T.NETHERITE_BLOCK, T.NETHERITE_BLOCK, T.NETHERITE_BLOCK, T.NETHERITE_BLOCK, T.NETHERITE_BLOCK, T.NETHERITE_BLOCK],
    [BlockType.CRAFTING_TABLE]: [T.CRAFTING_SIDE, T.CRAFTING_SIDE, T.CRAFTING_TOP, T.OAK_PLANKS, T.CRAFTING_SIDE, T.CRAFTING_SIDE],
    [BlockType.TNT]: [T.TNT_SIDE, T.TNT_SIDE, T.TNT_TOP, T.TNT_TOP, T.TNT_SIDE, T.TNT_SIDE],
    [BlockType.SNOW]: [T.SNOW, T.SNOW, T.SNOW, T.SNOW, T.SNOW, T.SNOW],
    [BlockType.OBSIDIAN]: [T.OBSIDIAN, T.OBSIDIAN, T.OBSIDIAN, T.OBSIDIAN, T.OBSIDIAN, T.OBSIDIAN],
    [BlockType.BOOKSHELF]: [T.BOOKSHELF_SIDE, T.BOOKSHELF_SIDE, T.OAK_PLANKS, T.OAK_PLANKS, T.BOOKSHELF_SIDE, T.BOOKSHELF_SIDE],
    [BlockType.GLOWSTONE]: [T.GLOWSTONE, T.GLOWSTONE, T.GLOWSTONE, T.GLOWSTONE, T.GLOWSTONE, T.GLOWSTONE],
    [BlockType.SANDSTONE]: [T.SANDSTONE_SIDE, T.SANDSTONE_SIDE, T.SAND, T.SAND, T.SANDSTONE_SIDE, T.SANDSTONE_SIDE],
    [BlockType.CACTUS]: [T.CACTUS_SIDE, T.CACTUS_SIDE, T.CACTUS_SIDE, T.CACTUS_SIDE, T.CACTUS_SIDE, T.CACTUS_SIDE],
    [BlockType.BIRCH_LOG]: [T.BIRCH_LOG_SIDE, T.BIRCH_LOG_SIDE, T.BIRCH_LOG_TOP, T.BIRCH_LOG_TOP, T.BIRCH_LOG_SIDE, T.BIRCH_LOG_SIDE],
    [BlockType.BIRCH_LEAVES]: [T.BIRCH_LEAVES, T.BIRCH_LEAVES, T.BIRCH_LEAVES, T.BIRCH_LEAVES, T.BIRCH_LEAVES, T.BIRCH_LEAVES],
    [BlockType.BIRCH_PLANKS]: [T.BIRCH_PLANKS, T.BIRCH_PLANKS, T.BIRCH_PLANKS, T.BIRCH_PLANKS, T.BIRCH_PLANKS, T.BIRCH_PLANKS],
    [BlockType.CHERRY_LOG]: [T.CHERRY_LOG_SIDE, T.CHERRY_LOG_SIDE, T.CHERRY_LOG_TOP, T.CHERRY_LOG_TOP, T.CHERRY_LOG_SIDE, T.CHERRY_LOG_SIDE],
    [BlockType.CHERRY_LEAVES]: [T.CHERRY_LEAVES, T.CHERRY_LEAVES, T.CHERRY_LEAVES, T.CHERRY_LEAVES, T.CHERRY_LEAVES, T.CHERRY_LEAVES],
    [BlockType.CHERRY_PLANKS]: [T.CHERRY_PLANKS, T.CHERRY_PLANKS, T.CHERRY_PLANKS, T.CHERRY_PLANKS, T.CHERRY_PLANKS, T.CHERRY_PLANKS],
    [BlockType.DARK_OAK_LOG]: [T.DARK_OAK_LOG_SIDE, T.DARK_OAK_LOG_SIDE, T.DARK_OAK_LOG_TOP, T.DARK_OAK_LOG_TOP, T.DARK_OAK_LOG_SIDE, T.DARK_OAK_LOG_SIDE],
    [BlockType.DARK_OAK_LEAVES]: [T.DARK_OAK_LEAVES, T.DARK_OAK_LEAVES, T.DARK_OAK_LEAVES, T.DARK_OAK_LEAVES, T.DARK_OAK_LEAVES, T.DARK_OAK_LEAVES],
    [BlockType.DARK_OAK_PLANKS]: [T.DARK_OAK_PLANKS, T.DARK_OAK_PLANKS, T.DARK_OAK_PLANKS, T.DARK_OAK_PLANKS, T.DARK_OAK_PLANKS, T.DARK_OAK_PLANKS],
    [BlockType.ICE]: [T.ICE, T.ICE, T.ICE, T.ICE, T.ICE, T.ICE],
    [BlockType.PACKED_ICE]: [T.PACKED_ICE, T.PACKED_ICE, T.PACKED_ICE, T.PACKED_ICE, T.PACKED_ICE, T.PACKED_ICE],
    [BlockType.MOSS_BLOCK]: [T.MOSS_BLOCK, T.MOSS_BLOCK, T.MOSS_BLOCK, T.MOSS_BLOCK, T.MOSS_BLOCK, T.MOSS_BLOCK],
    [BlockType.CLAY]: [T.CLAY, T.CLAY, T.CLAY, T.CLAY, T.CLAY, T.CLAY],
    [BlockType.RED_MUSHROOM_BLOCK]: [T.RED_MUSHROOM_BLOCK, T.RED_MUSHROOM_BLOCK, T.RED_MUSHROOM_BLOCK, T.RED_MUSHROOM_BLOCK, T.RED_MUSHROOM_BLOCK, T.RED_MUSHROOM_BLOCK],
    [BlockType.STONE_BRICKS]: [T.STONE_BRICKS, T.STONE_BRICKS, T.STONE_BRICKS, T.STONE_BRICKS, T.STONE_BRICKS, T.STONE_BRICKS],
    [BlockType.MOSSY_STONE_BRICKS]: [T.MOSSY_STONE_BRICKS, T.MOSSY_STONE_BRICKS, T.MOSSY_STONE_BRICKS, T.MOSSY_STONE_BRICKS, T.MOSSY_STONE_BRICKS, T.MOSSY_STONE_BRICKS],
    [BlockType.SMOOTH_STONE]: [T.SMOOTH_STONE, T.SMOOTH_STONE, T.SMOOTH_STONE, T.SMOOTH_STONE, T.SMOOTH_STONE, T.SMOOTH_STONE],
    [BlockType.GRANITE]: [T.GRANITE, T.GRANITE, T.GRANITE, T.GRANITE, T.GRANITE, T.GRANITE],
    [BlockType.DIORITE]: [T.DIORITE, T.DIORITE, T.DIORITE, T.DIORITE, T.DIORITE, T.DIORITE],
    [BlockType.ANDESITE]: [T.ANDESITE, T.ANDESITE, T.ANDESITE, T.ANDESITE, T.ANDESITE, T.ANDESITE],
    [BlockType.DEEPSLATE]: [T.DEEPSLATE, T.DEEPSLATE, T.DEEPSLATE, T.DEEPSLATE, T.DEEPSLATE, T.DEEPSLATE],
    [BlockType.TUFF]: [T.TUFF, T.TUFF, T.TUFF, T.TUFF, T.TUFF, T.TUFF],
    [BlockType.BASALT]: [T.BASALT, T.BASALT, T.BASALT, T.BASALT, T.BASALT, T.BASALT],
    [BlockType.NETHERRACK]: [T.NETHERRACK, T.NETHERRACK, T.NETHERRACK, T.NETHERRACK, T.NETHERRACK, T.NETHERRACK],
    [BlockType.NETHER_BRICKS]: [T.NETHER_BRICKS, T.NETHER_BRICKS, T.NETHER_BRICKS, T.NETHER_BRICKS, T.NETHER_BRICKS, T.NETHER_BRICKS],
    [BlockType.SOUL_SAND]: [T.SOUL_SAND, T.SOUL_SAND, T.SOUL_SAND, T.SOUL_SAND, T.SOUL_SAND, T.SOUL_SAND],
    [BlockType.QUARTZ_BLOCK]: [T.QUARTZ_BLOCK, T.QUARTZ_BLOCK, T.QUARTZ_BLOCK, T.QUARTZ_BLOCK, T.QUARTZ_BLOCK, T.QUARTZ_BLOCK],
    [BlockType.PRISMARINE]: [T.PRISMARINE, T.PRISMARINE, T.PRISMARINE, T.PRISMARINE, T.PRISMARINE, T.PRISMARINE],
    [BlockType.SEA_LANTERN]: [T.SEA_LANTERN, T.SEA_LANTERN, T.SEA_LANTERN, T.SEA_LANTERN, T.SEA_LANTERN, T.SEA_LANTERN],
    [BlockType.RED_WOOL]: [T.RED_WOOL, T.RED_WOOL, T.RED_WOOL, T.RED_WOOL, T.RED_WOOL, T.RED_WOOL],
    [BlockType.BLUE_WOOL]: [T.BLUE_WOOL, T.BLUE_WOOL, T.BLUE_WOOL, T.BLUE_WOOL, T.BLUE_WOOL, T.BLUE_WOOL],
    [BlockType.GREEN_WOOL]: [T.GREEN_WOOL, T.GREEN_WOOL, T.GREEN_WOOL, T.GREEN_WOOL, T.GREEN_WOOL, T.GREEN_WOOL],
    [BlockType.YELLOW_WOOL]: [T.YELLOW_WOOL, T.YELLOW_WOOL, T.YELLOW_WOOL, T.YELLOW_WOOL, T.YELLOW_WOOL, T.YELLOW_WOOL],
    [BlockType.PURPLE_WOOL]: [T.PURPLE_WOOL, T.PURPLE_WOOL, T.PURPLE_WOOL, T.PURPLE_WOOL, T.PURPLE_WOOL, T.PURPLE_WOOL],
    [BlockType.ORANGE_WOOL]: [T.ORANGE_WOOL, T.ORANGE_WOOL, T.ORANGE_WOOL, T.ORANGE_WOOL, T.ORANGE_WOOL, T.ORANGE_WOOL],
    [BlockType.WHITE_WOOL]: [T.WHITE_WOOL, T.WHITE_WOOL, T.WHITE_WOOL, T.WHITE_WOOL, T.WHITE_WOOL, T.WHITE_WOOL],
    [BlockType.BLACK_WOOL]: [T.BLACK_WOOL, T.BLACK_WOOL, T.BLACK_WOOL, T.BLACK_WOOL, T.BLACK_WOOL, T.BLACK_WOOL],
    [BlockType.TERRACOTTA]: [T.TERRACOTTA, T.TERRACOTTA, T.TERRACOTTA, T.TERRACOTTA, T.TERRACOTTA, T.TERRACOTTA],
    [BlockType.TARGET_BLOCK]: [T.TARGET_BLOCK, T.TARGET_BLOCK, T.TARGET_BLOCK, T.TARGET_BLOCK, T.TARGET_BLOCK, T.TARGET_BLOCK],
    [BlockType.POPPY]: [T.POPPY, T.POPPY, T.POPPY, T.POPPY, T.POPPY, T.POPPY],
    [BlockType.DANDELION]: [T.DANDELION, T.DANDELION, T.DANDELION, T.DANDELION, T.DANDELION, T.DANDELION],
    [BlockType.SHORT_GRASS]: [T.SHORT_GRASS, T.SHORT_GRASS, T.SHORT_GRASS, T.SHORT_GRASS, T.SHORT_GRASS, T.SHORT_GRASS],
    [BlockType.TALL_GRASS]: [T.TALL_GRASS, T.TALL_GRASS, T.TALL_GRASS, T.TALL_GRASS, T.TALL_GRASS, T.TALL_GRASS],
    [BlockType.RED_MUSHROOM]: [T.RED_MUSHROOM, T.RED_MUSHROOM, T.RED_MUSHROOM, T.RED_MUSHROOM, T.RED_MUSHROOM, T.RED_MUSHROOM],
    [BlockType.BROWN_MUSHROOM]: [T.BROWN_MUSHROOM, T.BROWN_MUSHROOM, T.BROWN_MUSHROOM, T.BROWN_MUSHROOM, T.BROWN_MUSHROOM, T.BROWN_MUSHROOM],
    [BlockType.SPRUCE_LOG]: [T.SPRUCE_LOG_SIDE, T.SPRUCE_LOG_SIDE, T.SPRUCE_LOG_TOP, T.SPRUCE_LOG_TOP, T.SPRUCE_LOG_SIDE, T.SPRUCE_LOG_SIDE],
    [BlockType.SPRUCE_LEAVES]: [T.SPRUCE_LEAVES, T.SPRUCE_LEAVES, T.SPRUCE_LEAVES, T.SPRUCE_LEAVES, T.SPRUCE_LEAVES, T.SPRUCE_LEAVES],
    [BlockType.SPRUCE_PLANKS]: [T.SPRUCE_PLANKS, T.SPRUCE_PLANKS, T.SPRUCE_PLANKS, T.SPRUCE_PLANKS, T.SPRUCE_PLANKS, T.SPRUCE_PLANKS],
    [BlockType.JUNGLE_LOG]: [T.JUNGLE_LOG_SIDE, T.JUNGLE_LOG_SIDE, T.JUNGLE_LOG_TOP, T.JUNGLE_LOG_TOP, T.JUNGLE_LOG_SIDE, T.JUNGLE_LOG_SIDE],
    [BlockType.JUNGLE_LEAVES]: [T.JUNGLE_LEAVES, T.JUNGLE_LEAVES, T.JUNGLE_LEAVES, T.JUNGLE_LEAVES, T.JUNGLE_LEAVES, T.JUNGLE_LEAVES],
    [BlockType.JUNGLE_PLANKS]: [T.JUNGLE_PLANKS, T.JUNGLE_PLANKS, T.JUNGLE_PLANKS, T.JUNGLE_PLANKS, T.JUNGLE_PLANKS, T.JUNGLE_PLANKS],
    [BlockType.ACACIA_LOG]: [T.ACACIA_LOG_SIDE, T.ACACIA_LOG_SIDE, T.ACACIA_LOG_TOP, T.ACACIA_LOG_TOP, T.ACACIA_LOG_SIDE, T.ACACIA_LOG_SIDE],
    [BlockType.ACACIA_LEAVES]: [T.ACACIA_LEAVES, T.ACACIA_LEAVES, T.ACACIA_LEAVES, T.ACACIA_LEAVES, T.ACACIA_LEAVES, T.ACACIA_LEAVES],
    [BlockType.ACACIA_PLANKS]: [T.ACACIA_PLANKS, T.ACACIA_PLANKS, T.ACACIA_PLANKS, T.ACACIA_PLANKS, T.ACACIA_PLANKS, T.ACACIA_PLANKS],

    // --- House Building & Special Blocks ---
    [BlockType.OAK_STAIRS]: [T.OAK_PLANKS, T.OAK_PLANKS, T.OAK_PLANKS, T.OAK_PLANKS, T.OAK_PLANKS, T.OAK_PLANKS],
    [BlockType.SPRUCE_STAIRS]: [T.SPRUCE_PLANKS, T.SPRUCE_PLANKS, T.SPRUCE_PLANKS, T.SPRUCE_PLANKS, T.SPRUCE_PLANKS, T.SPRUCE_PLANKS],
    [BlockType.COBBLESTONE_STAIRS]: [T.COBBLESTONE, T.COBBLESTONE, T.COBBLESTONE, T.COBBLESTONE, T.COBBLESTONE, T.COBBLESTONE],
    [BlockType.BRICK_STAIRS]: [T.BRICK, T.BRICK, T.BRICK, T.BRICK, T.BRICK, T.BRICK],
    [BlockType.STONE_BRICK_STAIRS]: [T.STONE_BRICKS, T.STONE_BRICKS, T.STONE_BRICKS, T.STONE_BRICKS, T.STONE_BRICKS, T.STONE_BRICKS],
    [BlockType.QUARTZ_STAIRS]: [T.QUARTZ_BLOCK, T.QUARTZ_BLOCK, T.QUARTZ_BLOCK, T.QUARTZ_BLOCK, T.QUARTZ_BLOCK, T.QUARTZ_BLOCK],
    [BlockType.OAK_SLAB]: [T.OAK_PLANKS, T.OAK_PLANKS, T.OAK_PLANKS, T.OAK_PLANKS, T.OAK_PLANKS, T.OAK_PLANKS],
    [BlockType.SPRUCE_SLAB]: [T.SPRUCE_PLANKS, T.SPRUCE_PLANKS, T.SPRUCE_PLANKS, T.SPRUCE_PLANKS, T.SPRUCE_PLANKS, T.SPRUCE_PLANKS],
    [BlockType.COBBLESTONE_SLAB]: [T.COBBLESTONE, T.COBBLESTONE, T.COBBLESTONE, T.COBBLESTONE, T.COBBLESTONE, T.COBBLESTONE],
    [BlockType.BRICK_SLAB]: [T.BRICK, T.BRICK, T.BRICK, T.BRICK, T.BRICK, T.BRICK],
    [BlockType.STONE_BRICK_SLAB]: [T.STONE_BRICKS, T.STONE_BRICKS, T.STONE_BRICKS, T.STONE_BRICKS, T.STONE_BRICKS, T.STONE_BRICKS],
    [BlockType.QUARTZ_SLAB]: [T.QUARTZ_BLOCK, T.QUARTZ_BLOCK, T.QUARTZ_BLOCK, T.QUARTZ_BLOCK, T.QUARTZ_BLOCK, T.QUARTZ_BLOCK],
    [BlockType.SMOOTH_STONE_SLAB]: [T.SMOOTH_STONE, T.SMOOTH_STONE, T.SMOOTH_STONE, T.SMOOTH_STONE, T.SMOOTH_STONE, T.SMOOTH_STONE],
    [BlockType.OAK_FENCE]: [T.OAK_PLANKS, T.OAK_PLANKS, T.OAK_PLANKS, T.OAK_PLANKS, T.OAK_PLANKS, T.OAK_PLANKS],
    [BlockType.SPRUCE_FENCE]: [T.SPRUCE_PLANKS, T.SPRUCE_PLANKS, T.SPRUCE_PLANKS, T.SPRUCE_PLANKS, T.SPRUCE_PLANKS, T.SPRUCE_PLANKS],
    [BlockType.NETHER_BRICK_FENCE]: [T.NETHER_BRICKS, T.NETHER_BRICKS, T.NETHER_BRICKS, T.NETHER_BRICKS, T.NETHER_BRICKS, T.NETHER_BRICKS],
    [BlockType.COBBLESTONE_WALL]: [T.COBBLESTONE, T.COBBLESTONE, T.COBBLESTONE, T.COBBLESTONE, T.COBBLESTONE, T.COBBLESTONE],
    [BlockType.STONE_BRICK_WALL]: [T.STONE_BRICKS, T.STONE_BRICKS, T.STONE_BRICKS, T.STONE_BRICKS, T.STONE_BRICKS, T.STONE_BRICKS],
    [BlockType.BRICK_WALL]: [T.BRICK, T.BRICK, T.BRICK, T.BRICK, T.BRICK, T.BRICK],
    [BlockType.OAK_DOOR]: [T.OAK_PLANKS, T.OAK_PLANKS, T.OAK_PLANKS, T.OAK_PLANKS, T.OAK_PLANKS, T.OAK_PLANKS],
    [BlockType.SPRUCE_DOOR]: [T.SPRUCE_PLANKS, T.SPRUCE_PLANKS, T.SPRUCE_PLANKS, T.SPRUCE_PLANKS, T.SPRUCE_PLANKS, T.SPRUCE_PLANKS],
    [BlockType.OAK_TRAPDOOR]: [T.OAK_PLANKS, T.OAK_PLANKS, T.OAK_PLANKS, T.OAK_PLANKS, T.OAK_PLANKS, T.OAK_PLANKS],
    [BlockType.GLASS_PANE]: [T.GLASS, T.GLASS, T.GLASS, T.GLASS, T.GLASS, T.GLASS],
    [BlockType.LANTERN]: [T.GLOWSTONE, T.GLOWSTONE, T.GLOWSTONE, T.GLOWSTONE, T.GLOWSTONE, T.GLOWSTONE],
    [BlockType.CHEST]: [T.CRAFTING_SIDE, T.CRAFTING_SIDE, T.OAK_PLANKS, T.OAK_PLANKS, T.CRAFTING_SIDE, T.CRAFTING_SIDE],
    [BlockType.FURNACE]: [T.COBBLESTONE, T.COBBLESTONE, T.SMOOTH_STONE, T.SMOOTH_STONE, T.COBBLESTONE, T.COBBLESTONE],
    [BlockType.QUARTZ_PILLAR]: [T.QUARTZ_BLOCK, T.QUARTZ_BLOCK, T.QUARTZ_BLOCK, T.QUARTZ_BLOCK, T.QUARTZ_BLOCK, T.QUARTZ_BLOCK],
    [BlockType.CHISELED_QUARTZ]: [T.QUARTZ_BLOCK, T.QUARTZ_BLOCK, T.QUARTZ_BLOCK, T.QUARTZ_BLOCK, T.QUARTZ_BLOCK, T.QUARTZ_BLOCK],
    [BlockType.PURPUR_BLOCK]: [T.PURPLE_WOOL, T.PURPLE_WOOL, T.PURPLE_WOOL, T.PURPLE_WOOL, T.PURPLE_WOOL, T.PURPLE_WOOL],
    [BlockType.DEEPSLATE_BRICKS]: [T.DEEPSLATE, T.DEEPSLATE, T.DEEPSLATE, T.DEEPSLATE, T.DEEPSLATE, T.DEEPSLATE],
    [BlockType.POLISHED_GRANITE]: [T.GRANITE, T.GRANITE, T.GRANITE, T.GRANITE, T.GRANITE, T.GRANITE],
    [BlockType.POLISHED_DIORITE]: [T.DIORITE, T.DIORITE, T.DIORITE, T.DIORITE, T.DIORITE, T.DIORITE],
    [BlockType.POLISHED_ANDESITE]: [T.ANDESITE, T.ANDESITE, T.ANDESITE, T.ANDESITE, T.ANDESITE, T.ANDESITE],
    [BlockType.WHITE_CONCRETE]: [T.WHITE_WOOL, T.WHITE_WOOL, T.WHITE_WOOL, T.WHITE_WOOL, T.WHITE_WOOL, T.WHITE_WOOL],
    [BlockType.BLACK_CONCRETE]: [T.BLACK_WOOL, T.BLACK_WOOL, T.BLACK_WOOL, T.BLACK_WOOL, T.BLACK_WOOL, T.BLACK_WOOL],
    [BlockType.GRAY_CONCRETE]: [T.BLACK_WOOL, T.BLACK_WOOL, T.BLACK_WOOL, T.BLACK_WOOL, T.BLACK_WOOL, T.BLACK_WOOL],
    [BlockType.RED_CONCRETE]: [T.RED_WOOL, T.RED_WOOL, T.RED_WOOL, T.RED_WOOL, T.RED_WOOL, T.RED_WOOL],
    [BlockType.BLUE_CONCRETE]: [T.BLUE_WOOL, T.BLUE_WOOL, T.BLUE_WOOL, T.BLUE_WOOL, T.BLUE_WOOL, T.BLUE_WOOL],
    [BlockType.YELLOW_CONCRETE]: [T.YELLOW_WOOL, T.YELLOW_WOOL, T.YELLOW_WOOL, T.YELLOW_WOOL, T.YELLOW_WOOL, T.YELLOW_WOOL],
    [BlockType.GREEN_CONCRETE]: [T.GREEN_WOOL, T.GREEN_WOOL, T.GREEN_WOOL, T.GREEN_WOOL, T.GREEN_WOOL, T.GREEN_WOOL],
    [BlockType.CYAN_CONCRETE]: [T.BLUE_WOOL, T.BLUE_WOOL, T.BLUE_WOOL, T.BLUE_WOOL, T.BLUE_WOOL, T.BLUE_WOOL],
    [BlockType.ORANGE_CONCRETE]: [T.ORANGE_WOOL, T.ORANGE_WOOL, T.ORANGE_WOOL, T.ORANGE_WOOL, T.ORANGE_WOOL, T.ORANGE_WOOL],
    [BlockType.PINK_CONCRETE]: [T.RED_WOOL, T.RED_WOOL, T.RED_WOOL, T.RED_WOOL, T.RED_WOOL, T.RED_WOOL],
    [BlockType.PURPLE_CONCRETE]: [T.PURPLE_WOOL, T.PURPLE_WOOL, T.PURPLE_WOOL, T.PURPLE_WOOL, T.PURPLE_WOOL, T.PURPLE_WOOL],
    [BlockType.LIGHT_BLUE_WOOL]: [T.BLUE_WOOL, T.BLUE_WOOL, T.BLUE_WOOL, T.BLUE_WOOL, T.BLUE_WOOL, T.BLUE_WOOL],
    [BlockType.LIME_WOOL]: [T.GREEN_WOOL, T.GREEN_WOOL, T.GREEN_WOOL, T.GREEN_WOOL, T.GREEN_WOOL, T.GREEN_WOOL],
    [BlockType.PINK_WOOL]: [T.RED_WOOL, T.RED_WOOL, T.RED_WOOL, T.RED_WOOL, T.RED_WOOL, T.RED_WOOL],
    [BlockType.GRAY_WOOL]: [T.BLACK_WOOL, T.BLACK_WOOL, T.BLACK_WOOL, T.BLACK_WOOL, T.BLACK_WOOL, T.BLACK_WOOL],
    [BlockType.CYAN_WOOL]: [T.BLUE_WOOL, T.BLUE_WOOL, T.BLUE_WOOL, T.BLUE_WOOL, T.BLUE_WOOL, T.BLUE_WOOL],
    [BlockType.MAGENTA_WOOL]: [T.PURPLE_WOOL, T.PURPLE_WOOL, T.PURPLE_WOOL, T.PURPLE_WOOL, T.PURPLE_WOOL, T.PURPLE_WOOL],
  };

  const getBlockFaceTileId = (blockType: BlockType, faceIndex: number): number => {
    const map = FACE_TILE_MAP[blockType];
    if (map && map[faceIndex] !== undefined) return map[faceIndex];
    const conf = BLOCK_REGISTRY[blockType];
    if (conf?.baseBlock && FACE_TILE_MAP[conf.baseBlock]) {
      return FACE_TILE_MAP[conf.baseBlock][faceIndex] ?? T.DIRT;
    }
    return T.DIRT;
  };

  // Materials map for UI hand held item or break particles
  const materialsMap: Record<BlockType, THREE.Material> = {} as any;
  for (let id = 1; id <= 250; id++) {
    const config = BLOCK_REGISTRY[id as BlockType];
    if (config) {
      materialsMap[id as BlockType] = config.isTransparent ? transparentMaterial : opaqueMaterial;
    }
  }

  cachedAtlas = {
    texture,
    opaqueMaterial,
    transparentMaterial,
    materialsMap,
    getTileUVs,
    getBlockFaceTileId,
  };

  return cachedAtlas;
}

// Retain legacy helpers for backwards compat
export function generateBlockTextures() {
  return {};
}

export function createBlockMaterials(_textures: any) {
  const atlas = getTextureAtlas();
  return atlas.materialsMap;
}
