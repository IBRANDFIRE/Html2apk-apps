import React, { useEffect, useRef, useCallback, useImperativeHandle, forwardRef } from 'react';
import * as THREE from 'three';
import { BlockType, PlayerState, RaycastHit, GameSettings, BlockFacing } from '../types';
import { BLOCK_REGISTRY } from '../game/blocks';
import { VoxelWorld, CHUNK_SIZE_X, CHUNK_SIZE_Z } from '../game/world';
import { generateBlockTextures, createBlockMaterials, getTextureAtlas } from '../game/textures';

function updateHeldBlockUVs(geometry: THREE.BoxGeometry, blockType: BlockType) {
  const atlas = getTextureAtlas();
  const uvAttr = geometry.getAttribute('uv') as THREE.BufferAttribute;
  if (!uvAttr) return;

  // Add white vertex colors attribute required by MeshLambertMaterial (vertexColors: true)
  let colorAttr = geometry.getAttribute('color') as THREE.BufferAttribute;
  if (!colorAttr || colorAttr.count !== geometry.getAttribute('position').count) {
    const posCount = geometry.getAttribute('position').count;
    const colors = new Float32Array(posCount * 3);
    colors.fill(1.0);
    colorAttr = new THREE.BufferAttribute(colors, 3);
    geometry.setAttribute('color', colorAttr);
  } else {
    const colors = colorAttr.array as Float32Array;
    colors.fill(1.0);
    colorAttr.needsUpdate = true;
  }

  const uvs = uvAttr.array as Float32Array;

  // BoxGeometry face order: 0:+X, 1:-X, 2:+Y, 3:-Y, 4:+Z, 5:-Z
  for (let faceIdx = 0; faceIdx < 6; faceIdx++) {
    const tileId = atlas.getBlockFaceTileId(blockType, faceIdx);
    const [u0, v0, u1, v1] = atlas.getTileUVs(tileId);

    const offset = faceIdx * 8;
    uvs[offset + 0] = u0; uvs[offset + 1] = v1;
    uvs[offset + 2] = u0; uvs[offset + 3] = v0;
    uvs[offset + 4] = u1; uvs[offset + 5] = v1;
    uvs[offset + 6] = u1; uvs[offset + 7] = v0;
  }
  uvAttr.needsUpdate = true;
}
import { soundManager } from '../game/audio';
import { fastVoxelRaycast } from '../game/raycast';
import { PlayerPhysics, MovementInput } from '../game/physics';
import { MobManager } from '../game/mobs';

export interface VoxelCanvasHandle {
  applyLookDelta: (deltaYaw: number, deltaPitch: number) => void;
  setPlayerState: (updater: (prev: PlayerState) => PlayerState) => void;
  getPlayerState: () => PlayerState;
  toggleFly: () => boolean;
  teleport: (x: number, y: number, z: number) => void;
  breakBlock: () => void;
  placeBlock: () => void;
  startMining: () => void;
  stopMining: () => void;
  startPlacing: () => void;
  stopPlacing: () => void;
  interactAtScreenCoord: (screenX: number, screenY: number, mode?: 'place' | 'break' | 'auto') => void;
}

interface VoxelCanvasProps {
  worldData: {
    seed: number;
    worldType: 'default' | 'flat' | 'plains' | 'mountains' | 'amplified' | 'desert' | 'islands';
    modifiedBlocks: Record<string, Record<string, BlockType>>;
    timeOfDay: number;
  };
  initialPlayer: PlayerState;
  movementInputRef: React.MutableRefObject<MovementInput>;
  activeBlock: BlockType;
  settings: GameSettings;
  onBlockChange: (x: number, y: number, z: number, newType: BlockType, isBreak: boolean) => void;
  onTargetBlockChange: (hit: RaycastHit | null) => void;
  onPointerLockChange: (isLocked: boolean) => void;
  onPlayerSync?: (player: PlayerState, timeOfDay: number) => void;
  onFpsUpdate?: (fps: number) => void;
  actionTrigger?: { type: 'break' | 'place'; timestamp: number } | null;
  onRegisterWorld?: (world: VoxelWorld) => void;
  onCollectItem?: (blockType: BlockType, count: number) => void;
}

export const VoxelCanvas = forwardRef<VoxelCanvasHandle, VoxelCanvasProps>(({
  worldData,
  initialPlayer,
  movementInputRef,
  activeBlock,
  settings,
  onBlockChange,
  onTargetBlockChange,
  onPointerLockChange,
  onPlayerSync,
  onFpsUpdate,
  actionTrigger,
  onRegisterWorld,
  onCollectItem,
}, ref) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const worldRef = useRef<VoxelWorld | null>(null);
  const mobManagerRef = useRef<MobManager | null>(null);

  const onCollectItemRef = useRef(onCollectItem);
  useEffect(() => {
    onCollectItemRef.current = onCollectItem;
  }, [onCollectItem]);

  // Lighting refs
  const sunLightRef = useRef<THREE.DirectionalLight | null>(null);
  const ambientLightRef = useRef<THREE.AmbientLight | null>(null);
  const sunMeshRef = useRef<THREE.Mesh | null>(null);
  const moonMeshRef = useRef<THREE.Mesh | null>(null);

  // Selection outline box
  const selectionBoxRef = useRef<THREE.LineSegments | null>(null);

  // Hand item model
  const handMeshRef = useRef<THREE.Mesh | null>(null);
  const handSwingAnimRef = useRef<number>(0);

  // Particle systems for block breaking
  const particlesRef = useRef<{ mesh: THREE.InstancedMesh; velocities: THREE.Vector3[]; life: number }[]>([]);

  // Clouds layer
  const cloudsMeshRef = useRef<THREE.Mesh | null>(null);

  const materialsRef = useRef<Record<BlockType, THREE.Material | THREE.Material[]> | null>(null);

  // High-performance state stored in refs for 60+ FPS zero-re-render simulation
  const playerRef = useRef<PlayerState>({ ...initialPlayer });
  const physicsRef = useRef(new PlayerPhysics());
  const timeOfDayRef = useRef<number>(worldData.timeOfDay);
  const currentHitRef = useRef<RaycastHit | null>(null);
  const lastChunkRef = useRef<{ cx: number; cz: number }>({ cx: 999999, cz: 999999 });

  // Reused objects to avoid memory allocations and garbage collection hitches
  const cameraDirRef = useRef(new THREE.Vector3());
  const skyColorRef = useRef(new THREE.Color('#78a7ff'));
  const whiteColorRef = useRef(new THREE.Color('#ffffff'));
  const tempEulerRef = useRef(new THREE.Euler(0, 0, 0, 'YXZ'));

  // Active block ref for handlePlace without recreating callbacks
  const activeBlockRef = useRef(activeBlock);
  useEffect(() => {
    activeBlockRef.current = activeBlock;
  }, [activeBlock]);

  // Settings ref
  const settingsRef = useRef(settings);
  useEffect(() => {
    settingsRef.current = settings;
    if (cameraRef.current && cameraRef.current.fov !== settings.fov) {
      cameraRef.current.fov = settings.fov;
      cameraRef.current.updateProjectionMatrix();
    }
  }, [settings]);

  // Continuous mining & placing state
  const isMiningRef = useRef(false);
  const isPlacingRef = useRef(false);
  const mineCooldownRef = useRef(0);
  const placeCooldownRef = useRef(0);

  // Update initialPlayer if world reloaded
  useEffect(() => {
    playerRef.current = { ...initialPlayer };
    timeOfDayRef.current = worldData.timeOfDay;
  }, [worldData.seed, worldData.worldType]);

  // Apply look delta directly to playerRef and camera
  const applyLookDelta = useCallback((deltaYaw: number, deltaPitch: number) => {
    if (!cameraRef.current) return;
    const p = playerRef.current;
    p.yaw += deltaYaw;
    const maxPitch = Math.PI / 2 - 0.05;
    const minPitch = -Math.PI / 2 + 0.05;
    p.pitch = Math.max(minPitch, Math.min(maxPitch, p.pitch + deltaPitch));

    tempEulerRef.current.set(p.pitch, p.yaw, 0, 'YXZ');
    cameraRef.current.quaternion.setFromEuler(tempEulerRef.current);
  }, []);

  // Spawn visual break particles
  const spawnBreakParticles = (bx: number, by: number, bz: number, blockType: BlockType) => {
    if (!sceneRef.current || !materialsRef.current) return;
    const mat = materialsRef.current[blockType] || materialsRef.current[BlockType.DIRT];
    const particleCount = 8;
    const pGeo = new THREE.BoxGeometry(0.12, 0.12, 0.12);
    const pMesh = new THREE.InstancedMesh(pGeo, Array.isArray(mat) ? mat[0] : mat, particleCount);

    const dummy = new THREE.Matrix4();
    const velocities: THREE.Vector3[] = [];

    for (let i = 0; i < particleCount; i++) {
      const px = bx + 0.5 + (Math.random() - 0.5) * 0.6;
      const py = by + 0.5 + (Math.random() - 0.5) * 0.6;
      const pz = bz + 0.5 + (Math.random() - 0.5) * 0.6;
      dummy.setPosition(px, py, pz);
      pMesh.setMatrixAt(i, dummy);

      velocities.push(
        new THREE.Vector3(
          (Math.random() - 0.5) * 4,
          Math.random() * 3.5 + 1.5,
          (Math.random() - 0.5) * 4
        )
      );
    }
    pMesh.instanceMatrix.needsUpdate = true;
    sceneRef.current.add(pMesh);
    particlesRef.current.push({ mesh: pMesh, velocities, life: 0.8 });
  };

  // Trigger TNT explosion with chain reaction
  const explodeTNT = (centerX: number, centerY: number, centerZ: number) => {
    if (!worldRef.current) return;
    soundManager.playExplosion();

    const radius = 3;
    const chainTNTs: [number, number, number][] = [];

    for (let ox = -radius; ox <= radius; ox++) {
      for (let oy = -radius; oy <= radius; oy++) {
        for (let oz = -radius; oz <= radius; oz++) {
          const dist = Math.hypot(ox, oy, oz);
          if (dist <= radius) {
            const tx = centerX + ox;
            const ty = centerY + oy;
            const tz = centerZ + oz;
            const currentBlock = worldRef.current.getBlock(tx, ty, tz);
            if (currentBlock !== BlockType.AIR && currentBlock !== BlockType.BEDROCK) {
              if (currentBlock === BlockType.TNT && (ox !== 0 || oy !== 0 || oz !== 0)) {
                chainTNTs.push([tx, ty, tz]);
              }
              worldRef.current.setBlock(tx, ty, tz, BlockType.AIR);
              onBlockChange(tx, ty, tz, currentBlock, true);
              if (Math.random() > 0.4) {
                spawnBreakParticles(tx, ty, tz, currentBlock);
              }
            }
          }
        }
      }
    }

    // Trigger chain explosions
    chainTNTs.forEach(([cx, cy, cz], idx) => {
      setTimeout(() => {
        explodeTNT(cx, cy, cz);
      }, (idx + 1) * 120);
    });
  };

  // Handle breaking targeted block / hitting mobs
  const handleBreak = useCallback(() => {
    // Check if player hit a mob first
    if (mobManagerRef.current && cameraRef.current) {
      cameraRef.current.getWorldDirection(cameraDirRef.current);
      const hitMob = mobManagerRef.current.checkHitMob(cameraRef.current.position, cameraDirRef.current, 4.5);
      if (hitMob) {
        handSwingAnimRef.current = 1.0;
        return;
      }
    }

    const hit = currentHitRef.current;
    if (!hit || !worldRef.current) return;

    const [bx, by, bz] = hit.blockPos;
    if (hit.blockType === BlockType.BEDROCK) return;

    if (hit.blockType === BlockType.TNT) {
      explodeTNT(bx, by, bz);
      return;
    }

    handSwingAnimRef.current = 1.0;
    const config = BLOCK_REGISTRY[hit.blockType];
    soundManager.playBlockBreak(config?.soundType || 'stone');
    spawnBreakParticles(bx, by, bz, hit.blockType);

    const brokenType = hit.blockType;
    worldRef.current.setBlock(bx, by, bz, BlockType.AIR);
    onBlockChange(bx, by, bz, brokenType, true);
  }, [onBlockChange]);

  // Handle placing active block
  const handlePlace = useCallback(() => {
    const hit = currentHitRef.current;
    const currentActiveBlock = activeBlockRef.current;
    if (!hit || !worldRef.current) return;

    const [bx, by, bz] = hit.blockPos;
    const [nx, ny, nz] = hit.normal;

    const targetBlock = worldRef.current.getBlock(bx, by, bz);
    const targetConf = BLOCK_REGISTRY[targetBlock];

    // 1. Interactive Door Toggle (Open / Close)
    if (targetConf?.shape === 'door') {
      const isCurrentlyOpen = !!targetConf.isOpen;
      const baseBlock = targetConf.baseBlock || (isCurrentlyOpen ? BlockType.OAK_DOOR : targetBlock);
      const facingDir = targetConf.facing || 'N';
      const isSpruce = baseBlock === BlockType.SPRUCE_DOOR || targetBlock >= BlockType.SPRUCE_DOOR;
      const baseName = isSpruce ? 'SPRUCE_DOOR' : 'OAK_DOOR';

      let nextBlock: BlockType;
      if (isCurrentlyOpen) {
        const closeKey = `${baseName}_${facingDir}` as keyof typeof BlockType;
        nextBlock = BlockType[closeKey] || (isSpruce ? BlockType.SPRUCE_DOOR : BlockType.OAK_DOOR);
      } else {
        const openKey = `${baseName}_OPEN_${facingDir}` as keyof typeof BlockType;
        nextBlock = BlockType[openKey] || (isSpruce ? BlockType.SPRUCE_DOOR_OPEN : BlockType.OAK_DOOR_OPEN);
      }

      worldRef.current.setBlock(bx, by, bz, nextBlock);
      onBlockChange(bx, by, bz, nextBlock, false);
      soundManager.playDoorToggle(!isCurrentlyOpen);
      handSwingAnimRef.current = 1.0;
      return;
    }

    // 2. Interactive Trapdoor Toggle (Open / Close)
    if (targetConf?.shape === 'trapdoor') {
      const isCurrentlyOpen = !!targetConf.isOpen;
      const nextBlock = isCurrentlyOpen ? BlockType.OAK_TRAPDOOR : BlockType.OAK_TRAPDOOR_OPEN;
      worldRef.current.setBlock(bx, by, bz, nextBlock);
      onBlockChange(bx, by, bz, nextBlock, false);
      soundManager.playDoorToggle(!isCurrentlyOpen);
      handSwingAnimRef.current = 1.0;
      return;
    }

    if (currentActiveBlock === BlockType.AIR) return;

    const placeX = bx + nx;
    const placeY = by + ny;
    const placeZ = bz + nz;

    const p = playerRef.current;
    const pMinX = p.x - 0.3;
    const pMaxX = p.x + 0.3;
    const pMinY = p.y;
    const pMaxY = p.y + 1.8;
    const pMinZ = p.z - 0.3;
    const pMaxZ = p.z + 0.3;

    const blockMinX = placeX;
    const blockMaxX = placeX + 1;
    const blockMinY = placeY;
    const blockMaxY = placeY + 1;
    const blockMinZ = placeZ;
    const blockMaxZ = placeZ + 1;

    const overlapsPlayer =
      pMaxX > blockMinX &&
      pMinX < blockMaxX &&
      pMaxY > blockMinY &&
      pMinY < blockMaxY &&
      pMaxZ > blockMinZ &&
      pMinZ < blockMaxZ;

    if (overlapsPlayer) return;

    handSwingAnimRef.current = 1.0;
    const activeConf = BLOCK_REGISTRY[currentActiveBlock];

    // Calculate facing direction (N, S, E, W) from camera look vector
    let facing: BlockFacing = 'N';
    if (cameraRef.current) {
      const dir = cameraRef.current.getWorldDirection(cameraDirRef.current);
      if (Math.abs(dir.x) > Math.abs(dir.z)) {
        facing = dir.x > 0 ? 'E' : 'W';
      } else {
        facing = dir.z > 0 ? 'S' : 'N';
      }
    }

    const hitPosY = hit.hitPos ? hit.hitPos[1] : (hit.blockPos[1] + 0.5);
    const isClickingTopHalf = ny < 0 || (ny === 0 && (hitPosY - Math.floor(hitPosY)) > 0.5);
    let blockToPlace = currentActiveBlock;

    // Resolve orientation variants
    if (activeConf?.shape === 'stairs') {
      const baseName = BlockType[currentActiveBlock];
      const variantKey = `${baseName}_${facing}${isClickingTopHalf ? '_UP' : ''}` as keyof typeof BlockType;
      if (BlockType[variantKey] !== undefined) {
        blockToPlace = BlockType[variantKey];
      }
    } else if (activeConf?.shape === 'slab') {
      // Double slab conversion when placing on an existing slab of the same type
      if (targetConf?.shape === 'slab' && (targetConf.baseBlock === currentActiveBlock || targetBlock === currentActiveBlock)) {
        let fullBlock = BlockType.OAK_PLANKS;
        if (currentActiveBlock === BlockType.COBBLESTONE_SLAB) fullBlock = BlockType.COBBLESTONE;
        else if (currentActiveBlock === BlockType.BRICK_SLAB) fullBlock = BlockType.BRICK;
        else if (currentActiveBlock === BlockType.STONE_BRICK_SLAB) fullBlock = BlockType.STONE_BRICKS;
        else if (currentActiveBlock === BlockType.QUARTZ_SLAB) fullBlock = BlockType.QUARTZ_BLOCK;
        else if (currentActiveBlock === BlockType.SMOOTH_STONE_SLAB) fullBlock = BlockType.SMOOTH_STONE;
        else if (currentActiveBlock === BlockType.SPRUCE_SLAB) fullBlock = BlockType.SPRUCE_PLANKS;

        worldRef.current.setBlock(bx, by, bz, fullBlock);
        onBlockChange(bx, by, bz, fullBlock, false);
        soundManager.playBlockPlace(activeConf.soundType || 'stone');
        return;
      }

      const variantKey = `${BlockType[currentActiveBlock]}_${isClickingTopHalf ? 'TOP' : 'BOT'}` as keyof typeof BlockType;
      if (BlockType[variantKey] !== undefined) {
        blockToPlace = BlockType[variantKey];
      }
    } else if (activeConf?.shape === 'door') {
      const variantKey = `${BlockType[currentActiveBlock]}_${facing}` as keyof typeof BlockType;
      if (BlockType[variantKey] !== undefined) {
        blockToPlace = BlockType[variantKey];
      }
    } else if (currentActiveBlock === BlockType.CHEST || currentActiveBlock === BlockType.FURNACE) {
      const variantKey = `${BlockType[currentActiveBlock]}_${facing}` as keyof typeof BlockType;
      if (BlockType[variantKey] !== undefined) {
        blockToPlace = BlockType[variantKey];
      }
    }

    const placeConfig = BLOCK_REGISTRY[blockToPlace] || activeConf;
    soundManager.playBlockPlace(placeConfig?.soundType || 'stone');

    worldRef.current.setBlock(placeX, placeY, placeZ, blockToPlace);
    onBlockChange(placeX, placeY, placeZ, blockToPlace, false);
  }, [onBlockChange]);

  // Expose imperative handle to parent
  useImperativeHandle(ref, () => ({
    applyLookDelta,
    setPlayerState: (updater) => {
      playerRef.current = updater(playerRef.current);
    },
    getPlayerState: () => ({ ...playerRef.current }),
    toggleFly: () => {
      playerRef.current.isFlying = !playerRef.current.isFlying;
      return playerRef.current.isFlying;
    },
    teleport: (x: number, y: number, z: number) => {
      playerRef.current.x = x;
      playerRef.current.y = y;
      playerRef.current.z = z;
      playerRef.current.isGrounded = false;
      if (cameraRef.current) {
        cameraRef.current.position.set(x, y + 1.62, z);
      }
    },
    breakBlock: handleBreak,
    placeBlock: handlePlace,
    startMining: () => {
      handleBreak();
      isMiningRef.current = true;
      mineCooldownRef.current = 0.28;
    },
    stopMining: () => {
      isMiningRef.current = false;
    },
    startPlacing: () => {
      handlePlace();
      isPlacingRef.current = true;
      placeCooldownRef.current = 0.28;
    },
    stopPlacing: () => {
      isPlacingRef.current = false;
    },
    interactAtScreenCoord: (screenX: number, screenY: number, mode: 'place' | 'break' | 'auto' = 'auto') => {
      if (!worldRef.current || !cameraRef.current || !rendererRef.current) return;
      const canvas = rendererRef.current.domElement;
      const rect = canvas.getBoundingClientRect();
      const ndcX = ((screenX - rect.left) / rect.width) * 2 - 1;
      const ndcY = -((screenY - rect.top) / rect.height) * 2 + 1;

      const screenRaycaster = new THREE.Raycaster();
      screenRaycaster.setFromCamera(new THREE.Vector2(ndcX, ndcY), cameraRef.current);
      const hit = fastVoxelRaycast(worldRef.current, screenRaycaster.ray.origin, screenRaycaster.ray.direction, 5.5);
      if (!hit) return;

      currentHitRef.current = hit;
      if (mode === 'break') {
        handleBreak();
      } else if (mode === 'place') {
        handlePlace();
      } else {
        if (activeBlockRef.current !== BlockType.AIR) {
          handlePlace();
        } else {
          handleBreak();
        }
      }
    },
  }), [applyLookDelta, handleBreak, handlePlace]);

  // Initialize Three.js scene & main game animation loop
  useEffect(() => {
    if (!containerRef.current) return;

    const width = containerRef.current.clientWidth || window.innerWidth || 800;
    const height = containerRef.current.clientHeight || window.innerHeight || 600;

    const scene = new THREE.Scene();
    sceneRef.current = scene;

    const initialSkyColor = new THREE.Color('#78a7ff');
    scene.background = initialSkyColor;

    const camera = new THREE.PerspectiveCamera(settings.fov, Math.max(0.1, width / height), 0.1, 1000);
    const px = 0;
    const pz = 0;
    const py = Number.isFinite(playerRef.current.y) ? playerRef.current.y : 28;
    camera.position.set(px, py + 1.62, pz);

    const initialPitch = Number.isFinite(playerRef.current.pitch) ? playerRef.current.pitch : 0;
    const initialYaw = Number.isFinite(playerRef.current.yaw) ? playerRef.current.yaw : 0;
    tempEulerRef.current.set(initialPitch, initialYaw, 0, 'YXZ');
    camera.quaternion.setFromEuler(tempEulerRef.current);
    cameraRef.current = camera;

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({
        antialias: false,
        alpha: false,
        powerPreference: 'high-performance',
        precision: 'mediump',
      });
      renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5));
      renderer.setSize(width, height);
      rendererRef.current = renderer;
    } catch (err) {
      console.error('Failed to create WebGLRenderer:', err);
      return;
    }

    renderer.domElement.style.position = 'absolute';
    renderer.domElement.style.top = '0';
    renderer.domElement.style.left = '0';
    renderer.domElement.style.width = '100%';
    renderer.domElement.style.height = '100%';
    renderer.domElement.style.display = 'block';

    while (containerRef.current.firstChild) {
      containerRef.current.removeChild(containerRef.current.firstChild);
    }
    containerRef.current.appendChild(renderer.domElement);

    // Fog for depth & render distance blend
    scene.fog = new THREE.FogExp2(initialSkyColor, 0.015);

    // Hemisphere light
    const hemiLight = new THREE.HemisphereLight('#b1e1ff', '#544028', 0.65);
    scene.add(hemiLight);

    // Ambient light
    const ambientLight = new THREE.AmbientLight('#ffffff', 0.6);
    scene.add(ambientLight);
    ambientLightRef.current = ambientLight;

    // Sun directional light
    const sunLight = new THREE.DirectionalLight('#fff8e7', 1.2);
    sunLight.position.set(40, 80, 30);
    scene.add(sunLight);
    sunLightRef.current = sunLight;

    // Sun & Moon celestial bodies
    const sunGeo = new THREE.PlaneGeometry(12, 12);
    const sunMat = new THREE.MeshBasicMaterial({ color: '#fff066', side: THREE.DoubleSide });
    const sunMesh = new THREE.Mesh(sunGeo, sunMat);
    scene.add(sunMesh);
    sunMeshRef.current = sunMesh;

    const moonGeo = new THREE.PlaneGeometry(9, 9);
    const moonMat = new THREE.MeshBasicMaterial({ color: '#e8ecf8', side: THREE.DoubleSide });
    const moonMesh = new THREE.Mesh(moonGeo, moonMat);
    scene.add(moonMesh);
    moonMeshRef.current = moonMesh;

    // Procedural 3D clouds
    const cloudsGeo = new THREE.PlaneGeometry(400, 400, 16, 16);
    const cloudsMat = new THREE.MeshBasicMaterial({
      color: '#ffffff',
      transparent: true,
      opacity: 0.65,
      side: THREE.DoubleSide,
    });
    const cloudsMesh = new THREE.Mesh(cloudsGeo, cloudsMat);
    cloudsMesh.rotation.x = Math.PI / 2;
    cloudsMesh.position.y = 38;
    scene.add(cloudsMesh);
    cloudsMeshRef.current = cloudsMesh;

    // Selection wireframe box
    const boxGeo = new THREE.BoxGeometry(1.005, 1.005, 1.005);
    const wireframeGeo = new THREE.WireframeGeometry(boxGeo);
    const lineMat = new THREE.LineBasicMaterial({ color: 0x000000, linewidth: 2 });
    const selectionBox = new THREE.LineSegments(wireframeGeo, lineMat);
    selectionBox.visible = false;
    scene.add(selectionBox);
    selectionBoxRef.current = selectionBox;

    // Textures & Materials
    const textures = generateBlockTextures();
    const materials = createBlockMaterials(textures);
    materialsRef.current = materials;

    // Voxel World
    const world = new VoxelWorld(
      scene,
      materials,
      worldData.seed,
      worldData.worldType,
      worldData.modifiedBlocks
    );
    worldRef.current = world;

    // Instantiate Mob Manager
    const mobManager = new MobManager(scene, world);
    mobManagerRef.current = mobManager;

    // Preload chunks around spawn smoothly
    world.updateLoadedChunks(px, pz, settings.renderDistance);
    world.processChunkQueue(25, 20);

    // Position player safely on terrain surface at (0, 0) coordinates
    const surfaceY = world.getHighestSolidY(0, 0);
    playerRef.current.x = 0;
    playerRef.current.z = 0;
    playerRef.current.y = surfaceY + 1.62;
    playerRef.current.isGrounded = true;
    camera.position.set(0, surfaceY + 1.62, 0);

    if (onRegisterWorld) {
      onRegisterWorld(world);
    }

    // Hand model in camera space
    const handGeo = new THREE.BoxGeometry(0.32, 0.32, 0.32);
    const handMat = materials[activeBlock] || materials[BlockType.GRASS];
    const handMesh = new THREE.Mesh(handGeo, handMat);
    handMesh.position.set(0.35, -0.32, -0.65);
    handMesh.rotation.set(0.2, -0.35, 0.1);
    camera.add(handMesh);
    scene.add(camera);
    handMeshRef.current = handMesh;

    // Render immediate initial frame
    try {
      renderer.render(scene, camera);
    } catch (e) {
      console.error('Initial frame render error:', e);
    }

    // Resize listener with ResizeObserver
    const handleResize = () => {
      if (!containerRef.current || !renderer || !camera) return;
      const w = containerRef.current.clientWidth || window.innerWidth || 800;
      const h = containerRef.current.clientHeight || window.innerHeight || 600;
      if (w > 0 && h > 0) {
        camera.aspect = w / h;
        camera.updateProjectionMatrix();
        renderer.setSize(w, h);
      }
    };
    window.addEventListener('resize', handleResize);
    const resizeObserver = new ResizeObserver(handleResize);
    resizeObserver.observe(containerRef.current);

    // ==========================================
    // UNIFIED HIGH-PERFORMANCE GAME & RENDER LOOP
    // ==========================================
    let animId: number;
    let lastTime = performance.now();
    let lastSyncTime = performance.now();
    let lastFpsTime = performance.now();
    let frameCount = 0;

    const animate = (time: number) => {
      animId = requestAnimationFrame(animate);
      const dt = Math.min((time - lastTime) / 1000, 0.05);
      lastTime = time;

      frameCount++;
      if (time - lastFpsTime >= 1000) {
        if (onFpsUpdate) onFpsUpdate(frameCount);
        frameCount = 0;
        lastFpsTime = time;
      }

      const p = playerRef.current;
      const curSettings = settingsRef.current;

      // 1. Advance Day / Night Cycle
      if (curSettings.dayNightSpeed > 0) {
        timeOfDayRef.current = (timeOfDayRef.current + dt * 20 * curSettings.dayNightSpeed) % 24000;
      }

      // 2. Physics & Player Movement
      if (worldRef.current && movementInputRef.current) {
        const res = physicsRef.current.update(p, movementInputRef.current, worldRef.current, dt);
        if (res.footstepTriggered) {
          soundManager.playFootstep(res.soundType);
        }
        if (res.flyToggled) {
          soundManager.playPop();
          if (onPlayerSync) {
            onPlayerSync({ ...playerRef.current }, timeOfDayRef.current);
          }
        }
      }

      // 3. Update Camera Position
      camera.position.set(p.x, p.y + 1.62, p.z);

      // 3.5. Update Mobs and Dropped Items
      if (mobManagerRef.current) {
        mobManagerRef.current.update(dt, p.x, p.y, p.z, (blockType, count) => {
          if (onCollectItemRef.current) {
            onCollectItemRef.current(blockType, count);
          }
        });
      }

      // 4. Update Sky, Atmosphere, Celestial Bodies
      const timeNorm = (((timeOfDayRef.current % 24000) + 24000) % 24000) / 24000;
      const angle = timeNorm * Math.PI * 2;
      const sunX = Math.cos(angle) * 120;
      const sunY = Math.sin(angle) * 120;
      const isDay = sunY > -10;

      if (sunLightRef.current) {
        sunLightRef.current.position.set(p.x + sunX, p.y + Math.max(15, sunY), p.z + 30);
        sunLightRef.current.intensity = isDay ? Math.min(1.3, Math.max(0.3, (sunY / 120) * 1.3)) : 0.15;
      }

      if (sunY >= 25) {
        skyColorRef.current.set('#78a7ff');
      } else if (sunY > -15) {
        skyColorRef.current.set('#ff8f5a');
      } else {
        skyColorRef.current.set('#141834');
      }

      scene.background = skyColorRef.current;
      renderer.setClearColor(skyColorRef.current, 1.0);

      // Underwater camera vision check
      const eyeY = p.y + 1.62;
      const eyeBlock = worldRef.current ? worldRef.current.getBlock(Math.floor(p.x), Math.floor(eyeY), Math.floor(p.z)) : BlockType.AIR;
      const isUnderwater = eyeBlock === BlockType.WATER;

      if (scene.fog) {
        if (isUnderwater) {
          scene.fog.color.setHex(0x194975);
          (scene.fog as THREE.FogExp2).density = 0.07;
        } else {
          scene.fog.color.copy(skyColorRef.current);
          (scene.fog as THREE.FogExp2).density = 0.015;
        }
      }
      if (ambientLightRef.current) {
        ambientLightRef.current.color.copy(skyColorRef.current).lerp(whiteColorRef.current, 0.55);
        ambientLightRef.current.intensity = isDay ? 0.75 : 0.45;
      }

      if (sunMeshRef.current) {
        sunMeshRef.current.position.set(p.x + sunX, p.y + sunY, p.z + 10);
        sunMeshRef.current.lookAt(camera.position);
        sunMeshRef.current.visible = sunY > -10;
      }
      if (moonMeshRef.current) {
        moonMeshRef.current.position.set(p.x - sunX, p.y - sunY, p.z + 10);
        moonMeshRef.current.lookAt(camera.position);
        moonMeshRef.current.visible = sunY < 10;
      }

      // Procedural Clouds drift across the sky with player position
      if (cloudsMeshRef.current) {
        cloudsMeshRef.current.visible = !!curSettings.cloudsEnabled;
        cloudsMeshRef.current.position.x = p.x + ((time * 0.003) % 200) - 100;
        cloudsMeshRef.current.position.z = p.z;
        cloudsMeshRef.current.position.y = 42;
      }

      // Dynamic Light Engine: Update sunLightFactor from time of day
      if (worldRef.current) {
        const computedFactor = isDay ? Math.min(1.0, Math.max(0.12, (sunY / 100) * 1.0)) : 0.08;
        if (Math.abs(worldRef.current.sunLightFactor - computedFactor) > 0.04) {
          worldRef.current.sunLightFactor = computedFactor;
        }
      }

      // 5. Ultra-Fast Voxel Raycast (Amanatides & Woo DDA, ~0.7 microseconds)
      if (worldRef.current) {
        camera.getWorldDirection(cameraDirRef.current);
        const hit = fastVoxelRaycast(worldRef.current, camera.position, cameraDirRef.current, 5.2);

        const prev = currentHitRef.current;
        const changed =
          (!prev && hit) ||
          (prev && !hit) ||
          (prev && hit && (
            prev.blockPos[0] !== hit.blockPos[0] ||
            prev.blockPos[1] !== hit.blockPos[1] ||
            prev.blockPos[2] !== hit.blockPos[2] ||
            prev.normal[0] !== hit.normal[0] ||
            prev.normal[1] !== hit.normal[1] ||
            prev.normal[2] !== hit.normal[2]
          ));

        if (changed) {
          currentHitRef.current = hit;
          onTargetBlockChange(hit);
        }

        if (hit && selectionBoxRef.current) {
          selectionBoxRef.current.position.set(hit.blockPos[0] + 0.5, hit.blockPos[1] + 0.5, hit.blockPos[2] + 0.5);
          selectionBoxRef.current.visible = true;
        } else if (selectionBoxRef.current) {
          selectionBoxRef.current.visible = false;
        }
      }

      // Continuous Mining / Placing while action is held
      if (isMiningRef.current) {
        mineCooldownRef.current -= dt;
        if (mineCooldownRef.current <= 0) {
          handleBreak();
          mineCooldownRef.current = 0.22;
        }
      }
      if (isPlacingRef.current) {
        placeCooldownRef.current -= dt;
        if (placeCooldownRef.current <= 0) {
          handlePlace();
          placeCooldownRef.current = 0.24;
        }
      }

      // 6. Dynamic Chunk Generation when crossing chunk boundaries
      if (worldRef.current) {
        const curCx = Math.floor(p.x / CHUNK_SIZE_X);
        const curCz = Math.floor(p.z / CHUNK_SIZE_Z);
        if (curCx !== lastChunkRef.current.cx || curCz !== lastChunkRef.current.cz) {
          lastChunkRef.current = { cx: curCx, cz: curCz };
          worldRef.current.updateLoadedChunks(p.x, p.z, curSettings.renderDistance);
        }
        worldRef.current.processChunkQueue(2);
      }

      // 7. Clouds drift
      if (cloudsMeshRef.current) {
        if (curSettings.cloudsEnabled) {
          cloudsMeshRef.current.position.x = (time * 0.002) % 400 - 200;
          cloudsMeshRef.current.visible = true;
        } else {
          cloudsMeshRef.current.visible = false;
        }
      }

      // 8. Hand Swing Animation
      if (handSwingAnimRef.current > 0) {
        handSwingAnimRef.current = Math.max(0, handSwingAnimRef.current - dt * 6);
        if (handMeshRef.current) {
          const swing = Math.sin(handSwingAnimRef.current * Math.PI);
          handMeshRef.current.position.set(0.35 - swing * 0.15, -0.32 + swing * 0.12, -0.65 - swing * 0.1);
          handMeshRef.current.rotation.set(0.2 - swing * 0.6, -0.35 + swing * 0.5, 0.1);
        }
      }

      // 9. Particle System Physics
      for (let i = particlesRef.current.length - 1; i >= 0; i--) {
        const part = particlesRef.current[i];
        part.life -= dt * 2.5;
        if (part.life <= 0) {
          scene.remove(part.mesh);
          part.mesh.geometry.dispose();
          particlesRef.current.splice(i, 1);
        } else {
          const dummy = new THREE.Matrix4();
          const pos = new THREE.Vector3();
          const count = part.velocities.length;
          for (let j = 0; j < count; j++) {
            part.mesh.getMatrixAt(j, dummy);
            pos.setFromMatrixPosition(dummy);
            part.velocities[j].y -= 18 * dt;
            pos.addScaledVector(part.velocities[j], dt);
            dummy.setPosition(pos);
            part.mesh.setMatrixAt(j, dummy);
          }
          part.mesh.instanceMatrix.needsUpdate = true;
        }
      }

      // 10. WebGL Render
      try {
        renderer.render(scene, camera);
      } catch (err) {
        console.error('Render loop error:', err);
      }

      // 11. Throttled UI State Sync (every 100ms = 10 FPS)
      if (time - lastSyncTime >= 100) {
        lastSyncTime = time;
        if (onPlayerSync) {
          onPlayerSync({ ...playerRef.current }, timeOfDayRef.current);
        }
      }
    };

    animId = requestAnimationFrame(animate);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', handleResize);
      resizeObserver.disconnect();

      if (mobManagerRef.current) {
        mobManagerRef.current.destroy();
        mobManagerRef.current = null;
      }

      if (worldRef.current) {
        if (typeof worldRef.current.dispose === 'function') {
          worldRef.current.dispose();
        } else if (typeof (worldRef.current as any).destroy === 'function') {
          (worldRef.current as any).destroy();
        }
      }

      renderer.dispose();
      if (renderer.domElement.parentNode) {
        renderer.domElement.parentNode.removeChild(renderer.domElement);
      }
    };
  }, [worldData.seed, worldData.worldType]);

  // Update Hand Item Mesh, Material & UVs when active block changes
  useEffect(() => {
    if (handMeshRef.current) {
      if (activeBlock === BlockType.AIR) {
        handMeshRef.current.visible = false;
      } else {
        handMeshRef.current.visible = true;
        const atlas = getTextureAtlas();
        const conf = BLOCK_REGISTRY[activeBlock];
        handMeshRef.current.material = conf?.isTransparent ? atlas.transparentMaterial : atlas.opaqueMaterial;
        updateHeldBlockUVs(handMeshRef.current.geometry as THREE.BoxGeometry, activeBlock);
      }
    }
  }, [activeBlock]);

  // External Action Trigger from mobile buttons or touch screen
  useEffect(() => {
    if (!actionTrigger) return;
    if (actionTrigger.type === 'break') {
      handleBreak();
    } else if (actionTrigger.type === 'place') {
      handlePlace();
    }
  }, [actionTrigger, handleBreak, handlePlace]);

  // Desktop Mouse Handlers (Pointer Lock & Smooth 0-latency Look)
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const handleMouseDown = (e: MouseEvent) => {
      if (document.pointerLockElement !== container) {
        try {
          const lockResult = container.requestPointerLock() as any;
          if (lockResult && typeof lockResult.catch === 'function') {
            lockResult.catch(() => {
              // Ignore pointer lock rejections in iframe sandbox environments
            });
          }
        } catch {
          // Fallback for older browsers
        }
        return;
      }

      if (e.button === 0) {
        handleBreak();
        isMiningRef.current = true;
        mineCooldownRef.current = 0.28;
      } else if (e.button === 2) {
        handlePlace();
        isPlacingRef.current = true;
        placeCooldownRef.current = 0.28;
      }
    };

    const handleMouseUp = (e: MouseEvent) => {
      if (e.button === 0) isMiningRef.current = false;
      if (e.button === 2) isPlacingRef.current = false;
    };

    const handleMouseMove = (e: MouseEvent) => {
      if (document.pointerLockElement !== container) return;
      const sens = settingsRef.current.mouseSensitivity || 0.002;
      applyLookDelta(-e.movementX * sens, -e.movementY * sens);
    };

    const handleContextMenu = (e: MouseEvent) => {
      e.preventDefault();
    };

    const handleLockChange = () => {
      const isLocked = document.pointerLockElement === container;
      if (!isLocked) {
        isMiningRef.current = false;
        isPlacingRef.current = false;
      }
      onPointerLockChange(isLocked);
    };

    const handleBlur = () => {
      isMiningRef.current = false;
      isPlacingRef.current = false;
    };

    const handleLockError = () => {
      // Gracefully silence pointer lock errors in sandboxed iframes
    };

    container.addEventListener('mousedown', handleMouseDown);
    window.addEventListener('mouseup', handleMouseUp);
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('blur', handleBlur);
    container.addEventListener('contextmenu', handleContextMenu);
    document.addEventListener('pointerlockchange', handleLockChange);
    document.addEventListener('pointerlockerror', handleLockError);

    return () => {
      container.removeEventListener('mousedown', handleMouseDown);
      window.removeEventListener('mouseup', handleMouseUp);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('blur', handleBlur);
      container.removeEventListener('contextmenu', handleContextMenu);
      document.removeEventListener('pointerlockchange', handleLockChange);
      document.removeEventListener('pointerlockerror', handleLockError);
    };
  }, [handleBreak, handlePlace, applyLookDelta, onPointerLockChange]);

  return (
    <div
      ref={containerRef}
      id="voxel-canvas-container"
      className="absolute inset-0 w-full h-full cursor-crosshair select-none overflow-hidden touch-none"
    />
  );
});

VoxelCanvas.displayName = 'VoxelCanvas';
