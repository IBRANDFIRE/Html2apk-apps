import React from 'react';
import { PlayerState, RaycastHit, GameSettings } from '../types';
import { BLOCK_REGISTRY } from '../game/blocks';
import { Settings, Save, Smartphone, MousePointer, Info } from 'lucide-react';

interface HUDOverlayProps {
  worldName: string;
  seed: number;
  player: PlayerState;
  targetHit: RaycastHit | null;
  settings: GameSettings;
  fps: number;
  isPointerLocked: boolean;
  onOpenSettings: () => void;
  onOpenSaveManager: () => void;
  onQuickSave: () => void;
  isTouchControlsVisible: boolean;
  onToggleTouchControls: () => void;
  saveFeedback: string | null;
}

export const HUDOverlay: React.FC<HUDOverlayProps> = ({
  worldName,
  seed,
  player,
  targetHit,
  settings,
  fps,
  isPointerLocked,
  onOpenSettings,
  onOpenSaveManager,
  onQuickSave,
  isTouchControlsVisible,
  onToggleTouchControls,
  saveFeedback,
}) => {
  // Compute facing direction from yaw
  const getFacingDirection = (yaw: number) => {
    const deg = (((yaw * 180) / Math.PI) % 360 + 360) % 360;
    if (deg >= 315 || deg < 45) return 'N (-Z)';
    if (deg >= 45 && deg < 135) return 'W (-X)';
    if (deg >= 135 && deg < 225) return 'S (+Z)';
    return 'E (+X)';
  };

  return (
    <div className="absolute inset-0 pointer-events-none select-none z-10 flex flex-col justify-between p-2 sm:p-3">
      {/* Top Header Row */}
      <div className="flex items-center justify-between w-full pointer-events-auto">
        {/* Top Left: World Info */}
        <div className="flex items-center gap-1.5 text-[11px] font-mono drop-shadow-[0_1px_2px_rgba(0,0,0,0.9)]">
          <span className="bg-neutral-900/75 px-2 py-0.5 rounded border border-neutral-700/80 text-white font-semibold backdrop-blur-xs">
            {worldName}
          </span>
          {saveFeedback && (
            <span className="bg-emerald-600/90 text-white px-2 py-0.5 rounded text-[10px] font-bold animate-pulse">
              {saveFeedback}
            </span>
          )}

          {/* Optional Compact F3 Stats */}
          {settings.showCoordinates && (
            <div className="bg-black/70 backdrop-blur-xs px-2 py-1 rounded border border-white/10 text-[10px] text-neutral-300 flex items-center gap-2">
              <span className="text-white font-bold">
                {player.x.toFixed(1)}, {player.y.toFixed(1)}, {player.z.toFixed(1)}
              </span>
              <span className="text-emerald-400 font-bold">{fps} FPS</span>
              <span className="text-neutral-400 font-bold">{getFacingDirection(player.yaw)}</span>
            </div>
          )}
        </div>

        {/* Top Right: Compact Action Buttons */}
        <div className="flex items-center gap-1.5">
          {/* Quick Save button */}
          <button
            onClick={onQuickSave}
            className="p-1.5 bg-neutral-900/75 hover:bg-neutral-800 text-white rounded-lg border border-neutral-700/80 shadow-md backdrop-blur-xs active:scale-95 transition-transform"
            title="Save Game World"
          >
            <Save className="w-3.5 h-3.5 text-emerald-400" />
          </button>

          {/* Touch Controls Toggle */}
          <button
            onClick={onToggleTouchControls}
            className={`p-1.5 rounded-lg border shadow-md backdrop-blur-xs transition-all ${
              isTouchControlsVisible
                ? 'bg-amber-600/90 border-amber-400 text-white'
                : 'bg-neutral-900/75 border-neutral-700/80 text-neutral-400 hover:text-white'
            }`}
            title="Toggle On-Screen Touch Buttons"
          >
            <Smartphone className="w-3.5 h-3.5" />
          </button>

          {/* Settings / Pause menu */}
          <button
            onClick={onOpenSettings}
            className="p-1.5 rounded-lg bg-neutral-900/75 hover:bg-neutral-800 text-white border border-neutral-700/80 shadow-md backdrop-blur-xs active:scale-95 transition-transform"
            title="Settings & Pause (ESC)"
          >
            <Settings className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Center Crosshair */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none">
        <div className="relative w-4 h-4 flex items-center justify-center">
          <div className="absolute w-3.5 h-[2px] bg-white/80 shadow-[0_0_2px_rgba(0,0,0,0.8)]" />
          <div className="absolute h-3.5 w-[2px] bg-white/80 shadow-[0_0_2px_rgba(0,0,0,0.8)]" />
        </div>
      </div>

      {/* Desktop Pointer Lock Hint (subtle small banner) */}
      {!isPointerLocked && !isTouchControlsVisible && (
        <div className="absolute top-12 left-1/2 -translate-x-1/2 bg-neutral-950/80 backdrop-blur-xs border border-neutral-700/80 text-white px-3 py-1 rounded-full text-[11px] font-mono flex items-center gap-1.5 shadow-xl pointer-events-none">
          <MousePointer className="w-3.5 h-3.5 text-amber-400" />
          <span>Click screen to control camera (ESC to unlock)</span>
        </div>
      )}
    </div>
  );
};
