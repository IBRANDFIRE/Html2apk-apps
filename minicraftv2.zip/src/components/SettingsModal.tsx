import React from 'react';
import { GameSettings } from '../types';
import { soundManager } from '../game/audio';
import { X, Sliders, Volume2, Sun, Eye, Compass, Shield } from 'lucide-react';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: GameSettings;
  onUpdateSettings: (newSettings: Partial<GameSettings>) => void;
  timeOfDay: number;
  onUpdateTimeOfDay: (time: number) => void;
  gameMode: 'survival' | 'creative';
  onToggleGameMode: () => void;
  onOpenSaveManager: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
  timeOfDay,
  onUpdateTimeOfDay,
  gameMode,
  onToggleGameMode,
  onOpenSaveManager,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-3 sm:p-5 select-none">
      <div className="relative w-full max-w-lg bg-neutral-900 border-2 border-neutral-600 rounded-2xl shadow-2xl p-4 sm:p-6 text-neutral-100 flex flex-col max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-neutral-700">
          <div className="flex items-center gap-2">
            <Sliders className="w-5 h-5 text-amber-400" />
            <h2 className="text-base font-mono font-bold tracking-tight">GAME SETTINGS & PAUSE</h2>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-white border border-neutral-700 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-4 my-4">
          {/* Game Mode switch */}
          <div className="flex items-center justify-between p-3 bg-neutral-800/80 rounded-xl border border-neutral-700">
            <div className="flex items-center gap-2.5">
              <Shield className="w-5 h-5 text-amber-400" />
              <div>
                <span className="text-xs font-mono font-bold text-white block">GAME MODE</span>
                <span className="text-[11px] font-mono text-neutral-400">
                  {gameMode === 'survival' ? 'Survival: Health & resource gathering' : 'Creative: Flight & infinite blocks'}
                </span>
              </div>
            </div>
            <button
              onClick={onToggleGameMode}
              className="px-3 py-1.5 bg-neutral-700 hover:bg-neutral-600 text-white rounded-lg text-xs font-mono font-bold capitalize border border-neutral-600"
            >
              {gameMode}
            </button>
          </div>

          {/* Time of Day */}
          <div className="p-3 bg-neutral-800/80 rounded-xl border border-neutral-700 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono font-bold text-white flex items-center gap-1.5">
                <Sun className="w-4 h-4 text-amber-400" /> TIME OF DAY
              </span>
              <span className="text-xs font-mono text-neutral-400">
                {timeOfDay < 6000 ? 'Dawn' : timeOfDay < 12000 ? 'Noon' : timeOfDay < 18000 ? 'Sunset' : 'Night'} ({timeOfDay})
              </span>
            </div>
            <input
              type="range"
              min="0"
              max="24000"
              step="500"
              value={timeOfDay}
              onChange={(e) => onUpdateTimeOfDay(parseInt(e.target.value, 10))}
              className="w-full accent-amber-500"
            />
            <div className="flex justify-between text-[10px] font-mono text-neutral-400">
              <button type="button" onClick={() => onUpdateTimeOfDay(0)} className="hover:text-white">Dawn (0)</button>
              <button type="button" onClick={() => onUpdateTimeOfDay(6000)} className="hover:text-white">Noon (6000)</button>
              <button type="button" onClick={() => onUpdateTimeOfDay(12000)} className="hover:text-white">Sunset (12000)</button>
              <button type="button" onClick={() => onUpdateTimeOfDay(18000)} className="hover:text-white">Midnight (18000)</button>
            </div>
          </div>

          {/* Render Distance & FOV */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="p-3 bg-neutral-800/80 rounded-xl border border-neutral-700 space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono font-bold text-white flex items-center gap-1">
                  <Eye className="w-3.5 h-3.5 text-neutral-400" /> RENDER DISTANCE
                </span>
                <span className="text-xs font-mono text-amber-400">{settings.renderDistance} Chunks</span>
              </div>
              <input
                type="range"
                min="2"
                max="5"
                value={settings.renderDistance}
                onChange={(e) => onUpdateSettings({ renderDistance: parseInt(e.target.value, 10) })}
                className="w-full accent-amber-500"
              />
            </div>

            <div className="p-3 bg-neutral-800/80 rounded-xl border border-neutral-700 space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono font-bold text-white">FOV</span>
                <span className="text-xs font-mono text-amber-400">{settings.fov}°</span>
              </div>
              <input
                type="range"
                min="60"
                max="95"
                value={settings.fov}
                onChange={(e) => onUpdateSettings({ fov: parseInt(e.target.value, 10) })}
                className="w-full accent-amber-500"
              />
            </div>
          </div>

          {/* Sound & Coordinates */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="p-3 bg-neutral-800/80 rounded-xl border border-neutral-700 space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono font-bold text-white flex items-center gap-1">
                  <Volume2 className="w-3.5 h-3.5 text-neutral-400" /> SOUND VOLUME
                </span>
                <span className="text-xs font-mono text-amber-400">{Math.round(settings.soundVolume * 100)}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="1"
                step="0.05"
                value={settings.soundVolume}
                onChange={(e) => {
                  const vol = parseFloat(e.target.value);
                  soundManager.volume = vol;
                  onUpdateSettings({ soundVolume: vol });
                }}
                className="w-full accent-amber-500"
              />
            </div>

            <div className="p-3 bg-neutral-800/80 rounded-xl border border-neutral-700 flex items-center justify-between">
              <div>
                <span className="text-xs font-mono font-bold text-white flex items-center gap-1">
                  <Compass className="w-3.5 h-3.5 text-neutral-400" /> F3 STATS / COORDS
                </span>
                <span className="text-[10px] font-mono text-neutral-400">Show X, Y, Z & FPS</span>
              </div>
              <button
                onClick={() => onUpdateSettings({ showCoordinates: !settings.showCoordinates })}
                className={`px-3 py-1 rounded-lg text-xs font-mono font-bold border transition-colors ${
                  settings.showCoordinates ? 'bg-amber-600 border-amber-400 text-white' : 'bg-neutral-700 border-neutral-600 text-neutral-300'
                }`}
              >
                {settings.showCoordinates ? 'ON' : 'OFF'}
              </button>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="pt-3 border-t border-neutral-800 flex items-center justify-between gap-3">
          <button
            onClick={() => {
              onClose();
              onOpenSaveManager();
            }}
            className="px-4 py-2 bg-neutral-800 hover:bg-neutral-700 text-amber-300 border border-neutral-700 rounded-lg text-xs font-mono font-bold"
          >
            Manage Saved Worlds
          </button>

          <button
            onClick={onClose}
            className="px-6 py-2 bg-amber-600 hover:bg-amber-500 text-white rounded-lg text-xs font-mono font-bold shadow-lg"
          >
            Back to Game (ESC)
          </button>
        </div>
      </div>
    </div>
  );
};
