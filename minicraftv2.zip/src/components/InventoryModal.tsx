import React, { useState } from 'react';
import { BlockType, InventoryItem } from '../types';
import { BLOCK_REGISTRY, CREATIVE_BLOCKS } from '../game/blocks';
import { CRAFTING_RECIPES, findMatchingRecipe } from '../game/crafting';
import { soundManager } from '../game/audio';
import { X, ArrowRight, Sparkles, Hammer, Grid } from 'lucide-react';

interface InventoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  hotbar: (InventoryItem | null)[];
  inventory: (InventoryItem | null)[];
  onUpdateSlots: (newHotbar: (InventoryItem | null)[], newInventory: (InventoryItem | null)[]) => void;
  gameMode: 'survival' | 'creative';
  selectedHotbarIndex?: number;
  onSelectHotbarIndex?: (index: number) => void;
}

export const InventoryModal: React.FC<InventoryModalProps> = ({
  isOpen,
  onClose,
  hotbar,
  inventory,
  onUpdateSlots,
  gameMode,
  selectedHotbarIndex = 0,
  onSelectHotbarIndex,
}) => {
  const [activeTab, setActiveTab] = useState<'inventory' | 'creative'>('inventory');
  const [craftingGrid, setCraftingGrid] = useState<(BlockType | null)[]>([null, null, null, null]);
  const [heldItem, setHeldItem] = useState<InventoryItem | null>(null);

  const [searchQuery, setSearchQuery] = useState('');

  if (!isOpen) return null;

  const activeHotbarIdx = Math.max(0, Math.min(8, selectedHotbarIndex));

  const uniqueCreativeBlocks = Array.from(new Set(CREATIVE_BLOCKS));
  const filteredCreativeBlocks = uniqueCreativeBlocks.filter((type) => {
    const conf = BLOCK_REGISTRY[type];
    if (!conf) return false;
    return conf.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (conf.category && conf.category.toLowerCase().includes(searchQuery.toLowerCase()));
  });

  // Calculate crafting result
  const craftResult = findMatchingRecipe(craftingGrid, 2);

  // Quick equip item from inventory slot directly to selected hotbar slot
  const handleQuickEquipToSelectedHotbar = (inventoryIndex: number) => {
    soundManager.playUiClick();
    const nextInventory = [...inventory];
    const nextHotbar = [...hotbar];

    const invItem = nextInventory[inventoryIndex];
    const hotbarItem = nextHotbar[activeHotbarIdx];

    nextHotbar[activeHotbarIdx] = invItem;
    nextInventory[inventoryIndex] = hotbarItem;

    onUpdateSlots(nextHotbar, nextInventory);
  };

  // Handle slot click in inventory/hotbar
  const handleSlotClick = (isHotbar: boolean, index: number, isDoubleClickOrShift: boolean = false) => {
    soundManager.playUiClick();
    if (isHotbar) {
      onSelectHotbarIndex?.(index);
    }

    const targetArray = isHotbar ? [...hotbar] : [...inventory];
    const currentItem = targetArray[index];

    if (isDoubleClickOrShift && !isHotbar && currentItem) {
      handleQuickEquipToSelectedHotbar(index);
      return;
    }

    if (!heldItem && currentItem) {
      // Pick up item
      setHeldItem({ ...currentItem });
      targetArray[index] = null;
    } else if (heldItem && !currentItem) {
      // Place held item
      targetArray[index] = { ...heldItem };
      setHeldItem(null);
    } else if (heldItem && currentItem) {
      if (heldItem.blockType === currentItem.blockType) {
        // Stack items
        const maxStack = 64;
        const space = maxStack - currentItem.count;
        if (space > 0) {
          const toAdd = Math.min(space, heldItem.count);
          targetArray[index] = { ...currentItem, count: currentItem.count + toAdd };
          const remCount = heldItem.count - toAdd;
          setHeldItem(remCount > 0 ? { ...heldItem, count: remCount } : null);
        }
      } else {
        // Swap items
        targetArray[index] = { ...heldItem };
        setHeldItem({ ...currentItem });
      }
    }

    if (isHotbar) {
      onUpdateSlots(targetArray, inventory);
    } else {
      onUpdateSlots(hotbar, targetArray);
    }
  };

  // Handle crafting grid slot click
  const handleCraftingGridClick = (index: number) => {
    soundManager.playUiClick();
    const newGrid = [...craftingGrid];
    const curType = newGrid[index];

    if (!heldItem && curType !== null) {
      setHeldItem({ blockType: curType, count: 1 });
      newGrid[index] = null;
    } else if (heldItem) {
      newGrid[index] = heldItem.blockType;
      const nextCount = heldItem.count - 1;
      setHeldItem(nextCount > 0 ? { ...heldItem, count: nextCount } : null);
    }
    setCraftingGrid(newGrid);
  };

  // Claim crafted item
  const handleClaimCraft = () => {
    if (!craftResult) return;
    soundManager.playBlockPlace('wood');

    // Add to held item or hotbar/inventory
    if (!heldItem) {
      setHeldItem({ blockType: craftResult.blockType, count: craftResult.count });
    } else if (heldItem.blockType === craftResult.blockType) {
      setHeldItem({ ...heldItem, count: heldItem.count + craftResult.count });
    } else {
      // Held item different, find empty slot in hotbar/inventory
      const nextHotbar = [...hotbar];
      const emptyIdx = nextHotbar.findIndex((x) => x === null);
      if (emptyIdx !== -1) {
        nextHotbar[emptyIdx] = { blockType: craftResult.blockType, count: craftResult.count };
        onUpdateSlots(nextHotbar, inventory);
      } else {
        return; // No space
      }
    }

    // Consume 1 item from each non-empty crafting slot
    const newGrid = craftingGrid.map(() => null);
    setCraftingGrid(newGrid);
  };

  // Creative Mode: Take 64 of block directly into currently selected hotbar slot
  const handleCreativePick = (type: BlockType) => {
    soundManager.playUiClick();
    const nextHotbar = [...hotbar];
    nextHotbar[activeHotbarIdx] = { blockType: type, count: 64 };
    onUpdateSlots(nextHotbar, inventory);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-2 sm:p-4 select-none">
      <div className="relative w-full max-w-2xl bg-neutral-900 border-2 border-neutral-600 rounded-2xl shadow-2xl p-4 sm:p-6 text-neutral-100 flex flex-col max-h-[95vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-neutral-700">
          <div className="flex items-center gap-2">
            <div className="flex bg-neutral-800 p-0.5 rounded-lg border border-neutral-700">
              <button
                onClick={() => setActiveTab('inventory')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-mono font-bold transition-all ${
                  activeTab === 'inventory' ? 'bg-neutral-700 text-white shadow' : 'text-neutral-400 hover:text-white'
                }`}
              >
                <Grid className="w-4 h-4" />
                <span>INVENTORY & CRAFTING</span>
              </button>
              <button
                onClick={() => setActiveTab('creative')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-mono font-bold transition-all ${
                  activeTab === 'creative' ? 'bg-amber-600 text-white shadow' : 'text-neutral-400 hover:text-white'
                }`}
              >
                <Sparkles className="w-4 h-4" />
                <span>CREATIVE BLOCKS</span>
              </button>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-white border border-neutral-700 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Floating cursor item indicator */}
        {heldItem && (
          <div className="bg-amber-500/20 border border-amber-400/40 text-amber-200 text-xs px-2.5 py-1 rounded-md my-2 flex items-center justify-between font-mono">
            <span>Holding: <strong>{BLOCK_REGISTRY[heldItem.blockType]?.name}</strong> (x{heldItem.count})</span>
            <span className="text-[11px] text-neutral-400">Click any slot to place</span>
          </div>
        )}

        {/* Content Tabs */}
        {activeTab === 'inventory' ? (
          <div className="flex flex-col gap-4 mt-3">
            {/* 2x2 Crafting Area */}
            <div className="flex items-center justify-between p-3 bg-neutral-800/80 rounded-xl border border-neutral-700">
              <div>
                <span className="text-xs font-mono font-bold text-neutral-400 uppercase tracking-wider flex items-center gap-1">
                  <Hammer className="w-3.5 h-3.5 text-neutral-300" /> Crafting (2x2)
                </span>
                <p className="text-[11px] text-neutral-500">Combine blocks to craft new items</p>
              </div>

              <div className="flex items-center gap-3">
                {/* 2x2 Grid */}
                <div className="grid grid-cols-2 gap-1 bg-neutral-900 p-1.5 rounded-lg border border-neutral-700">
                  {craftingGrid.map((type, idx) => (
                    <button
                      key={idx}
                      onClick={() => handleCraftingGridClick(idx)}
                      className="w-10 h-10 rounded bg-neutral-800 hover:bg-neutral-700/80 border border-neutral-600 flex items-center justify-center text-xs font-mono relative"
                    >
                      {type !== null && (
                        <div
                          className="w-6 h-6 rounded-xs shadow-xs"
                          style={{ backgroundColor: BLOCK_REGISTRY[type]?.color }}
                          title={BLOCK_REGISTRY[type]?.name}
                        />
                      )}
                    </button>
                  ))}
                </div>

                <ArrowRight className="w-5 h-5 text-neutral-500" />

                {/* Craft Result */}
                <button
                  disabled={!craftResult}
                  onClick={handleClaimCraft}
                  className={`w-12 h-12 rounded-lg border flex flex-col items-center justify-center transition-all ${
                    craftResult
                      ? 'bg-amber-950/80 border-amber-500/80 text-amber-300 hover:scale-105 shadow-md cursor-pointer'
                      : 'bg-neutral-800/40 border-neutral-700 text-neutral-600 cursor-not-allowed'
                  }`}
                >
                  {craftResult && (
                    <>
                      <div
                        className="w-6 h-6 rounded-xs"
                        style={{ backgroundColor: BLOCK_REGISTRY[craftResult.blockType]?.color }}
                      />
                      <span className="text-[10px] font-mono font-bold mt-0.5">x{craftResult.count}</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Quick Recipe Book */}
            <div className="flex flex-wrap gap-1.5 p-2 bg-neutral-950/40 rounded-lg border border-neutral-800">
              <span className="text-[11px] font-mono text-neutral-400 w-full mb-1">Quick Recipes:</span>
              {CRAFTING_RECIPES.map((r) => (
                <button
                  key={r.id}
                  onClick={() => {
                    // Try to auto-craft if player has ingredients
                    soundManager.playUiClick();
                  }}
                  className="px-2 py-0.5 bg-neutral-800 hover:bg-neutral-700 text-[11px] font-mono rounded border border-neutral-700 text-neutral-300 flex items-center gap-1"
                >
                  <span>{r.name}</span>
                  <span className="text-amber-400">(x{r.result.count})</span>
                </button>
              ))}
            </div>

            {/* 27-slot Main Inventory Grid */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-mono font-bold text-neutral-400 uppercase tracking-wider">
                  Main Inventory (27 Slots)
                </span>
                <span className="text-[10px] font-mono text-neutral-500">
                  Tip: Double-click item to quick-equip to Slot #{activeHotbarIdx + 1}
                </span>
              </div>
              <div className="grid grid-cols-9 gap-1 sm:gap-1.5 bg-neutral-950/60 p-2.5 rounded-xl border border-neutral-800">
                {inventory.map((item, idx) => {
                  const conf = item ? BLOCK_REGISTRY[item.blockType] : null;
                  return (
                    <button
                      key={idx}
                      onClick={(e) => handleSlotClick(false, idx, e.detail === 2 || e.shiftKey)}
                      className="w-full aspect-square rounded-lg bg-neutral-800/90 hover:bg-neutral-700/80 border border-neutral-700 flex flex-col items-center justify-center relative active:scale-95 transition-transform"
                      title={conf ? `${conf.name} (Double-click to equip to Slot #${activeHotbarIdx + 1})` : 'Empty Slot'}
                    >
                      {item && conf && (
                        <>
                          <div
                            className="w-5 h-5 sm:w-6 sm:h-6 rounded-xs shadow-xs"
                            style={{ backgroundColor: conf.color }}
                          />
                          {item.count > 1 && (
                            <span className="absolute bottom-0.5 right-1 text-[9px] sm:text-[10px] font-mono font-bold text-white drop-shadow-[0_1px_1px_rgba(0,0,0,0.8)]">
                              {item.count}
                            </span>
                          )}
                        </>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 9-slot Hotbar Grid */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-mono font-bold text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
                  <span>Hotbar (9 Slots)</span>
                  <span className="bg-amber-500/20 text-amber-300 border border-amber-400/30 px-2 py-0.5 rounded text-[10px] font-bold">
                    Target Slot: #{activeHotbarIdx + 1}
                  </span>
                </span>
                <span className="text-[10px] font-mono text-neutral-400">
                  Click slot to select active target
                </span>
              </div>
              <div className="grid grid-cols-9 gap-1 sm:gap-1.5 bg-neutral-950/60 p-2.5 rounded-xl border border-neutral-700 ring-1 ring-amber-500/20">
                {hotbar.map((item, idx) => {
                  const conf = item ? BLOCK_REGISTRY[item.blockType] : null;
                  const isSelected = idx === activeHotbarIdx;
                  return (
                    <button
                      key={idx}
                      onClick={(e) => handleSlotClick(true, idx, e.detail === 2 || e.shiftKey)}
                      className={`w-full aspect-square rounded-lg flex flex-col items-center justify-center relative active:scale-95 transition-all ${
                        isSelected
                          ? 'bg-amber-950/70 border-2 border-amber-400 ring-2 ring-amber-400/40 shadow-lg scale-105 z-10'
                          : 'bg-neutral-800/90 hover:bg-neutral-700/80 border border-neutral-600'
                      }`}
                      title={isSelected ? `Slot ${idx + 1} (Selected Hotbar Slot)` : `Slot ${idx + 1}`}
                    >
                      <span className={`absolute top-0.5 left-1 text-[8px] font-mono font-bold ${isSelected ? 'text-amber-300' : 'text-neutral-400'}`}>
                        {idx + 1}
                      </span>
                      {isSelected && (
                        <span className="absolute top-0.5 right-1 text-[7px] font-mono font-black text-amber-400">
                          ★
                        </span>
                      )}
                      {item && conf && (
                        <>
                          <div
                            className="w-5 h-5 sm:w-6 sm:h-6 rounded-xs shadow-xs"
                            style={{ backgroundColor: conf.color }}
                          />
                          {item.count > 1 && (
                            <span className="absolute bottom-0.5 right-1 text-[9px] sm:text-[10px] font-mono font-bold text-white drop-shadow-[0_1px_1px_rgba(0,0,0,0.8)]">
                              {item.count}
                            </span>
                          )}
                        </>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        ) : (
          /* Creative Block Selector */
          <div className="mt-3 flex flex-col gap-3">
            <div className="flex flex-wrap items-center justify-between gap-2 bg-neutral-950/60 p-2.5 rounded-xl border border-neutral-800">
              <p className="text-xs font-mono text-neutral-300 flex items-center gap-1.5">
                <span>Click any block to place stack (x64) into:</span>
                <span className="bg-amber-500/20 border border-amber-400/40 text-amber-300 px-2 py-0.5 rounded font-bold">
                  Hotbar Slot #{activeHotbarIdx + 1}
                </span>
              </p>
              <input
                type="text"
                placeholder="Search blocks..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="px-3 py-1 bg-neutral-900 border border-neutral-700 rounded-lg text-xs font-mono text-white focus:outline-none focus:border-amber-400 w-44"
              />
            </div>
            <div className="grid grid-cols-4 sm:grid-cols-6 gap-2.5 max-h-[50vh] overflow-y-auto p-2 bg-neutral-950/40 rounded-xl border border-neutral-800">
              {filteredCreativeBlocks.map((type) => {
                const conf = BLOCK_REGISTRY[type];
                return (
                  <button
                    key={type}
                    onClick={() => handleCreativePick(type)}
                    className="p-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 border border-neutral-700 hover:border-amber-400 flex flex-col items-center gap-1.5 transition-all text-center group"
                  >
                    <div
                      className="w-8 h-8 rounded-sm shadow-md border border-black/40 group-hover:scale-110 transition-transform"
                      style={{ backgroundColor: conf.color }}
                    />
                    <span className="text-[11px] font-mono font-medium text-neutral-300 leading-tight">
                      {conf.name}
                    </span>
                  </button>
                );
              })}
              {filteredCreativeBlocks.length === 0 && (
                <div className="col-span-full py-8 text-center text-xs font-mono text-neutral-500">
                  No blocks found matching "{searchQuery}"
                </div>
              )}
            </div>
          </div>
        )}

        {/* Footer info */}
        <div className="mt-4 pt-3 border-t border-neutral-800 flex items-center justify-between text-xs font-mono text-neutral-400">
          <span>Mode: <strong className="text-white capitalize">{gameMode}</strong></span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-white rounded-lg border border-neutral-700 transition-colors"
          >
            Close (E / ESC)
          </button>
        </div>
      </div>
    </div>
  );
};
