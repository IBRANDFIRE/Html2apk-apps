import React, { useState, useEffect, useRef } from 'react';
import { WorldMetadata, SavedWorldData } from '../types';
import { worldStorage } from '../game/storage';
import { soundManager } from '../game/audio';
import {
  Save,
  FolderOpen,
  Plus,
  Trash2,
  Download,
  Upload,
  Copy,
  Clock,
  MapPin,
  Calendar,
  X,
  Check,
  Globe,
} from 'lucide-react';

interface SaveManagerModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentWorld: SavedWorldData;
  onSaveCurrentWorld: () => Promise<void>;
  onLoadWorld: (worldId: string) => Promise<void>;
  onCreateWorld: (name: string, type: 'default' | 'flat' | 'mountains' | 'islands', seed: number, gameMode: 'survival' | 'creative') => Promise<void>;
  onImportWorld: (worldData: SavedWorldData) => Promise<void>;
}

export const SaveManagerModal: React.FC<SaveManagerModalProps> = ({
  isOpen,
  onClose,
  currentWorld,
  onSaveCurrentWorld,
  onLoadWorld,
  onCreateWorld,
  onImportWorld,
}) => {
  const [worlds, setWorlds] = useState<WorldMetadata[]>([]);
  const [activeTab, setActiveTab] = useState<'list' | 'create'>('list');
  const [saveStatus, setSaveStatus] = useState<string | null>(null);

  // New world form state
  const [newName, setNewName] = useState('My Voxel Realm');
  const [newType, setNewType] = useState<'default' | 'flat' | 'mountains' | 'islands'>('default');
  const [newSeed, setNewSeed] = useState<string>(() => Math.floor(Math.random() * 999999).toString());
  const [newMode, setNewMode] = useState<'survival' | 'creative'>('survival');

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Load list of worlds on modal open
  const refreshWorlds = async () => {
    const list = await worldStorage.listWorlds();
    setWorlds(list);
  };

  useEffect(() => {
    if (isOpen) {
      refreshWorlds();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  // Handle manual save
  const handleSaveCurrent = async () => {
    soundManager.playUiClick();
    setSaveStatus('Saving world state...');
    try {
      await onSaveCurrentWorld();
      setSaveStatus('World saved successfully!');
      await refreshWorlds();
      setTimeout(() => setSaveStatus(null), 2500);
    } catch {
      setSaveStatus('Error saving world');
    }
  };

  // Handle world creation
  const handleCreateSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    soundManager.playUiClick();
    const parsedSeed = parseInt(newSeed, 10) || Math.floor(Math.random() * 999999);
    await onCreateWorld(newName.trim() || 'New World', newType, parsedSeed, newMode);
    setActiveTab('list');
    await refreshWorlds();
    onClose();
  };

  // Handle world deletion
  const handleDelete = async (id: string, name: string) => {
    if (id === currentWorld.id) {
      alert('Cannot delete the currently active world.');
      return;
    }
    if (confirm(`Are you sure you want to delete world "${name}"? This action cannot be undone.`)) {
      soundManager.playUiClick();
      await worldStorage.deleteWorld(id);
      await refreshWorlds();
    }
  };

  // Handle world duplication
  const handleDuplicate = async (id: string) => {
    const worldToCopy = await worldStorage.loadWorld(id);
    if (!worldToCopy) return;

    soundManager.playUiClick();
    const copyData: SavedWorldData = {
      ...worldToCopy,
      id: 'world_' + Date.now() + '_' + Math.floor(Math.random() * 1000),
      name: `${worldToCopy.name} (Copy)`,
      createdAt: Date.now(),
      lastPlayedAt: Date.now(),
    };
    await worldStorage.saveWorld(copyData);
    await refreshWorlds();
  };

  // Handle export to JSON
  const handleExport = async (id: string) => {
    const worldToExport = await worldStorage.loadWorld(id);
    if (!worldToExport) return;

    soundManager.playUiClick();
    const jsonStr = worldStorage.exportWorldJSON(worldToExport);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${worldToExport.name.replace(/\s+/g, '_')}_voxelcraft_save.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // Handle import from file
  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      const text = await file.text();
      const imported = worldStorage.importWorldJSON(text);
      await onImportWorld(imported);
      await refreshWorlds();
      alert(`Imported world "${imported.name}" successfully!`);
      onClose();
    } catch {
      alert('Failed to import world file. Please ensure it is a valid VoxelCraft save JSON.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-3 sm:p-5 select-none">
      <div className="relative w-full max-w-2xl bg-neutral-900 border-2 border-neutral-600 rounded-2xl shadow-2xl p-4 sm:p-6 text-neutral-100 flex flex-col max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-neutral-700">
          <div className="flex items-center gap-2">
            <Globe className="w-5 h-5 text-amber-400" />
            <h2 className="text-base sm:text-lg font-mono font-bold tracking-tight">
              WORLD SAVE MANAGER
            </h2>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-white border border-neutral-700 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Current Active World Status Bar */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between p-3 my-3 bg-neutral-800/80 rounded-xl border border-neutral-700 gap-3">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono font-bold text-amber-400">ACTIVE WORLD:</span>
              <span className="text-sm font-mono font-bold text-white">{currentWorld.name}</span>
            </div>
            <div className="flex items-center gap-3 text-[11px] font-mono text-neutral-400 mt-1">
              <span>Seed: {currentWorld.seed}</span>
              <span>Type: {currentWorld.worldType}</span>
              <span>Mode: {currentWorld.gameMode}</span>
            </div>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              onClick={handleSaveCurrent}
              className="flex items-center justify-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg border border-emerald-400 text-xs font-mono font-bold shadow transition-all active:scale-95 flex-1 sm:flex-initial"
            >
              <Save className="w-4 h-4" />
              <span>SAVE NOW</span>
            </button>

            <button
              onClick={() => handleExport(currentWorld.id)}
              className="flex items-center justify-center gap-1.5 px-3 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 rounded-lg border border-neutral-600 text-xs font-mono transition-all active:scale-95"
              title="Export this world to JSON"
            >
              <Download className="w-4 h-4" />
              <span>EXPORT</span>
            </button>
          </div>
        </div>

        {saveStatus && (
          <div className="p-2 mb-3 bg-emerald-950/60 border border-emerald-600/60 text-emerald-300 text-xs font-mono rounded-lg flex items-center gap-2">
            <Check className="w-4 h-4" />
            <span>{saveStatus}</span>
          </div>
        )}

        {/* Tabs: Saved Worlds vs Create New World */}
        <div className="flex items-center justify-between border-b border-neutral-800 pb-2 mb-3">
          <div className="flex gap-2">
            <button
              onClick={() => setActiveTab('list')}
              className={`px-3 py-1 rounded-lg text-xs font-mono font-bold transition-all ${
                activeTab === 'list'
                  ? 'bg-neutral-800 text-white border border-neutral-600 shadow'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              Saved Worlds ({worlds.length})
            </button>
            <button
              onClick={() => setActiveTab('create')}
              className={`px-3 py-1 rounded-lg text-xs font-mono font-bold transition-all ${
                activeTab === 'create'
                  ? 'bg-amber-600 text-white shadow'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              + Create World
            </button>
          </div>

          <div>
            <button
              onClick={() => fileInputRef.current?.click()}
              className="flex items-center gap-1 px-2.5 py-1 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs font-mono rounded-lg border border-neutral-700"
            >
              <Upload className="w-3.5 h-3.5 text-sky-400" />
              <span>Import File</span>
            </button>
            <input
              ref={fileInputRef}
              type="file"
              accept=".json"
              className="hidden"
              onChange={handleFileChange}
            />
          </div>
        </div>

        {/* Tab Content */}
        {activeTab === 'list' ? (
          <div className="flex-1 overflow-y-auto space-y-2 pr-1">
            {worlds.length === 0 ? (
              <div className="text-center py-8 text-neutral-500 font-mono text-xs">
                No saved worlds found. Current world will be saved automatically.
              </div>
            ) : (
              worlds.map((w) => {
                const isActive = w.id === currentWorld.id;
                const playedDate = new Date(w.lastPlayedAt).toLocaleDateString(undefined, {
                  month: 'short',
                  day: 'numeric',
                  hour: '2-digit',
                  minute: '2-digit',
                });

                return (
                  <div
                    key={w.id}
                    className={`p-3 rounded-xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                      isActive
                        ? 'bg-neutral-800/90 border-amber-500/80 shadow-md ring-1 ring-amber-500/30'
                        : 'bg-neutral-800/40 border-neutral-700/60 hover:bg-neutral-800/70'
                    }`}
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-white text-sm">{w.name}</span>
                        {isActive && (
                          <span className="bg-amber-500/20 text-amber-300 text-[10px] font-mono px-1.5 py-0.5 rounded border border-amber-500/40">
                            PLAYING
                          </span>
                        )}
                        <span className="bg-neutral-700/60 text-neutral-300 text-[10px] font-mono px-1.5 py-0.5 rounded capitalize">
                          {w.worldType}
                        </span>
                      </div>

                      <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-[11px] font-mono text-neutral-400 mt-1">
                        <span className="flex items-center gap-1">
                          <MapPin className="w-3 h-3 text-neutral-500" />
                          Seed: {w.seed}
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3 text-neutral-500" />
                          {playedDate}
                        </span>
                        <span>Mode: {w.gameMode}</span>
                      </div>
                    </div>

                    {/* Action buttons */}
                    <div className="flex items-center gap-1.5 self-end sm:self-center">
                      {!isActive && (
                        <button
                          onClick={() => onLoadWorld(w.id)}
                          className="flex items-center gap-1 px-3 py-1.5 bg-sky-600 hover:bg-sky-500 text-white rounded-lg text-xs font-mono font-bold shadow transition-all"
                        >
                          <FolderOpen className="w-3.5 h-3.5" />
                          <span>LOAD</span>
                        </button>
                      )}

                      <button
                        onClick={() => handleDuplicate(w.id)}
                        className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 border border-neutral-700"
                        title="Duplicate World"
                      >
                        <Copy className="w-4 h-4" />
                      </button>

                      <button
                        onClick={() => handleExport(w.id)}
                        className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 border border-neutral-700"
                        title="Export JSON"
                      >
                        <Download className="w-4 h-4" />
                      </button>

                      {!isActive && (
                        <button
                          onClick={() => handleDelete(w.id, w.name)}
                          className="p-1.5 rounded-lg bg-rose-950/60 hover:bg-rose-900/80 text-rose-300 border border-rose-800/60"
                          title="Delete World"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        ) : (
          /* Create New World Form */
          <form onSubmit={handleCreateSubmit} className="flex-1 overflow-y-auto space-y-4 pr-1">
            <div>
              <label className="block text-xs font-mono font-bold text-neutral-300 mb-1">
                WORLD NAME
              </label>
              <input
                type="text"
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                required
                maxLength={32}
                className="w-full px-3 py-2 bg-neutral-950 border border-neutral-700 rounded-lg text-sm font-mono text-white focus:outline-none focus:border-amber-500"
                placeholder="My Adventure World"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-mono font-bold text-neutral-300 mb-1">
                  WORLD GENERATOR TYPE
                </label>
                <select
                  value={newType}
                  onChange={(e) => setNewType(e.target.value as any)}
                  className="w-full px-3 py-2 bg-neutral-950 border border-neutral-700 rounded-lg text-sm font-mono text-white focus:outline-none focus:border-amber-500"
                >
                  <option value="default">Default Overworld (Biomes, Hills, Rivers & Ores)</option>
                  <option value="plains">Lush Plains (Flat Meadows, Wildflowers & Rivers)</option>
                  <option value="mountains">Jagged Mountains (Snow Peaks, Cliffs & Waterfalls)</option>
                  <option value="amplified">Amplified (Extreme 50-Block Cliffs & Floating Islands)</option>
                  <option value="desert">Arid Desert (Golden Sand Dunes, Cacti & Oases)</option>
                  <option value="islands">Survival Islands (Ocean Archipelago & Sand Beaches)</option>
                  <option value="flat">Superflat (Clean Building Flatland)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-mono font-bold text-neutral-300 mb-1">
                  GAME MODE
                </label>
                <select
                  value={newMode}
                  onChange={(e) => setNewMode(e.target.value as any)}
                  className="w-full px-3 py-2 bg-neutral-950 border border-neutral-700 rounded-lg text-sm font-mono text-white focus:outline-none focus:border-amber-500"
                >
                  <option value="survival">Survival (Health, Mining, Crafting)</option>
                  <option value="creative">Creative (Infinite Blocks, Flight)</option>
                </select>
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-mono font-bold text-neutral-300">
                  WORLD SEED (NUMERIC)
                </label>
                <button
                  type="button"
                  onClick={() => setNewSeed(Math.floor(Math.random() * 999999).toString())}
                  className="text-[11px] font-mono text-amber-400 hover:underline"
                >
                  Randomize
                </button>
              </div>
              <input
                type="number"
                value={newSeed}
                onChange={(e) => setNewSeed(e.target.value)}
                className="w-full px-3 py-2 bg-neutral-950 border border-neutral-700 rounded-lg text-sm font-mono text-white focus:outline-none focus:border-amber-500"
              />
            </div>

            <div className="pt-2 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setActiveTab('list')}
                className="px-4 py-2 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 rounded-lg text-xs font-mono"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex items-center gap-1.5 px-5 py-2 bg-amber-600 hover:bg-amber-500 text-white rounded-lg text-xs font-mono font-bold shadow-lg transition-all"
              >
                <Plus className="w-4 h-4" />
                <span>GENERATE & ENTER WORLD</span>
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
