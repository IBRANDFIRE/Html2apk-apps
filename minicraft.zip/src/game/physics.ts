import { BlockType, PlayerState } from '../types';
import { BLOCK_REGISTRY } from './blocks';
import { VoxelWorld, CHUNK_HEIGHT } from './world';

export interface MovementInput {
  forward: boolean;
  backward: boolean;
  left: boolean;
  right: boolean;
  analogX?: number;
  analogZ?: number;
  jump: boolean;
  sneak: boolean;
  sprint: boolean;
  flyToggle?: boolean;
}

export class PlayerPhysics {
  public width = 0.6;
  public height = 1.8;
  public eyeHeight = 1.62;

  public vx = 0;
  public vy = 0;
  public vz = 0;

  private gravity = 28;
  private walkSpeed = 4.3;
  private sprintSpeed = 6.2;
  private sneakSpeed = 1.8;
  private jumpVelocity = 8.6;
  private flySpeed = 10.0;

  private jumpHoldTimer = 0;
  private jumpHoldTriggered = false;

  public update(
    player: PlayerState,
    input: MovementInput,
    world: VoxelWorld,
    dt: number
  ): { footstepTriggered: boolean; soundType: string; flyToggled: boolean } {
    const clampedDt = Math.min(dt, 0.05); // Prevent tunneling on tab lag

    let flyToggled = false;
    if (input.jump) {
      this.jumpHoldTimer += clampedDt;
      if (this.jumpHoldTimer >= 0.4 && !this.jumpHoldTriggered) {
        this.jumpHoldTriggered = true;
        player.isFlying = !player.isFlying;
        flyToggled = true;
        if (!player.isFlying) {
          this.vy = 0;
        }
      }
    } else {
      this.jumpHoldTimer = 0;
      this.jumpHoldTriggered = false;
    }

    // Multi-point water check (feet, torso, eyes)
    const feetY = player.y + 0.1;
    const bodyY = player.y + 0.8;
    const eyesY = player.y + 1.5;

    const blockFeet = world.getBlock(Math.floor(player.x), Math.floor(feetY), Math.floor(player.z));
    const blockBody = world.getBlock(Math.floor(player.x), Math.floor(bodyY), Math.floor(player.z));
    const blockEyes = world.getBlock(Math.floor(player.x), Math.floor(eyesY), Math.floor(player.z));

    const inWater = blockFeet === BlockType.WATER || blockBody === BlockType.WATER || blockEyes === BlockType.WATER;

    // Movement direction from yaw
    let moveX = 0;
    let moveZ = 0;

    if (input.analogX !== undefined && input.analogZ !== undefined && (input.analogX !== 0 || input.analogZ !== 0)) {
      moveX = input.analogX;
      moveZ = input.analogZ;
      const len = Math.hypot(moveX, moveZ);
      if (len > 1) {
        moveX /= len;
        moveZ /= len;
      }
    } else {
      if (input.forward) moveZ -= 1;
      if (input.backward) moveZ += 1;
      if (input.left) moveX -= 1;
      if (input.right) moveX += 1;

      const len = Math.hypot(moveX, moveZ);
      if (len > 0) {
        moveX /= len;
        moveZ /= len;
      }
    }

    // Rotate movement vector by yaw
    const sinYaw = Math.sin(player.yaw);
    const cosYaw = Math.cos(player.yaw);

    const worldMoveX = moveX * cosYaw + moveZ * sinYaw;
    const worldMoveZ = -moveX * sinYaw + moveZ * cosYaw;

    let targetSpeed = this.walkSpeed;
    if (player.isFlying) {
      targetSpeed = this.flySpeed;
    } else if (input.sprint) {
      targetSpeed = this.sprintSpeed;
    } else if (input.sneak) {
      targetSpeed = this.sneakSpeed;
    }

    // Fast, responsive horizontal acceleration & deceleration
    const accel = player.isGrounded ? 26 : 10;
    const targetVx = worldMoveX * targetSpeed;
    const targetVz = worldMoveZ * targetSpeed;

    this.vx += (targetVx - this.vx) * Math.min(1, accel * clampedDt);
    this.vz += (targetVz - this.vz) * Math.min(1, accel * clampedDt);

    let footstepTriggered = false;
    let blockUnderType = 'grass';

    if (player.isFlying) {
      // Flying mode (Creative)
      let targetVy = 0;
      if (input.jump) targetVy += this.flySpeed;
      if (input.sneak) targetVy -= this.flySpeed;
      this.vy += (targetVy - this.vy) * Math.min(1, 15 * clampedDt);

      player.x += this.vx * clampedDt;
      player.y += this.vy * clampedDt;
      player.z += this.vz * clampedDt;
      player.isGrounded = false;
    } else if (inWater) {
      // Swimming physics with smooth buoyancy & direction control
      const waterSpeed = input.sprint ? 5.2 : 3.6;
      const targetVx = worldMoveX * waterSpeed;
      const targetVz = worldMoveZ * waterSpeed;

      this.vx += (targetVx - this.vx) * Math.min(1, 12 * clampedDt);
      this.vz += (targetVz - this.vz) * Math.min(1, 12 * clampedDt);

      if (input.jump) {
        // Swim upward smoothly
        this.vy = Math.min(this.vy + 24 * clampedDt, 4.8);

        // If body emerged near surface, leap out onto land
        if (blockBody !== BlockType.WATER && blockEyes !== BlockType.WATER) {
          this.vy = 7.5;
        }
      } else if (input.sneak) {
        // Swim downward
        this.vy = Math.max(this.vy - 24 * clampedDt, -4.5);
      } else {
        // Soft neutral buoyancy with slight water damping
        this.vy *= Math.pow(0.85, clampedDt * 60);

        // Pitch-based 3D swimming (look up/down to swim up/down)
        if (input.forward && Math.abs(player.pitch) > 0.15) {
          const pitchEffect = Math.sin(player.pitch);
          this.vy += pitchEffect * waterSpeed * 0.8 * clampedDt * 10;
          this.vy = Math.max(-4.5, Math.min(4.8, this.vy));
        }
      }

      this.vx *= Math.pow(0.85, clampedDt * 60);
      this.vz *= Math.pow(0.85, clampedDt * 60);

      player.isGrounded = false;
      this.moveWithCollision(player, input, world, clampedDt);
    } else {
      // Standard gravity & ground movement
      if (player.isGrounded) {
        const hasGround = this.isColliding(player.x, player.y - 0.05, player.z, world, 0.001);
        if (!hasGround) {
          player.isGrounded = false;
        }
      }

      if (player.isGrounded) {
        this.vy = 0;
        if (input.jump) {
          this.vy = this.jumpVelocity;
          player.isGrounded = false;
        }
      } else {
        this.vy -= this.gravity * clampedDt;
        this.vy = Math.max(this.vy, -38); // Terminal velocity
      }

      const prevGrounded = player.isGrounded;
      this.moveWithCollision(player, input, world, clampedDt);

      // Footstep sound detection
      const horizontalSpeed = Math.hypot(this.vx, this.vz);
      if (player.isGrounded && horizontalSpeed > 1.2) {
        const checkY = Math.floor(player.y - 0.2);
        const groundBlock = world.getBlock(Math.floor(player.x), checkY, Math.floor(player.z));
        const conf = BLOCK_REGISTRY[groundBlock];
        blockUnderType = conf?.soundType || 'grass';
        if (Math.random() < clampedDt * (input.sprint ? 3.8 : 2.6)) {
          footstepTriggered = true;
        }
      }

      if (!prevGrounded && player.isGrounded) {
        // Just landed
        footstepTriggered = true;
      }
    }

    // Keep within world bounds
    player.y = Math.max(1, Math.min(player.y, CHUNK_HEIGHT - 2));

    return { footstepTriggered, soundType: blockUnderType, flyToggled };
  }

  // AABB collision resolution
  private moveWithCollision(player: PlayerState, input: MovementInput, world: VoxelWorld, dt: number) {
    // 1. Move Y axis
    const newY = player.y + this.vy * dt;
    if (this.vy < 0) {
      // Falling down
      if (this.isColliding(player.x, newY, player.z, world, 0.001)) {
        player.y = Math.floor(newY) + 1.0;
        this.vy = 0;
        player.isGrounded = true;
      } else {
        player.y = newY;
        player.isGrounded = false;
      }
    } else if (this.vy > 0) {
      // Jumping up
      if (this.isColliding(player.x, newY, player.z, world, 0.001)) {
        player.y = Math.floor(newY + this.height) - this.height;
        this.vy = 0;
      } else {
        player.y = newY;
        player.isGrounded = false;
      }
    }

    // Sneak protection - don't fall off ledge
    let tryX = player.x + this.vx * dt;
    if (input.sneak && player.isGrounded) {
      if (!this.isColliding(tryX, player.y - 0.1, player.z, world, 0.001)) {
        tryX = player.x;
        this.vx = 0;
      }
    }

    // 2. Move X axis (use yOffset = 0.08 to prevent ground block collision stutter)
    if (!this.isColliding(tryX, player.y, player.z, world, 0.08)) {
      player.x = tryX;
    } else {
      // Auto step (1 block height)
      const stepY = Math.floor(player.y) + 1.0;
      if (
        player.isGrounded &&
        !this.isColliding(tryX, stepY, player.z, world, 0.08) &&
        !this.isColliding(player.x, stepY, player.z, world, 0.08)
      ) {
        player.x = tryX;
        player.y = stepY;
        player.isGrounded = true;
      } else {
        this.vx = 0;
      }
    }

    // Sneak protection for Z
    let tryZ = player.z + this.vz * dt;
    if (input.sneak && player.isGrounded) {
      if (!this.isColliding(player.x, player.y - 0.1, tryZ, world, 0.001)) {
        tryZ = player.z;
        this.vz = 0;
      }
    }

    // 3. Move Z axis (use yOffset = 0.08 to prevent ground block collision stutter)
    if (!this.isColliding(player.x, player.y, tryZ, world, 0.08)) {
      player.z = tryZ;
    } else {
      // Auto step (1 block height)
      const stepY = Math.floor(player.y) + 1.0;
      if (
        player.isGrounded &&
        !this.isColliding(player.x, stepY, tryZ, world, 0.08) &&
        !this.isColliding(player.x, stepY, player.z, world, 0.08)
      ) {
        player.z = tryZ;
        player.y = stepY;
        player.isGrounded = true;
      } else {
        this.vz = 0;
      }
    }
  }

  public isColliding(x: number, y: number, z: number, world: VoxelWorld, yOffset = 0.005): boolean {
    const halfW = this.width / 2;
    const minX = Math.floor(x - halfW + 0.005);
    const maxX = Math.floor(x + halfW - 0.005);
    const minY = Math.floor(y + yOffset);
    const maxY = Math.floor(y + this.height - 0.005);
    const minZ = Math.floor(z - halfW + 0.005);
    const maxZ = Math.floor(z + halfW - 0.005);

    for (let bx = minX; bx <= maxX; bx++) {
      for (let by = minY; by <= maxY; by++) {
        for (let bz = minZ; bz <= maxZ; bz++) {
          const block = world.getBlock(bx, by, bz);
          if (block !== BlockType.AIR && block !== BlockType.WATER) {
            const conf = BLOCK_REGISTRY[block];
            if (!conf?.isPlant) {
              return true;
            }
          }
        }
      }
    }
    return false;
  }
}
