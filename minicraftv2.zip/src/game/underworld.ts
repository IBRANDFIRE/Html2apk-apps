import { BlockType } from '../types';
import { SeededNoise } from './noise';
import { CHUNK_SIZE_X, CHUNK_SIZE_Z } from './world';

export class UnderworldGenerator {
  private noise: SeededNoise;
  private oreNoise: SeededNoise;
  private veinNoise: SeededNoise;
  private caveNoise: SeededNoise;

  constructor(seed: number) {
    this.noise = new SeededNoise(seed + 1111);
    this.oreNoise = new SeededNoise(seed + 2222);
    this.veinNoise = new SeededNoise(seed + 3333);
    this.caveNoise = new SeededNoise(seed + 4444);
  }

  /**
   * Generates the underworld column (Y=0 up to surface height).
   * Handles bedrock, deepslate transition, stone veins (granite, diorite, andesite, tuff, basalt),
   * rarity-based ore spawning, and 3D cave carving.
   */
  public generateColumn(
    blocks: Uint8Array,
    lx: number,
    lz: number,
    gx: number,
    gz: number,
    surfaceHeight: number,
    isDesert: boolean = false
  ): void {
    for (let y = 0; y <= surfaceHeight; y++) {
      const idx = lx + lz * CHUNK_SIZE_X + y * (CHUNK_SIZE_X * CHUNK_SIZE_Z);

      // 1. Bedrock Floor (Y = 0, with random Y=1..2 jagged bedrock)
      if (y === 0) {
        blocks[idx] = BlockType.BEDROCK;
        continue;
      }
      if (y <= 2) {
        const bedrockNoise = this.noise.noise2D(gx * 0.4, gz * 0.4);
        if (y === 1 && bedrockNoise > 0.1) {
          blocks[idx] = BlockType.BEDROCK;
          continue;
        }
        if (y === 2 && bedrockNoise > 0.65) {
          blocks[idx] = BlockType.BEDROCK;
          continue;
        }
      }

      // 2. 3D Cave Carving Check
      if (y > 1 && y < surfaceHeight - 3) {
        const c1 = this.caveNoise.noise3D(gx * 0.045, y * 0.07, gz * 0.045);
        const c2 = this.caveNoise.noise3D(gx * 0.075 + 50, y * 0.05 + 50, gz * 0.075 + 50);

        // Tunnel carving threshold
        const caveThreshold = 0.11;
        if (Math.abs(c1) < caveThreshold && Math.abs(c2) < caveThreshold) {
          // Underground water pools at deep levels
          if (y <= 12) {
            blocks[idx] = BlockType.WATER;
          } else {
            blocks[idx] = BlockType.AIR;
          }
          continue;
        }
      }

      // 3. Base Layer: Deepslate at lower depths, Stone at mid/upper levels
      let baseStone: BlockType = BlockType.STONE;
      if (y <= 14) {
        baseStone = BlockType.DEEPSLATE;
      } else if (y <= 18) {
        // Smooth transition zone between deepslate and stone
        const transition = (18 - y) / 4;
        const n = this.noise.noise3D(gx * 0.2, y * 0.2, gz * 0.2);
        baseStone = n < transition ? BlockType.DEEPSLATE : BlockType.STONE;
      }

      // 4. Special Stone Vein Generation (Granite, Diorite, Andesite, Tuff, Basalt, Gravel, Calcite, Dripstone, Amethyst)
      const graniteVal = this.veinNoise.noise3D(gx * 0.08, y * 0.08, gz * 0.08);
      const dioriteVal = this.veinNoise.noise3D(gx * 0.08 + 100, y * 0.08 + 100, gz * 0.08 + 100);
      const andesiteVal = this.veinNoise.noise3D(gx * 0.08 + 200, y * 0.08 + 200, gz * 0.08 + 200);
      const gravelVal = this.veinNoise.noise3D(gx * 0.09 + 50, y * 0.09 + 50, gz * 0.09 + 50);

      let chosenBlock: BlockType = baseStone;

      if (graniteVal > 0.55) {
        chosenBlock = BlockType.GRANITE;
      } else if (dioriteVal > 0.55) {
        chosenBlock = BlockType.DIORITE;
      } else if (andesiteVal > 0.55) {
        chosenBlock = BlockType.ANDESITE;
      } else if (gravelVal > 0.62) {
        chosenBlock = BlockType.GRAVEL;
      } else if (y <= 16) {
        const basaltVal = this.veinNoise.noise3D(gx * 0.1, y * 0.1, gz * 0.1);
        const tuffVal = this.veinNoise.noise3D(gx * 0.1 + 300, y * 0.1 + 300, gz * 0.1 + 300);
        const dripstoneVal = this.veinNoise.noise3D(gx * 0.09 + 400, y * 0.09 + 400, gz * 0.09 + 400);

        // Rare underground Amethyst Geodes with Calcite outer layer
        const geodeNoise = this.veinNoise.noise3D(gx * 0.05 + 800, y * 0.05 + 800, gz * 0.05 + 800);
        if (geodeNoise > 0.72) {
          chosenBlock = BlockType.AMETHYST_BLOCK;
        } else if (geodeNoise > 0.65) {
          chosenBlock = BlockType.CALCITE;
        } else if (dripstoneVal > 0.58) {
          chosenBlock = BlockType.DRIPSTONE_BLOCK;
        } else if (basaltVal > 0.58) {
          chosenBlock = BlockType.BASALT;
        } else if (tuffVal > 0.56) {
          chosenBlock = BlockType.TUFF;
        }
      }

      // 5. Rarity-Based Ore Distribution
      const oN = this.oreNoise.noise3D(gx * 0.14, y * 0.14, gz * 0.14);
      const oN2 = this.oreNoise.noise3D(gx * 0.22 + 40, y * 0.22 + 40, gz * 0.22 + 40);

      // Emerald: Ultra Rare (Deep Y 1..14)
      if (y >= 1 && y <= 14 && oN > 0.88 && oN2 > 0.5) {
        chosenBlock = BlockType.EMERALD_ORE;
      }
      // Diamond: Extremely Rare (Deep Y 1..16)
      else if (y >= 1 && y <= 16 && oN > 0.82) {
        chosenBlock = BlockType.DIAMOND_ORE;
      }
      // Gold: Very Rare (Y 1..24)
      else if (y >= 1 && y <= 24 && oN > 0.74) {
        chosenBlock = BlockType.GOLD_ORE;
      }
      // Lapis: Rare (Y 4..28)
      else if (y >= 4 && y <= 28 && oN > 0.67 && oN2 > 0.4) {
        chosenBlock = BlockType.LAPIS_ORE;
      }
      // Redstone: Rare (Y 1..25)
      else if (y >= 1 && y <= 25 && oN > 0.61) {
        chosenBlock = BlockType.REDSTONE_ORE;
      }
      // Iron: Uncommon (Y 4..45)
      else if (y >= 4 && y <= 45 && oN > 0.46) {
        chosenBlock = BlockType.IRON_ORE;
      }
      // Coal: Common (Y 5..55)
      else if (y >= 5 && y <= 55 && oN > 0.34) {
        chosenBlock = BlockType.COAL_ORE;
      }

      // If at top surface layer, preserve grass/sand/etc set by caller
      if (y < surfaceHeight - 3) {
        blocks[idx] = chosenBlock;
      } else if (y < surfaceHeight) {
        // Dirt/Sand layer near surface
        if (isDesert) {
          blocks[idx] = BlockType.SANDSTONE;
        } else {
          blocks[idx] = BlockType.DIRT;
        }
      }
    }
  }
}
