export enum BlockType {
  AIR = 0,
  GRASS = 1,
  DIRT = 2,
  STONE = 3,
  COBBLESTONE = 4,
  OAK_LOG = 5,
  OAK_LEAVES = 6,
  OAK_PLANKS = 7,
  SAND = 8,
  WATER = 9,
  GLASS = 10,
  BRICK = 11,
  BEDROCK = 12,
  COAL_ORE = 13,
  IRON_ORE = 14,
  GOLD_ORE = 15,
  DIAMOND_ORE = 16,
  CRAFTING_TABLE = 17,
  TNT = 18,
  SNOW = 19,
  OBSIDIAN = 20,
  BOOKSHELF = 21,
  GLOWSTONE = 22,
  SANDSTONE = 23,
  CACTUS = 24,
  POPPY = 25,
  DANDELION = 26,
  REDSTONE_ORE = 27,
  EMERALD_ORE = 28,
  LAPIS_ORE = 29,
  DIAMOND_BLOCK = 30,
  GOLD_BLOCK = 31,
  IRON_BLOCK = 32,
  EMERALD_BLOCK = 33,
  NETHERITE_BLOCK = 34,
  BIRCH_LOG = 35,
  BIRCH_LEAVES = 36,
  BIRCH_PLANKS = 37,
  CHERRY_LOG = 38,
  CHERRY_LEAVES = 39,
  CHERRY_PLANKS = 40,
  DARK_OAK_LOG = 41,
  DARK_OAK_LEAVES = 42,
  DARK_OAK_PLANKS = 43,
  ICE = 44,
  PACKED_ICE = 45,
  MOSS_BLOCK = 46,
  CLAY = 47,
  RED_MUSHROOM_BLOCK = 48,
  STONE_BRICKS = 49,
  MOSSY_STONE_BRICKS = 50,
  SMOOTH_STONE = 51,
  NETHERRACK = 52,
  NETHER_BRICKS = 53,
  SOUL_SAND = 54,
  QUARTZ_BLOCK = 55,
  PRISMARINE = 56,
  SEA_LANTERN = 57,
  RED_WOOL = 58,
  BLUE_WOOL = 59,
  GREEN_WOOL = 60,
  YELLOW_WOOL = 61,
  PURPLE_WOOL = 62,
  ORANGE_WOOL = 63,
  WHITE_WOOL = 64,
  BLACK_WOOL = 65,
  TERRACOTTA = 66,
  TARGET_BLOCK = 67,
  SHORT_GRASS = 68,
  TALL_GRASS = 69,
  RED_MUSHROOM = 70,
  BROWN_MUSHROOM = 71,
  SPRUCE_LOG = 72,
  SPRUCE_LEAVES = 73,
  SPRUCE_PLANKS = 74,
  JUNGLE_LOG = 75,
  JUNGLE_LEAVES = 76,
  JUNGLE_PLANKS = 77,
  ACACIA_LOG = 78,
  ACACIA_LEAVES = 79,
  ACACIA_PLANKS = 80,
  GRANITE = 81,
  DIORITE = 82,
  ANDESITE = 83,
  DEEPSLATE = 84,
  TUFF = 85,
  BASALT = 86,
  RAW_BEEF = 87,
  RAW_PORKCHOP = 88,
  RAW_CHICKEN = 89,
  FEATHER = 90,
  LEATHER = 91,

  // --- STAIRS (Base + Directional Variants) ---
  OAK_STAIRS = 92,
  OAK_STAIRS_N = 93,
  OAK_STAIRS_S = 94,
  OAK_STAIRS_E = 95,
  OAK_STAIRS_W = 96,
  OAK_STAIRS_N_UP = 97,
  OAK_STAIRS_S_UP = 98,
  OAK_STAIRS_E_UP = 99,
  OAK_STAIRS_W_UP = 100,

  COBBLESTONE_STAIRS = 101,
  COBBLESTONE_STAIRS_N = 102,
  COBBLESTONE_STAIRS_S = 103,
  COBBLESTONE_STAIRS_E = 104,
  COBBLESTONE_STAIRS_W = 105,
  COBBLESTONE_STAIRS_N_UP = 106,
  COBBLESTONE_STAIRS_S_UP = 107,
  COBBLESTONE_STAIRS_E_UP = 108,
  COBBLESTONE_STAIRS_W_UP = 109,

  BRICK_STAIRS = 110,
  BRICK_STAIRS_N = 111,
  BRICK_STAIRS_S = 112,
  BRICK_STAIRS_E = 113,
  BRICK_STAIRS_W = 114,
  BRICK_STAIRS_N_UP = 115,
  BRICK_STAIRS_S_UP = 116,
  BRICK_STAIRS_E_UP = 117,
  BRICK_STAIRS_W_UP = 118,

  STONE_BRICK_STAIRS = 119,
  STONE_BRICK_STAIRS_N = 120,
  STONE_BRICK_STAIRS_S = 121,
  STONE_BRICK_STAIRS_E = 122,
  STONE_BRICK_STAIRS_W = 123,
  STONE_BRICK_STAIRS_N_UP = 124,
  STONE_BRICK_STAIRS_S_UP = 125,
  STONE_BRICK_STAIRS_E_UP = 126,
  STONE_BRICK_STAIRS_W_UP = 127,

  QUARTZ_STAIRS = 128,
  QUARTZ_STAIRS_N = 129,
  QUARTZ_STAIRS_S = 130,
  QUARTZ_STAIRS_E = 131,
  QUARTZ_STAIRS_W = 132,
  QUARTZ_STAIRS_N_UP = 133,
  QUARTZ_STAIRS_S_UP = 134,
  QUARTZ_STAIRS_E_UP = 135,
  QUARTZ_STAIRS_W_UP = 136,

  SPRUCE_STAIRS = 137,
  SPRUCE_STAIRS_N = 138,
  SPRUCE_STAIRS_S = 139,
  SPRUCE_STAIRS_E = 140,
  SPRUCE_STAIRS_W = 141,
  SPRUCE_STAIRS_N_UP = 142,
  SPRUCE_STAIRS_S_UP = 143,
  SPRUCE_STAIRS_E_UP = 144,
  SPRUCE_STAIRS_W_UP = 145,

  // --- SLABS (Base + Top/Bottom Variants) ---
  OAK_SLAB = 146,
  OAK_SLAB_BOT = 147,
  OAK_SLAB_TOP = 148,

  COBBLESTONE_SLAB = 149,
  COBBLESTONE_SLAB_BOT = 150,
  COBBLESTONE_SLAB_TOP = 151,

  BRICK_SLAB = 152,
  BRICK_SLAB_BOT = 153,
  BRICK_SLAB_TOP = 154,

  STONE_BRICK_SLAB = 155,
  STONE_BRICK_SLAB_BOT = 156,
  STONE_BRICK_SLAB_TOP = 157,

  QUARTZ_SLAB = 158,
  QUARTZ_SLAB_BOT = 159,
  QUARTZ_SLAB_TOP = 160,

  SMOOTH_STONE_SLAB = 161,
  SMOOTH_STONE_SLAB_BOT = 162,
  SMOOTH_STONE_SLAB_TOP = 163,

  SPRUCE_SLAB = 164,
  SPRUCE_SLAB_BOT = 165,
  SPRUCE_SLAB_TOP = 166,

  // --- FENCES & WALLS ---
  OAK_FENCE = 167,
  SPRUCE_FENCE = 168,
  NETHER_BRICK_FENCE = 169,
  COBBLESTONE_WALL = 170,
  STONE_BRICK_WALL = 171,
  BRICK_WALL = 172,

  // --- DOORS, TRAPDOORS, PANES & LANTERNS ---
  OAK_DOOR = 173,
  OAK_DOOR_N = 174,
  OAK_DOOR_S = 175,
  OAK_DOOR_E = 176,
  OAK_DOOR_W = 177,

  SPRUCE_DOOR = 178,
  SPRUCE_DOOR_N = 179,
  SPRUCE_DOOR_S = 180,
  SPRUCE_DOOR_E = 181,
  SPRUCE_DOOR_W = 182,

  OAK_TRAPDOOR = 183,
  GLASS_PANE = 184,
  LANTERN = 185,

  // --- CHESTS & FURNACES ---
  CHEST = 186,
  CHEST_N = 187,
  CHEST_S = 188,
  CHEST_E = 189,
  CHEST_W = 190,

  FURNACE = 191,
  FURNACE_N = 192,
  FURNACE_S = 193,
  FURNACE_E = 194,
  FURNACE_W = 195,

  // --- MORE HOUSE BUILDING BLOCKS ---
  QUARTZ_PILLAR = 196,
  CHISELED_QUARTZ = 197,
  PURPUR_BLOCK = 198,
  DEEPSLATE_BRICKS = 199,
  POLISHED_GRANITE = 200,
  POLISHED_DIORITE = 201,
  POLISHED_ANDESITE = 202,

  // --- CONCRETES ---
  WHITE_CONCRETE = 203,
  BLACK_CONCRETE = 204,
  GRAY_CONCRETE = 205,
  RED_CONCRETE = 206,
  BLUE_CONCRETE = 207,
  YELLOW_CONCRETE = 208,
  GREEN_CONCRETE = 209,
  CYAN_CONCRETE = 210,
  ORANGE_CONCRETE = 211,
  PINK_CONCRETE = 212,
  PURPLE_CONCRETE = 213,

  // --- WOOLS ---
  LIGHT_BLUE_WOOL = 214,
  LIME_WOOL = 215,
  PINK_WOOL = 216,
  GRAY_WOOL = 217,
  CYAN_WOOL = 218,
  MAGENTA_WOOL = 219,
}

export type BlockShape = 'cube' | 'stairs' | 'slab' | 'fence' | 'wall' | 'door' | 'trapdoor' | 'pane' | 'lantern';
export type BlockFacing = 'N' | 'S' | 'E' | 'W';

export interface BlockConfig {
  id: BlockType;
  name: string;
  isTransparent?: boolean;
  isPlant?: boolean;
  isFluid?: boolean;
  isLightSource?: boolean;
  hardness: number; // break time in seconds
  soundType: 'grass' | 'stone' | 'wood' | 'sand' | 'glass' | 'water';
  color: string; // Preview color for UI/fallback
  category: 'building' | 'natural' | 'ores' | 'decorative';
  shape?: BlockShape;
  facing?: BlockFacing;
  isUpsideDown?: boolean;
  isTopSlab?: boolean;
  baseBlock?: BlockType;
}

export interface InventoryItem {
  blockType: BlockType;
  count: number;
}

export interface PlayerState {
  x: number;
  y: number;
  z: number;
  pitch: number; // Vertical camera angle
  yaw: number;   // Horizontal camera angle
  isGrounded: boolean;
  isFlying: boolean;
  isSneaking: boolean;
  isSprinting: boolean;
  health: number;
  maxHealth: number;
  hunger: number;
  maxHunger: number;
  gameMode: 'survival' | 'creative';
}

export interface WorldMetadata {
  id: string;
  name: string;
  seed: number;
  createdAt: number;
  lastPlayedAt: number;
  gameMode: 'survival' | 'creative';
  worldType: 'default' | 'flat' | 'plains' | 'mountains' | 'amplified' | 'desert' | 'islands';
  timeOfDay: number; // 0 to 24000 (0=dawn, 6000=noon, 12000=dusk, 18000=midnight)
  player: PlayerState;
  hotbar: (InventoryItem | null)[];
  inventory: (InventoryItem | null)[];
  stats: {
    blocksPlaced: number;
    blocksBroken: number;
    timePlayedMinutes: number;
  };
}

export interface SavedWorldData extends WorldMetadata {
  // Delta of modified blocks: [chunkKey: string]: { [localIndex: number]: BlockType }
  modifiedBlocks: Record<string, Record<string, BlockType>>;
}

export interface RaycastHit {
  blockPos: [number, number, number];
  normal: [number, number, number];
  hitPos: [number, number, number];
  blockType: BlockType;
  distance: number;
}

export interface GameSettings {
  renderDistance: number; // in chunks (e.g. 3 to 6)
  fov: number;
  mouseSensitivity: number;
  touchSensitivity: number;
  soundVolume: number;
  showCoordinates: boolean;
  showFps: boolean;
  cloudsEnabled: boolean;
  dayNightSpeed: number; // 1 = normal, 0 = freeze
}
