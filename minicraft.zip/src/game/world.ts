import * as THREE from 'three';
import { BlockType } from '../types';
import { BLOCK_REGISTRY } from './blocks';
import { SeededNoise } from './noise';
import { getTextureAtlas } from './textures';
import { UnderworldGenerator } from './underworld';

export const CHUNK_SIZE_X = 16;
export const CHUNK_SIZE_Z = 16;
export const CHUNK_HEIGHT = 64;
export const SEA_LEVEL = 22;

export interface ChunkData {
  cx: number;
  cz: number;
  // 1D array of size CHUNK_SIZE_X * CHUNK_HEIGHT * CHUNK_SIZE_Z
  blocks: Uint8Array;
  // 2D array of size CHUNK_SIZE_X * CHUNK_SIZE_Z storing highest solid block Y
  heightMap: Uint8Array;
  isDirty: boolean;
  meshes: THREE.Mesh[];
}

const FACE_DEFINITIONS = [
  // 0: +X (PX, right)
  {
    dir: [1, 0, 0],
    corners: [
      [1, 0, 1], [1, 0, 0], [1, 1, 0], [1, 1, 1]
    ],
  },
  // 1: -X (NX, left)
  {
    dir: [-1, 0, 0],
    corners: [
      [0, 0, 0], [0, 0, 1], [0, 1, 1], [0, 1, 0]
    ],
  },
  // 2: +Y (PY, top)
  {
    dir: [0, 1, 0],
    corners: [
      [0, 1, 1], [1, 1, 1], [1, 1, 0], [0, 1, 0]
    ],
  },
  // 3: -Y (NY, bottom)
  {
    dir: [0, -1, 0],
    corners: [
      [0, 0, 0], [1, 0, 0], [1, 0, 1], [0, 0, 1]
    ],
  },
  // 4: +Z (PZ, front)
  {
    dir: [0, 0, 1],
    corners: [
      [0, 0, 1], [1, 0, 1], [1, 1, 1], [0, 1, 1]
    ],
  },
  // 5: -Z (NZ, back)
  {
    dir: [0, 0, -1],
    corners: [
      [1, 0, 0], [0, 0, 0], [0, 1, 0], [1, 1, 0]
    ],
  },
];

const AO_NEIGHBORS = [
  // Face 0: +X
  [
    [[1, 0, 1], [1, -1, 0], [1, -1, 1]],
    [[1, 0, -1], [1, -1, 0], [1, -1, -1]],
    [[1, 0, -1], [1, 1, 0], [1, 1, -1]],
    [[1, 0, 1], [1, 1, 0], [1, 1, 1]],
  ],
  // Face 1: -X
  [
    [[-1, 0, -1], [-1, -1, 0], [-1, -1, -1]],
    [[-1, 0, 1], [-1, -1, 0], [-1, -1, 1]],
    [[-1, 0, 1], [-1, 1, 0], [-1, 1, 1]],
    [[-1, 0, -1], [-1, 1, 0], [-1, 1, -1]],
  ],
  // Face 2: +Y
  [
    [[-1, 1, 0], [0, 1, 1], [-1, 1, 1]],
    [[1, 1, 0], [0, 1, 1], [1, 1, 1]],
    [[1, 1, 0], [0, 1, -1], [1, 1, -1]],
    [[-1, 1, 0], [0, 1, -1], [-1, 1, -1]],
  ],
  // Face 3: -Y
  [
    [[-1, -1, 0], [0, -1, -1], [-1, -1, -1]],
    [[1, -1, 0], [0, -1, -1], [1, -1, -1]],
    [[1, -1, 0], [0, -1, 1], [1, -1, 1]],
    [[-1, -1, 0], [0, -1, 1], [-1, -1, 1]],
  ],
  // Face 4: +Z
  [
    [[-1, 0, 1], [0, -1, 1], [-1, -1, 1]],
    [[1, 0, 1], [0, -1, 1], [1, -1, 1]],
    [[1, 0, 1], [0, 1, 1], [1, 1, 1]],
    [[-1, 0, 1], [0, 1, 1], [-1, 1, 1]],
  ],
  // Face 5: -Z
  [
    [[1, 0, -1], [0, -1, -1], [1, -1, -1]],
    [[-1, 0, -1], [0, -1, -1], [-1, -1, -1]],
    [[-1, 0, -1], [0, 1, -1], [-1, 1, -1]],
    [[1, 0, -1], [0, 1, -1], [1, 1, -1]],
  ],
];

// Reusable typed array buffers for zero GC overhead during chunk meshing
const MAX_CHUNK_FACES = CHUNK_SIZE_X * CHUNK_HEIGHT * CHUNK_SIZE_Z * 6;
const opaquePositions = new Float32Array(MAX_CHUNK_FACES * 4 * 3);
const opaqueNormals = new Float32Array(MAX_CHUNK_FACES * 4 * 3);
const opaqueUVs = new Float32Array(MAX_CHUNK_FACES * 4 * 2);
const opaqueColors = new Float32Array(MAX_CHUNK_FACES * 4 * 3);
const opaqueIndices = new Uint32Array(MAX_CHUNK_FACES * 6);

const transPositions = new Float32Array(MAX_CHUNK_FACES * 4 * 3);
const transNormals = new Float32Array(MAX_CHUNK_FACES * 4 * 3);
const transUVs = new Float32Array(MAX_CHUNK_FACES * 4 * 2);
const transColors = new Float32Array(MAX_CHUNK_FACES * 4 * 3);
const transIndices = new Uint32Array(MAX_CHUNK_FACES * 6);

// Fast AO calculation helper
function getAO(s1: boolean, s2: boolean, corner: boolean): number {
  if (s1 && s2) return 0.42;
  const count = (s1 ? 1 : 0) + (s2 ? 1 : 0) + (corner ? 1 : 0);
  if (count === 0) return 1.0;
  if (count === 1) return 0.82;
  if (count === 2) return 0.62;
  return 0.42;
}

export class VoxelWorld {
  public chunks: Map<string, ChunkData> = new Map();
  public modifiedBlocks: Record<string, Record<string, BlockType>> = {};
  public seed: number;
  public worldType: 'default' | 'flat' | 'plains' | 'mountains' | 'amplified' | 'desert' | 'islands';
  private noise: SeededNoise;
  private biomeNoise: SeededNoise;
  private oreNoise: SeededNoise;
  private underworld: UnderworldGenerator;
  public scene: THREE.Scene;
  private chunkMeshQueue: ChunkData[] = [];

  constructor(
    scene: THREE.Scene,
    _materials?: any,
    seed: number = 12345,
    worldType: 'default' | 'flat' | 'plains' | 'mountains' | 'amplified' | 'desert' | 'islands' = 'default',
    initialModifiedBlocks: Record<string, Record<string, BlockType>> = {}
  ) {
    this.scene = scene;
    this.seed = seed;
    this.worldType = worldType;
    this.modifiedBlocks = initialModifiedBlocks;

    this.noise = new SeededNoise(seed);
    this.biomeNoise = new SeededNoise(seed + 9999);
    this.oreNoise = new SeededNoise(seed + 55555);
    this.underworld = new UnderworldGenerator(seed);
  }

  public getChunkKey(cx: number, cz: number): string {
    return `${cx},${cz}`;
  }

  public getLocalIndex(lx: number, ly: number, lz: number): number {
    return lx + lz * CHUNK_SIZE_X + ly * (CHUNK_SIZE_X * CHUNK_SIZE_Z);
  }

  // Fast block check for solidity
  public isBlockSolid(gx: number, gy: number, gz: number): boolean {
    const block = this.getBlock(gx, gy, gz);
    if (block === BlockType.AIR || block === BlockType.WATER) return false;
    const config = BLOCK_REGISTRY[block];
    return !config?.isTransparent && !config?.isPlant;
  }

  // Get block at global coordinates
  public getBlock(gx: number, gy: number, gz: number): BlockType {
    if (gy < 0 || gy >= CHUNK_HEIGHT) return BlockType.AIR;

    const cx = Math.floor(gx / CHUNK_SIZE_X);
    const cz = Math.floor(gz / CHUNK_SIZE_Z);
    const chunk = this.chunks.get(this.getChunkKey(cx, cz));
    if (!chunk) return BlockType.AIR;

    const lx = ((gx % CHUNK_SIZE_X) + CHUNK_SIZE_X) % CHUNK_SIZE_X;
    const lz = ((gz % CHUNK_SIZE_Z) + CHUNK_SIZE_Z) % CHUNK_SIZE_Z;

    const index = this.getLocalIndex(lx, gy, lz);
    return chunk.blocks[index] as BlockType;
  }

  // Set block at global coordinates
  public setBlock(gx: number, gy: number, gz: number, blockType: BlockType): boolean {
    if (gy < 0 || gy >= CHUNK_HEIGHT) return false;

    const cx = Math.floor(gx / CHUNK_SIZE_X);
    const cz = Math.floor(gz / CHUNK_SIZE_Z);
    let chunk = this.chunks.get(this.getChunkKey(cx, cz));
    if (!chunk) {
      chunk = this.generateChunk(cx, cz);
      this.chunks.set(this.getChunkKey(cx, cz), chunk);
    }

    const lx = ((gx % CHUNK_SIZE_X) + CHUNK_SIZE_X) % CHUNK_SIZE_X;
    const lz = ((gz % CHUNK_SIZE_Z) + CHUNK_SIZE_Z) % CHUNK_SIZE_Z;

    const index = this.getLocalIndex(lx, gy, lz);
    chunk.blocks[index] = blockType;
    chunk.isDirty = true;

    // Update heightMap
    const hIdx = lx + lz * CHUNK_SIZE_X;
    if (blockType !== BlockType.AIR && blockType !== BlockType.WATER) {
      if (gy > chunk.heightMap[hIdx]) {
        chunk.heightMap[hIdx] = gy;
      }
    } else if (gy === chunk.heightMap[hIdx]) {
      let newH = 0;
      for (let y = gy - 1; y >= 0; y--) {
        const b = chunk.blocks[this.getLocalIndex(lx, y, lz)] as BlockType;
        if (b !== BlockType.AIR && b !== BlockType.WATER) {
          newH = y;
          break;
        }
      }
      chunk.heightMap[hIdx] = newH;
    }

    // Record in modifiedBlocks delta for persistent save
    const chunkKey = this.getChunkKey(cx, cz);
    if (!this.modifiedBlocks[chunkKey]) {
      this.modifiedBlocks[chunkKey] = {};
    }
    this.modifiedBlocks[chunkKey][`${lx},${gy},${lz}`] = blockType;

    this.rebuildChunkMesh(chunk);

    // Check border neighbors
    if (lx === 0) this.markChunkDirty(cx - 1, cz);
    if (lx === CHUNK_SIZE_X - 1) this.markChunkDirty(cx + 1, cz);
    if (lz === 0) this.markChunkDirty(cx, cz - 1);
    if (lz === CHUNK_SIZE_Z - 1) this.markChunkDirty(cx, cz + 1);

    return true;
  }

  private markChunkDirty(cx: number, cz: number) {
    const chunk = this.chunks.get(this.getChunkKey(cx, cz));
    if (chunk) {
      chunk.isDirty = true;
      this.rebuildChunkMesh(chunk);
    }
  }

  public getOrCreateChunk(cx: number, cz: number, shouldMesh: boolean = true): ChunkData {
    const key = this.getChunkKey(cx, cz);
    let chunk = this.chunks.get(key);
    if (!chunk) {
      chunk = this.generateChunk(cx, cz);
      this.chunks.set(key, chunk);
      if (shouldMesh) {
        this.rebuildChunkMesh(chunk);
      }
    }
    return chunk;
  }

  // Procedural Chunk Generator
  private generateChunk(cx: number, cz: number): ChunkData {
    const blocks = new Uint8Array(CHUNK_SIZE_X * CHUNK_HEIGHT * CHUNK_SIZE_Z);
    const chunkKey = this.getChunkKey(cx, cz);
    const deltas = this.modifiedBlocks[chunkKey] || {};

    const startGx = cx * CHUNK_SIZE_X;
    const startGz = cz * CHUNK_SIZE_Z;

    if (this.worldType === 'flat') {
      // Superflat world: Bedrock (Y=0), Dirt (Y=1,2), Grass (Y=3)
      for (let lx = 0; lx < CHUNK_SIZE_X; lx++) {
        for (let lz = 0; lz < CHUNK_SIZE_Z; lz++) {
          blocks[this.getLocalIndex(lx, 0, lz)] = BlockType.BEDROCK;
          blocks[this.getLocalIndex(lx, 1, lz)] = BlockType.DIRT;
          blocks[this.getLocalIndex(lx, 2, lz)] = BlockType.DIRT;
          blocks[this.getLocalIndex(lx, 3, lz)] = BlockType.GRASS;
        }
      }
    } else {
      // Procedural heightmap & biome generation
      for (let lx = 0; lx < CHUNK_SIZE_X; lx++) {
        for (let lz = 0; lz < CHUNK_SIZE_Z; lz++) {
          const gx = startGx + lx;
          const gz = startGz + lz;

          // Biome noise (-1 to +1)
          const biomeVal = this.biomeNoise.fbm2D(gx * 0.006, gz * 0.006, 3);
          let isDesert = this.worldType === 'desert' || biomeVal > 0.45;
          const isTaiga = biomeVal > 0.2 && biomeVal <= 0.45;
          const isPlains = this.worldType === 'plains' || (biomeVal >= -0.15 && biomeVal <= 0.2);
          const isBirchForest = biomeVal >= -0.45 && biomeVal < -0.15;
          const isJungle = biomeVal >= -0.7 && biomeVal < -0.45;
          const isCherryBiome = biomeVal < -0.7;

          let height = 26;

          if (this.worldType === 'plains') {
            // Gentle rolling green meadows with subtle elevation shifts
            const plainH = this.noise.fbm2D(gx * 0.012, gz * 0.012, 3, 0.4);
            height = Math.floor(25 + plainH * 6);
          } else if (this.worldType === 'mountains') {
            // Sharp ridge noise for epic mountain crests & snowy peaks
            const ridge = 1 - Math.abs(this.noise.fbm2D(gx * 0.012, gz * 0.012, 5, 0.55));
            height = Math.floor(20 + Math.pow(Math.max(0, ridge), 2.2) * 36);
          } else if (this.worldType === 'amplified') {
            // Extreme vertical terrain scale with 40-50 block cliffs
            const ampBase = this.noise.fbm2D(gx * 0.015, gz * 0.015, 5, 0.65);
            height = Math.floor(22 + Math.pow(Math.max(0, ampBase + 0.35), 1.6) * 38);
          } else if (this.worldType === 'desert') {
            // Sweeping golden sand dunes
            const dune = Math.sin(gx * 0.03) * Math.cos(gz * 0.03) * 5 + this.noise.fbm2D(gx * 0.012, gz * 0.012, 3) * 8;
            height = Math.floor(25 + dune);
          } else if (this.worldType === 'islands') {
            // Tropical ocean archipelago with islands and sandy shores
            const distNoise = this.noise.fbm2D(gx * 0.008, gz * 0.008, 4);
            height = Math.floor(14 + Math.max(0, distNoise + 0.05) * 24);
          } else {
            // Default Overworld: Blends mountains, hills, plains, deserts & rivers
            const contH = this.noise.fbm2D(gx * 0.008, gz * 0.008, 3, 0.5);
            const ridgeH = 1 - Math.abs(this.noise.fbm2D(gx * 0.018, gz * 0.018, 4, 0.55));
            const riverChannel = Math.abs(this.biomeNoise.fbm2D(gx * 0.009 + 200, gz * 0.009 + 200, 2));

            if (riverChannel < 0.04) {
              // Curving rivers cutting into terrain
              height = Math.floor(SEA_LEVEL - 2 + riverChannel * 25);
            } else if (biomeVal > 0.45) {
              // Desert dunes
              height = Math.floor(24 + contH * 10);
            } else if (biomeVal < -0.6) {
              // Mountain ranges in default world
              height = Math.floor(22 + Math.pow(Math.max(0, ridgeH), 1.8) * 32);
            } else {
              // Rolling hills & plains
              height = Math.floor(25 + contH * 12);
            }
          }

          height = Math.min(CHUNK_HEIGHT - 6, Math.max(1, height));

          // Generate Underworld (Bedrock, Deepslate, Stone veins, Caves, Ores)
          this.underworld.generateColumn(blocks, lx, lz, gx, gz, height, isDesert);

          // Apply surface top block
          const topIdx = this.getLocalIndex(lx, height, lz);
          if (height < SEA_LEVEL + 1) {
            blocks[topIdx] = BlockType.SAND;
          } else if (isDesert) {
            blocks[topIdx] = BlockType.SAND;
          } else if (height >= 44 && (this.worldType === 'mountains' || biomeVal < -0.6)) {
            blocks[topIdx] = BlockType.SNOW;
          } else if (isCherryBiome && this.worldType === 'default') {
            blocks[topIdx] = BlockType.MOSS_BLOCK;
          } else {
            blocks[topIdx] = BlockType.GRASS;
          }

          // Fill water up to SEA_LEVEL
          if (height < SEA_LEVEL) {
            for (let y = height + 1; y <= SEA_LEVEL; y++) {
              blocks[this.getLocalIndex(lx, y, lz)] = BlockType.WATER;
            }
          }

          // Flora: Trees, Flowers, Mushrooms, Cacti, Grass
          if (height >= SEA_LEVEL + 1) {
            const treeChance = this.noise.noise2D(gx * 0.2, gz * 0.2);
            if (lx >= 2 && lx <= CHUNK_SIZE_X - 3 && lz >= 2 && lz <= CHUNK_SIZE_Z - 3) {
              if (isCherryBiome && this.worldType === 'default' && treeChance > 0.3) {
                this.growTree(blocks, lx, height + 1, lz, BlockType.CHERRY_LOG, BlockType.CHERRY_LEAVES);
              } else if (isBirchForest && this.worldType === 'default' && treeChance > 0.25) {
                this.growTree(blocks, lx, height + 1, lz, BlockType.BIRCH_LOG, BlockType.BIRCH_LEAVES);
              } else if (isTaiga && treeChance > 0.3) {
                this.growSpruceTree(blocks, lx, height + 1, lz);
              } else if (isJungle && treeChance > 0.2) {
                this.growJungleTree(blocks, lx, height + 1, lz);
              } else if (isPlains && treeChance > 0.6) {
                this.growTree(blocks, lx, height + 1, lz, BlockType.OAK_LOG, BlockType.OAK_LEAVES);
              } else if (this.worldType === 'islands' && treeChance > 0.4) {
                this.growJungleTree(blocks, lx, height + 1, lz);
              }
            }

            if (isDesert && treeChance > 0.55 && lx >= 1 && lz >= 1) {
              const cHeight = 2 + Math.floor(Math.abs(treeChance) * 2);
              for (let cy = 0; cy < cHeight; cy++) {
                if (height + 1 + cy < CHUNK_HEIGHT - 2) {
                  blocks[this.getLocalIndex(lx, height + 1 + cy, lz)] = BlockType.CACTUS;
                }
              }
            } else if (!isDesert) {
              const plantNoise = this.noise.noise2D(gx * 0.5, gz * 0.5);
              const plantIdx = this.getLocalIndex(lx, height + 1, lz);
              if (blocks[plantIdx] === BlockType.AIR) {
                if (plantNoise > 0.55) {
                  blocks[plantIdx] = BlockType.SHORT_GRASS;
                } else if (plantNoise > 0.35) {
                  blocks[plantIdx] = BlockType.TALL_GRASS;
                } else if (plantNoise < -0.65) {
                  blocks[plantIdx] = BlockType.POPPY;
                } else if (plantNoise < -0.45) {
                  blocks[plantIdx] = BlockType.DANDELION;
                } else if (isJungle && plantNoise < -0.3) {
                  blocks[plantIdx] = Math.random() > 0.5 ? BlockType.RED_MUSHROOM : BlockType.BROWN_MUSHROOM;
                }
              }
            }
          }
        }
      }
    }

    // Apply saved modifications/deltas
    for (const [coordKey, blockType] of Object.entries(deltas)) {
      const [dlx, dly, dlz] = coordKey.split(',').map(Number);
      if (
        dlx >= 0 && dlx < CHUNK_SIZE_X &&
        dly >= 0 && dly < CHUNK_HEIGHT &&
        dlz >= 0 && dlz < CHUNK_SIZE_Z
      ) {
        blocks[this.getLocalIndex(dlx, dly, dlz)] = blockType;
      }
    }

    // Build heightMap for O(1) vertical terrain surface lookups
    const heightMap = new Uint8Array(CHUNK_SIZE_X * CHUNK_SIZE_Z);
    for (let lx = 0; lx < CHUNK_SIZE_X; lx++) {
      for (let lz = 0; lz < CHUNK_SIZE_Z; lz++) {
        let h = 0;
        for (let y = CHUNK_HEIGHT - 1; y >= 0; y--) {
          const b = blocks[lx + lz * CHUNK_SIZE_X + y * (CHUNK_SIZE_X * CHUNK_SIZE_Z)] as BlockType;
          if (b !== BlockType.AIR && b !== BlockType.WATER) {
            h = y;
            break;
          }
        }
        heightMap[lx + lz * CHUNK_SIZE_X] = h;
      }
    }

    return {
      cx,
      cz,
      blocks,
      heightMap,
      isDirty: true,
      meshes: [],
    };
  }

  // Grow customizable tree inside chunk
  private growTree(
    blocks: Uint8Array,
    lx: number,
    baseLy: number,
    lz: number,
    logType: BlockType,
    leafType: BlockType
  ) {
    const trunkHeight = 4;
    if (baseLy + trunkHeight + 2 >= CHUNK_HEIGHT) return;

    for (let ty = 0; ty < trunkHeight; ty++) {
      blocks[this.getLocalIndex(lx, baseLy + ty, lz)] = logType;
    }

    const leafStart = baseLy + trunkHeight - 2;
    for (let y = leafStart; y <= baseLy + trunkHeight + 1; y++) {
      const radius = y >= baseLy + trunkHeight ? 1 : 2;
      for (let ox = -radius; ox <= radius; ox++) {
        for (let oz = -radius; oz <= radius; oz++) {
          if (ox === 0 && oz === 0 && y < baseLy + trunkHeight) continue;
          if (Math.abs(ox) === radius && Math.abs(oz) === radius && y === baseLy + trunkHeight + 1) continue;

          const nlx = lx + ox;
          const nlz = lz + oz;
          if (nlx >= 0 && nlx < CHUNK_SIZE_X && nlz >= 0 && nlz < CHUNK_SIZE_Z) {
            const idx = this.getLocalIndex(nlx, y, nlz);
            if (blocks[idx] === BlockType.AIR) {
              blocks[idx] = leafType;
            }
          }
        }
      }
    }
  }

  // Grow Spruce Tree (Conical shape)
  private growSpruceTree(blocks: Uint8Array, lx: number, baseLy: number, lz: number) {
    const trunkHeight = 6;
    if (baseLy + trunkHeight + 2 >= CHUNK_HEIGHT) return;

    for (let ty = 0; ty < trunkHeight; ty++) {
      blocks[this.getLocalIndex(lx, baseLy + ty, lz)] = BlockType.SPRUCE_LOG;
    }

    const topY = baseLy + trunkHeight;
    // Spire top
    if (lx >= 0 && lx < CHUNK_SIZE_X && lz >= 0 && lz < CHUNK_SIZE_Z) {
      blocks[this.getLocalIndex(lx, topY, lz)] = BlockType.SPRUCE_LEAVES;
    }

    // Layered foliage down
    for (let y = topY - 1; y >= baseLy + 2; y--) {
      const radius = (topY - y) % 2 === 0 ? 2 : 1;
      for (let ox = -radius; ox <= radius; ox++) {
        for (let oz = -radius; oz <= radius; oz++) {
          if (ox === 0 && oz === 0 && y < topY - 2) continue;
          if (Math.abs(ox) === radius && Math.abs(oz) === radius && radius > 1) continue;

          const nlx = lx + ox;
          const nlz = lz + oz;
          if (nlx >= 0 && nlx < CHUNK_SIZE_X && nlz >= 0 && nlz < CHUNK_SIZE_Z) {
            const idx = this.getLocalIndex(nlx, y, nlz);
            if (blocks[idx] === BlockType.AIR) {
              blocks[idx] = BlockType.SPRUCE_LEAVES;
            }
          }
        }
      }
    }
  }

  // Grow Jungle Tree (Tall trunk, wide top canopy)
  private growJungleTree(blocks: Uint8Array, lx: number, baseLy: number, lz: number) {
    const trunkHeight = 8;
    if (baseLy + trunkHeight + 2 >= CHUNK_HEIGHT) return;

    for (let ty = 0; ty < trunkHeight; ty++) {
      blocks[this.getLocalIndex(lx, baseLy + ty, lz)] = BlockType.JUNGLE_LOG;
    }

    const topY = baseLy + trunkHeight - 2;
    for (let y = topY; y <= baseLy + trunkHeight + 1; y++) {
      const radius = y >= baseLy + trunkHeight ? 1 : 2;
      for (let ox = -radius; ox <= radius; ox++) {
        for (let oz = -radius; oz <= radius; oz++) {
          if (ox === 0 && oz === 0 && y < baseLy + trunkHeight) continue;

          const nlx = lx + ox;
          const nlz = lz + oz;
          if (nlx >= 0 && nlx < CHUNK_SIZE_X && nlz >= 0 && nlz < CHUNK_SIZE_Z) {
            const idx = this.getLocalIndex(nlx, y, nlz);
            if (blocks[idx] === BlockType.AIR) {
              blocks[idx] = BlockType.JUNGLE_LEAVES;
            }
          }
        }
      }
    }
  }

  // High-performance single-merged BufferGeometry mesh generator per chunk
  public rebuildChunkMesh(chunk: ChunkData) {
    for (const mesh of chunk.meshes) {
      this.scene.remove(mesh);
      mesh.geometry.dispose();
    }
    chunk.meshes = [];

    const atlas = getTextureAtlas();
    const startGx = chunk.cx * CHUNK_SIZE_X;
    const startGz = chunk.cz * CHUNK_SIZE_Z;

    let opaqueVertCount = 0;
    let opaqueIdxCount = 0;
    let transVertCount = 0;
    let transIdxCount = 0;

    const getBlockFast = (lx: number, ly: number, lz: number): BlockType => {
      if (ly < 0 || ly >= CHUNK_HEIGHT) return BlockType.AIR;
      if (lx >= 0 && lx < CHUNK_SIZE_X && lz >= 0 && lz < CHUNK_SIZE_Z) {
        return chunk.blocks[lx + lz * CHUNK_SIZE_X + ly * (CHUNK_SIZE_X * CHUNK_SIZE_Z)] as BlockType;
      }
      return this.getBlock(startGx + lx, ly, startGz + lz);
    };

    const isSolidFast = (lx: number, ly: number, lz: number): boolean => {
      const b = getBlockFast(lx, ly, lz);
      if (b === BlockType.AIR || b === BlockType.WATER) return false;
      const config = BLOCK_REGISTRY[b];
      return !config?.isTransparent && !config?.isPlant;
    };

    const appendCuboid = (
      x0: number, y0: number, z0: number,
      x1: number, y1: number, z1: number,
      tileId: number,
      trans: boolean,
      gx: number, ly: number, gz: number
    ) => {
      const pArr = trans ? transPositions : opaquePositions;
      const nArr = trans ? transNormals : opaqueNormals;
      const uvArr = trans ? transUVs : opaqueUVs;
      const cArr = trans ? transColors : opaqueColors;
      const iArr = trans ? transIndices : opaqueIndices;

      const [u0, v0, u1, v1] = atlas.getTileUVs(tileId);

      const faces = [
        { norm: [1, 0, 0], verts: [[x1, y0, z1], [x1, y0, z0], [x1, y1, z0], [x1, y1, z1]] },
        { norm: [-1, 0, 0], verts: [[x0, y0, z0], [x0, y0, z1], [x0, y1, z1], [x0, y1, z0]] },
        { norm: [0, 1, 0], verts: [[x0, y1, z1], [x1, y1, z1], [x1, y1, z0], [x0, y1, z0]] },
        { norm: [0, -1, 0], verts: [[x0, y0, z0], [x1, y0, z0], [x1, y0, z1], [x0, y0, z1]] },
        { norm: [0, 0, 1], verts: [[x0, y0, z1], [x1, y0, z1], [x1, y1, z1], [x0, y1, z1]] },
        { norm: [0, 0, -1], verts: [[x1, y0, z0], [x0, y0, z0], [x0, y1, z0], [x1, y1, z0]] }
      ];

      for (const f of faces) {
        const vBase = trans ? transVertCount : opaqueVertCount;
        const pOff = vBase * 3;
        const uOff = vBase * 2;
        const nOff = vBase * 3;
        const cOff = vBase * 3;

        for (let c = 0; c < 4; c++) {
          pArr[pOff + c * 3 + 0] = gx + f.verts[c][0];
          pArr[pOff + c * 3 + 1] = ly + f.verts[c][1];
          pArr[pOff + c * 3 + 2] = gz + f.verts[c][2];

          nArr[nOff + c * 3 + 0] = f.norm[0];
          nArr[nOff + c * 3 + 1] = f.norm[1];
          nArr[nOff + c * 3 + 2] = f.norm[2];

          const ao = f.norm[1] > 0 ? 1.0 : (f.norm[1] < 0 ? 0.6 : 0.85);
          cArr[cOff + c * 3 + 0] = ao;
          cArr[cOff + c * 3 + 1] = ao;
          cArr[cOff + c * 3 + 2] = ao;
        }

        uvArr[uOff + 0] = u0; uvArr[uOff + 1] = v0;
        uvArr[uOff + 2] = u1; uvArr[uOff + 3] = v0;
        uvArr[uOff + 4] = u1; uvArr[uOff + 5] = v1;
        uvArr[uOff + 6] = u0; uvArr[uOff + 7] = v1;

        const iOff = trans ? transIdxCount : opaqueIdxCount;
        iArr[iOff + 0] = vBase + 0;
        iArr[iOff + 1] = vBase + 1;
        iArr[iOff + 2] = vBase + 2;
        iArr[iOff + 3] = vBase + 0;
        iArr[iOff + 4] = vBase + 2;
        iArr[iOff + 5] = vBase + 3;

        if (trans) {
          transVertCount += 4;
          transIdxCount += 6;
        } else {
          opaqueVertCount += 4;
          opaqueIdxCount += 6;
        }
      }
    };

    for (let lx = 0; lx < CHUNK_SIZE_X; lx++) {
      for (let ly = 0; ly < CHUNK_HEIGHT; ly++) {
        for (let lz = 0; lz < CHUNK_SIZE_Z; lz++) {
          const idx = lx + lz * CHUNK_SIZE_X + ly * (CHUNK_SIZE_X * CHUNK_SIZE_Z);
          const blockType = chunk.blocks[idx] as BlockType;
          if (blockType === BlockType.AIR) continue;

          const config = BLOCK_REGISTRY[blockType];
          const isTransparent = !!config?.isTransparent;
          const gx = startGx + lx;
          const gz = startGz + lz;

          // Custom Block Shape Meshing (Slabs, Stairs, Fences, Walls, Doors, Trapdoors, Lanterns, Panes)
          if (config?.shape && config.shape !== 'cube') {
            const tileId = atlas.getBlockFaceTileId(blockType, 0);
            const isTrans = !!config.isTransparent || config.shape === 'stairs' || config.shape === 'slab';

            if (config.shape === 'slab') {
              if (config.isTopSlab) {
                appendCuboid(0, 0.5, 0, 1, 1, 1, tileId, isTrans, gx, ly, gz);
              } else {
                appendCuboid(0, 0, 0, 1, 0.5, 1, tileId, isTrans, gx, ly, gz);
              }
              continue;
            }

            if (config.shape === 'stairs') {
              const facing = config.facing || 'N';
              const isUp = !!config.isUpsideDown;
              if (!isUp) {
                appendCuboid(0, 0, 0, 1, 0.5, 1, tileId, isTrans, gx, ly, gz);
                if (facing === 'N') appendCuboid(0, 0.5, 0.5, 1, 1, 1, tileId, isTrans, gx, ly, gz);
                else if (facing === 'S') appendCuboid(0, 0.5, 0, 1, 1, 0.5, tileId, isTrans, gx, ly, gz);
                else if (facing === 'E') appendCuboid(0, 0.5, 0, 0.5, 1, 1, tileId, isTrans, gx, ly, gz);
                else if (facing === 'W') appendCuboid(0.5, 0.5, 0, 1, 1, 1, tileId, isTrans, gx, ly, gz);
              } else {
                appendCuboid(0, 0.5, 0, 1, 1, 1, tileId, isTrans, gx, ly, gz);
                if (facing === 'N') appendCuboid(0, 0, 0.5, 1, 0.5, 1, tileId, isTrans, gx, ly, gz);
                else if (facing === 'S') appendCuboid(0, 0, 0, 1, 0.5, 0.5, tileId, isTrans, gx, ly, gz);
                else if (facing === 'E') appendCuboid(0, 0, 0, 0.5, 0.5, 1, tileId, isTrans, gx, ly, gz);
                else if (facing === 'W') appendCuboid(0.5, 0, 0, 1, 0.5, 1, tileId, isTrans, gx, ly, gz);
              }
              continue;
            }

            if (config.shape === 'fence') {
              appendCuboid(0.375, 0, 0.375, 0.625, 1, 0.625, tileId, true, gx, ly, gz);
              const nN = getBlockFast(lx, ly, lz - 1);
              const nS = getBlockFast(lx, ly, lz + 1);
              const nE = getBlockFast(lx + 1, ly, lz);
              const nW = getBlockFast(lx - 1, ly, lz);

              if (nN !== BlockType.AIR && (BLOCK_REGISTRY[nN]?.shape === 'fence' || !BLOCK_REGISTRY[nN]?.isTransparent)) {
                appendCuboid(0.4375, 0.375, 0, 0.5625, 0.5625, 0.375, tileId, true, gx, ly, gz);
                appendCuboid(0.4375, 0.75, 0, 0.5625, 0.9375, 0.375, tileId, true, gx, ly, gz);
              }
              if (nS !== BlockType.AIR && (BLOCK_REGISTRY[nS]?.shape === 'fence' || !BLOCK_REGISTRY[nS]?.isTransparent)) {
                appendCuboid(0.4375, 0.375, 0.625, 0.5625, 0.5625, 1, tileId, true, gx, ly, gz);
                appendCuboid(0.4375, 0.75, 0.625, 0.5625, 0.9375, 1, tileId, true, gx, ly, gz);
              }
              if (nE !== BlockType.AIR && (BLOCK_REGISTRY[nE]?.shape === 'fence' || !BLOCK_REGISTRY[nE]?.isTransparent)) {
                appendCuboid(0.625, 0.375, 0.4375, 1, 0.5625, 0.5625, tileId, true, gx, ly, gz);
                appendCuboid(0.625, 0.75, 0.4375, 1, 0.9375, 0.5625, tileId, true, gx, ly, gz);
              }
              if (nW !== BlockType.AIR && (BLOCK_REGISTRY[nW]?.shape === 'fence' || !BLOCK_REGISTRY[nW]?.isTransparent)) {
                appendCuboid(0, 0.375, 0.4375, 0.375, 0.5625, 0.5625, tileId, true, gx, ly, gz);
                appendCuboid(0, 0.75, 0.4375, 0.375, 0.9375, 0.5625, tileId, true, gx, ly, gz);
              }
              continue;
            }

            if (config.shape === 'wall') {
              appendCuboid(0.25, 0, 0.25, 0.75, 1, 0.75, tileId, true, gx, ly, gz);
              const nN = getBlockFast(lx, ly, lz - 1);
              const nS = getBlockFast(lx, ly, lz + 1);
              const nE = getBlockFast(lx + 1, ly, lz);
              const nW = getBlockFast(lx - 1, ly, lz);

              if (nN !== BlockType.AIR && (BLOCK_REGISTRY[nN]?.shape === 'wall' || !BLOCK_REGISTRY[nN]?.isTransparent)) {
                appendCuboid(0.3125, 0, 0, 0.6875, 0.8125, 0.25, tileId, true, gx, ly, gz);
              }
              if (nS !== BlockType.AIR && (BLOCK_REGISTRY[nS]?.shape === 'wall' || !BLOCK_REGISTRY[nS]?.isTransparent)) {
                appendCuboid(0.3125, 0, 0.75, 0.6875, 0.8125, 1, tileId, true, gx, ly, gz);
              }
              if (nE !== BlockType.AIR && (BLOCK_REGISTRY[nE]?.shape === 'wall' || !BLOCK_REGISTRY[nE]?.isTransparent)) {
                appendCuboid(0.75, 0, 0.3125, 1, 0.8125, 0.6875, tileId, true, gx, ly, gz);
              }
              if (nW !== BlockType.AIR && (BLOCK_REGISTRY[nW]?.shape === 'wall' || !BLOCK_REGISTRY[nW]?.isTransparent)) {
                appendCuboid(0, 0, 0.3125, 0.25, 0.8125, 0.6875, tileId, true, gx, ly, gz);
              }
              continue;
            }

            if (config.shape === 'door') {
              const facing = config.facing || 'N';
              if (facing === 'N' || facing === 'S') {
                appendCuboid(0, 0, 0.4375, 1, 1, 0.5625, tileId, true, gx, ly, gz);
              } else {
                appendCuboid(0.4375, 0, 0, 0.5625, 1, 1, tileId, true, gx, ly, gz);
              }
              continue;
            }

            if (config.shape === 'trapdoor') {
              appendCuboid(0, 0, 0, 1, 0.18, 1, tileId, true, gx, ly, gz);
              continue;
            }

            if (config.shape === 'pane') {
              appendCuboid(0.4375, 0, 0, 0.5625, 1, 1, tileId, true, gx, ly, gz);
              continue;
            }

            if (config.shape === 'lantern') {
              appendCuboid(0.35, 0.1, 0.35, 0.65, 0.6, 0.65, tileId, true, gx, ly, gz);
              appendCuboid(0.42, 0.6, 0.42, 0.58, 0.75, 0.58, tileId, true, gx, ly, gz);
              continue;
            }
          }

          // Special Cross-Quad rendering for Plants (Flowers, Grass, Mushrooms)
          if (config?.isPlant) {
            const tileId = atlas.getBlockFaceTileId(blockType, 0);
            const [u0, v0, u1, v1] = atlas.getTileUVs(tileId);
            const vBase = transVertCount;

            const pIdx = vBase * 3;
            const uIdx = vBase * 2;
            const nIdx = vBase * 3;
            const cIdx = vBase * 3;

            // Diagonal quad 1: (0.14, 0, 0.14) to (0.86, 1, 0.86)
            transPositions[pIdx + 0] = gx + 0.14; transPositions[pIdx + 1] = ly; transPositions[pIdx + 2] = gz + 0.14;
            transPositions[pIdx + 3] = gx + 0.86; transPositions[pIdx + 4] = ly; transPositions[pIdx + 5] = gz + 0.86;
            transPositions[pIdx + 6] = gx + 0.86; transPositions[pIdx + 7] = ly + 1.0; transPositions[pIdx + 8] = gz + 0.86;
            transPositions[pIdx + 9] = gx + 0.14; transPositions[pIdx + 10] = ly + 1.0; transPositions[pIdx + 11] = gz + 0.14;

            // Diagonal quad 2: (0.86, 0, 0.14) to (0.14, 1, 0.86)
            transPositions[pIdx + 12] = gx + 0.86; transPositions[pIdx + 13] = ly; transPositions[pIdx + 14] = gz + 0.14;
            transPositions[pIdx + 15] = gx + 0.14; transPositions[pIdx + 16] = ly; transPositions[pIdx + 17] = gz + 0.86;
            transPositions[pIdx + 18] = gx + 0.14; transPositions[pIdx + 19] = ly + 1.0; transPositions[pIdx + 20] = gz + 0.86;
            transPositions[pIdx + 21] = gx + 0.86; transPositions[pIdx + 22] = ly + 1.0; transPositions[pIdx + 23] = gz + 0.14;

            for (let i = 0; i < 8; i++) {
              transNormals[nIdx + i * 3 + 0] = 0;
              transNormals[nIdx + i * 3 + 1] = 1;
              transNormals[nIdx + i * 3 + 2] = 0;

              transColors[cIdx + i * 3 + 0] = 1.0;
              transColors[cIdx + i * 3 + 1] = 1.0;
              transColors[cIdx + i * 3 + 2] = 1.0;
            }

            transUVs[uIdx + 0] = u0; transUVs[uIdx + 1] = v0;
            transUVs[uIdx + 2] = u1; transUVs[uIdx + 3] = v0;
            transUVs[uIdx + 4] = u1; transUVs[uIdx + 5] = v1;
            transUVs[uIdx + 6] = u0; transUVs[uIdx + 7] = v1;

            transUVs[uIdx + 8] = u0; transUVs[uIdx + 9] = v0;
            transUVs[uIdx + 10] = u1; transUVs[uIdx + 11] = v0;
            transUVs[uIdx + 12] = u1; transUVs[uIdx + 13] = v1;
            transUVs[uIdx + 14] = u0; transUVs[uIdx + 15] = v1;

            const iIdx = transIdxCount;
            transIndices[iIdx + 0] = vBase + 0; transIndices[iIdx + 1] = vBase + 1; transIndices[iIdx + 2] = vBase + 2;
            transIndices[iIdx + 3] = vBase + 0; transIndices[iIdx + 4] = vBase + 2; transIndices[iIdx + 5] = vBase + 3;

            transIndices[iIdx + 6] = vBase + 4; transIndices[iIdx + 7] = vBase + 5; transIndices[iIdx + 8] = vBase + 6;
            transIndices[iIdx + 9] = vBase + 4; transIndices[iIdx + 10] = vBase + 6; transIndices[iIdx + 11] = vBase + 7;

            transVertCount += 8;
            transIdxCount += 12;
            continue;
          }

          for (let faceIdx = 0; faceIdx < 6; faceIdx++) {
            const face = FACE_DEFINITIONS[faceIdx];
            const nlx = lx + face.dir[0];
            const nly = ly + face.dir[1];
            const nlz = lz + face.dir[2];

            const neighbor = getBlockFast(nlx, nly, nlz);
            let showFace = false;

            if (neighbor === BlockType.AIR) {
              showFace = true;
            } else {
              const neighborConfig = BLOCK_REGISTRY[neighbor];
              if (neighborConfig?.isTransparent) {
                if (blockType === BlockType.WATER && neighbor === BlockType.WATER) {
                  showFace = false;
                } else {
                  showFace = true;
                }
              }
            }

            if (showFace) {
              const tileId = atlas.getBlockFaceTileId(blockType, faceIdx);
              const [u0, v0, u1, v1] = atlas.getTileUVs(tileId);

              const pArr = isTransparent ? transPositions : opaquePositions;
              const nArr = isTransparent ? transNormals : opaqueNormals;
              const uvArr = isTransparent ? transUVs : opaqueUVs;
              const cArr = isTransparent ? transColors : opaqueColors;
              const iArr = isTransparent ? transIndices : opaqueIndices;

              const vBase = isTransparent ? transVertCount : opaqueVertCount;
              const iBase = isTransparent ? transIdxCount : opaqueIdxCount;

              const corners = face.corners;
              const pOffset = vBase * 3;
              const uOffset = vBase * 2;
              const nOffset = vBase * 3;
              const cOffset = vBase * 3;

              for (let c = 0; c < 4; c++) {
                pArr[pOffset + c * 3 + 0] = gx + corners[c][0];
                pArr[pOffset + c * 3 + 1] = ly + corners[c][1];
                pArr[pOffset + c * 3 + 2] = gz + corners[c][2];

                nArr[nOffset + c * 3 + 0] = face.dir[0];
                nArr[nOffset + c * 3 + 1] = face.dir[1];
                nArr[nOffset + c * 3 + 2] = face.dir[2];

                // AO calculation
                let ao = 1.0;
                if (!isTransparent && blockType !== BlockType.WATER) {
                  const aoOffsets = AO_NEIGHBORS[faceIdx][c];
                  const s1 = isSolidFast(lx + aoOffsets[0][0], ly + aoOffsets[0][1], lz + aoOffsets[0][2]);
                  const s2 = isSolidFast(lx + aoOffsets[1][0], ly + aoOffsets[1][1], lz + aoOffsets[1][2]);
                  const cornerSolid = isSolidFast(lx + aoOffsets[2][0], ly + aoOffsets[2][1], lz + aoOffsets[2][2]);
                  ao = getAO(s1, s2, cornerSolid);
                }

                cArr[cOffset + c * 3 + 0] = ao;
                cArr[cOffset + c * 3 + 1] = ao;
                cArr[cOffset + c * 3 + 2] = ao;
              }

              uvArr[uOffset + 0] = u0; uvArr[uOffset + 1] = v0;
              uvArr[uOffset + 2] = u1; uvArr[uOffset + 3] = v0;
              uvArr[uOffset + 4] = u1; uvArr[uOffset + 5] = v1;
              uvArr[uOffset + 6] = u0; uvArr[uOffset + 7] = v1;

              iArr[iBase + 0] = vBase + 0;
              iArr[iBase + 1] = vBase + 1;
              iArr[iBase + 2] = vBase + 2;
              iArr[iBase + 3] = vBase + 0;
              iArr[iBase + 4] = vBase + 2;
              iArr[iBase + 5] = vBase + 3;

              if (isTransparent) {
                transVertCount += 4;
                transIdxCount += 6;
              } else {
                opaqueVertCount += 4;
                opaqueIdxCount += 6;
              }
            }
          }
        }
      }
    }

    // Build single merged Opaque Mesh
    if (opaqueVertCount > 0) {
      const geo = new THREE.BufferGeometry();
      geo.setAttribute('position', new THREE.BufferAttribute(opaquePositions.slice(0, opaqueVertCount * 3), 3));
      geo.setAttribute('normal', new THREE.BufferAttribute(opaqueNormals.slice(0, opaqueVertCount * 3), 3));
      geo.setAttribute('uv', new THREE.BufferAttribute(opaqueUVs.slice(0, opaqueVertCount * 2), 2));
      geo.setAttribute('color', new THREE.BufferAttribute(opaqueColors.slice(0, opaqueVertCount * 3), 3));
      geo.setIndex(new THREE.BufferAttribute(opaqueIndices.slice(0, opaqueIdxCount), 1));
      geo.computeBoundingSphere();

      const mesh = new THREE.Mesh(geo, atlas.opaqueMaterial);
      mesh.frustumCulled = true;
      this.scene.add(mesh);
      chunk.meshes.push(mesh);
    }

    // Build single merged Transparent Mesh
    if (transVertCount > 0) {
      const geo = new THREE.BufferGeometry();
      geo.setAttribute('position', new THREE.BufferAttribute(transPositions.slice(0, transVertCount * 3), 3));
      geo.setAttribute('normal', new THREE.BufferAttribute(transNormals.slice(0, transVertCount * 3), 3));
      geo.setAttribute('uv', new THREE.BufferAttribute(transUVs.slice(0, transVertCount * 2), 2));
      geo.setAttribute('color', new THREE.BufferAttribute(transColors.slice(0, transVertCount * 3), 3));
      geo.setIndex(new THREE.BufferAttribute(transIndices.slice(0, transIdxCount), 1));
      geo.computeBoundingSphere();

      const mesh = new THREE.Mesh(geo, atlas.transparentMaterial);
      mesh.frustumCulled = true;
      this.scene.add(mesh);
      chunk.meshes.push(mesh);
    }

    chunk.isDirty = false;
  }

  // Process time-sliced background chunk meshing queue with 3ms max budget per frame
  public processChunkQueue(maxPerFrame = 2, maxTimeMs = 3) {
    const startTime = performance.now();
    let processed = 0;
    while (this.chunkMeshQueue.length > 0 && processed < maxPerFrame) {
      if (performance.now() - startTime > maxTimeMs) break;
      const chunk = this.chunkMeshQueue.shift();
      if (chunk && (chunk.isDirty || chunk.meshes.length === 0)) {
        this.rebuildChunkMesh(chunk);
        processed++;
      }
    }
  }

  // Load surrounding chunks around player position
  public updateLoadedChunks(playerGx: number, playerGz: number, renderDistance: number = 3) {
    const centerCx = Math.floor(playerGx / CHUNK_SIZE_X);
    const centerCz = Math.floor(playerGz / CHUNK_SIZE_Z);

    const maxDist = renderDistance + 1;
    for (const [key, chunk] of this.chunks.entries()) {
      if (Math.abs(chunk.cx - centerCx) > maxDist || Math.abs(chunk.cz - centerCz) > maxDist) {
        for (const mesh of chunk.meshes) {
          this.scene.remove(mesh);
          mesh.geometry.dispose();
        }
        chunk.meshes = [];
        this.chunks.delete(key);
      }
    }

    // Clear stale queue items
    this.chunkMeshQueue = this.chunkMeshQueue.filter(
      (c) => Math.abs(c.cx - centerCx) <= maxDist && Math.abs(c.cz - centerCz) <= maxDist
    );

    for (let dx = -renderDistance; dx <= renderDistance; dx++) {
      for (let dz = -renderDistance; dz <= renderDistance; dz++) {
        const cx = centerCx + dx;
        const cz = centerCz + dz;
        const key = this.getChunkKey(cx, cz);
        if (!this.chunks.has(key)) {
          const chunk = this.getOrCreateChunk(cx, cz, false);
          this.chunkMeshQueue.push(chunk);
        }
      }
    }
  }

  // Instant O(1) heightmap lookup for terrain surface elevation
  public getHighestSolidY(gx: number, gz: number): number {
    const cx = Math.floor(gx / CHUNK_SIZE_X);
    const cz = Math.floor(gz / CHUNK_SIZE_Z);
    const chunk = this.chunks.get(this.getChunkKey(cx, cz));
    if (chunk) {
      const lx = ((gx % CHUNK_SIZE_X) + CHUNK_SIZE_X) % CHUNK_SIZE_X;
      const lz = ((gz % CHUNK_SIZE_Z) + CHUNK_SIZE_Z) % CHUNK_SIZE_Z;
      return chunk.heightMap[lx + lz * CHUNK_SIZE_X];
    }
    return 26;
  }

  public destroy() {
    for (const chunk of this.chunks.values()) {
      for (const mesh of chunk.meshes) {
        this.scene.remove(mesh);
        mesh.geometry.dispose();
      }
    }
    this.chunks.clear();
  }

  public dispose() {
    this.destroy();
  }
}
