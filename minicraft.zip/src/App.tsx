import { useState, useEffect, useRef, useCallback } from 'react';
import { BlockType, PlayerState, RaycastHit, GameSettings, SavedWorldData, InventoryItem } from './types';
import { worldStorage } from './game/storage';
import { MovementInput } from './game/physics';
import { VoxelWorld } from './game/world';
import { soundManager } from './game/audio';
import { VoxelCanvas, VoxelCanvasHandle } from './components/VoxelCanvas';
import { Hotbar } from './components/Hotbar';
import { TouchControls } from './components/TouchControls';
import { HUDOverlay } from './components/HUDOverlay';
import { InventoryModal } from './components/InventoryModal';
import { SaveManagerModal } from './components/SaveManagerModal';
import { SettingsModal } from './components/SettingsModal';

export default function App() {
  // Current active world data
  const [currentWorld, setCurrentWorld] = useState<SavedWorldData | null>(null);
  const [isLoadingWorld, setIsLoadingWorld] = useState(true);

  // Selected hotbar index (0-8)
  const [selectedHotbarIndex, setSelectedHotbarIndex] = useState(0);

  // Player state
  const [player, setPlayer] = useState<PlayerState>({
    x: 0,
    y: 20,
    z: 0,
    pitch: 0,
    yaw: 0,
    isGrounded: false,
    isFlying: false,
    isSneaking: false,
    isSprinting: false,
    health: 20,
    maxHealth: 20,
    hunger: 20,
    maxHunger: 20,
    gameMode: 'survival',
  });

  // Targeted block
  const [targetHit, setTargetHit] = useState<RaycastHit | null>(null);

  // Settings
  const [settings, setSettings] = useState<GameSettings>({
    renderDistance: 3,
    fov: 75,
    mouseSensitivity: 0.0022,
    touchSensitivity: 0.005,
    soundVolume: 0.5,
    showCoordinates: true,
    showFps: true,
    cloudsEnabled: true,
    dayNightSpeed: 1,
  });

  // Modals state
  const [isInventoryOpen, setIsInventoryOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isSaveManagerOpen, setIsSaveManagerOpen] = useState(false);

  // Desktop pointer lock state
  const [isPointerLocked, setIsPointerLocked] = useState(false);

  // On-screen touch controls visibility (defaults to true only on mobile touch screens)
  const [isTouchControlsVisible, setIsTouchControlsVisible] = useState(() => {
    if (typeof window === 'undefined') return false;
    return window.matchMedia('(pointer: coarse)').matches;
  });

  // Action trigger (Mine / Place)
  const [actionTrigger, setActionTrigger] = useState<{ type: 'break' | 'place'; timestamp: number } | null>(null);

  // Save feedback message
  const [saveFeedback, setSaveFeedback] = useState<string | null>(null);

  // FPS counter
  const [fps, setFps] = useState(60);

  // Movement input state
  const movementInputRef = useRef<MovementInput>({
    forward: false,
    backward: false,
    left: false,
    right: false,
    jump: false,
    sneak: false,
    sprint: false,
  });

  const voxelCanvasRef = useRef<VoxelCanvasHandle>(null);
  const worldInstanceRef = useRef<VoxelWorld | null>(null);
  const playerRef = useRef(player);
  playerRef.current = player;

  const currentWorldRef = useRef(currentWorld);
  currentWorldRef.current = currentWorld;

  // Load initial world on start
  useEffect(() => {
    const initWorld = async () => {
      setIsLoadingWorld(true);
      const activeId = worldStorage.getActiveWorldId();
      let loaded: SavedWorldData | null = null;

      if (activeId) {
        loaded = await worldStorage.loadWorld(activeId);
      }

      if (!loaded) {
        const worlds = await worldStorage.listWorlds();
        if (worlds.length > 0) {
          loaded = await worldStorage.loadWorld(worlds[0].id);
        }
      }

      if (!loaded) {
        // Create initial default world
        loaded = worldStorage.createDefaultWorld('My Voxel Realm', 'default');
        await worldStorage.saveWorld(loaded);
      }

      setCurrentWorld(loaded);
      setPlayer(loaded.player);
      setIsLoadingWorld(false);
    };

    initWorld();
  }, []);

  // Save world helper
  const saveCurrentWorld = useCallback(async () => {
    const w = currentWorldRef.current;
    if (!w) return;

    const dataToSave: SavedWorldData = {
      ...w,
      player: playerRef.current,
      lastPlayedAt: Date.now(),
    };

    await worldStorage.saveWorld(dataToSave);
    setSaveFeedback('World saved!');
    setTimeout(() => setSaveFeedback(null), 2000);
  }, []);

  // Auto-save interval every 25 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      if (currentWorldRef.current && !isLoadingWorld) {
        saveCurrentWorld();
      }
    }, 25000);

    return () => clearInterval(interval);
  }, [saveCurrentWorld, isLoadingWorld]);

  // Keyboard input listeners
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Toggle inventory
      if (e.code === 'KeyE') {
        if (!isSettingsOpen && !isSaveManagerOpen) {
          setIsInventoryOpen((prev) => !prev);
          if (document.pointerLockElement) document.exitPointerLock();
        }
        return;
      }

      // Toggle pause/settings
      if (e.code === 'Escape') {
        if (isInventoryOpen) {
          setIsInventoryOpen(false);
        } else if (isSaveManagerOpen) {
          setIsSaveManagerOpen(false);
        } else {
          setIsSettingsOpen((prev) => !prev);
        }
        return;
      }

      // Hotbar selection 1-9
      if (e.code.startsWith('Digit')) {
        const num = parseInt(e.code.replace('Digit', ''), 10);
        if (num >= 1 && num <= 9) {
          setSelectedHotbarIndex(num - 1);
          soundManager.playUiClick();
          return;
        }
      }

      // Movement keys
      const m = movementInputRef.current;
      if (e.code === 'KeyW' || e.code === 'ArrowUp') m.forward = true;
      if (e.code === 'KeyS' || e.code === 'ArrowDown') m.backward = true;
      if (e.code === 'KeyA' || e.code === 'ArrowLeft') m.left = true;
      if (e.code === 'KeyD' || e.code === 'ArrowRight') m.right = true;
      if (e.code === 'Space') m.jump = true;
      if (e.code === 'ShiftLeft' || e.code === 'ShiftRight') m.sneak = true;
      if (e.code === 'ControlLeft' || e.code === 'ControlRight') m.sprint = true;
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      const m = movementInputRef.current;
      if (e.code === 'KeyW' || e.code === 'ArrowUp') m.forward = false;
      if (e.code === 'KeyS' || e.code === 'ArrowDown') m.backward = false;
      if (e.code === 'KeyA' || e.code === 'ArrowLeft') m.left = false;
      if (e.code === 'KeyD' || e.code === 'ArrowRight') m.right = false;
      if (e.code === 'Space') m.jump = false;
      if (e.code === 'ShiftLeft' || e.code === 'ShiftRight') m.sneak = false;
      if (e.code === 'ControlLeft' || e.code === 'ControlRight') m.sprint = false;
    };

    const handleWheel = (e: WheelEvent) => {
      if (isInventoryOpen || isSettingsOpen || isSaveManagerOpen) return;
      setSelectedHotbarIndex((prev) => {
        const dir = e.deltaY > 0 ? 1 : -1;
        return (prev + dir + 9) % 9;
      });
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    window.addEventListener('wheel', handleWheel, { passive: true });

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
      window.removeEventListener('wheel', handleWheel);
    };
  }, [isInventoryOpen, isSettingsOpen, isSaveManagerOpen]);

  // Look delta handler from mobile touch drag (applied directly to canvas without React re-renders)
  const handleLookDelta = useCallback((deltaYaw: number, deltaPitch: number) => {
    voxelCanvasRef.current?.applyLookDelta(deltaYaw, deltaPitch);
  }, []);

  // Throttled player & timeOfDay sync from VoxelCanvas (10 Hz) for HUD and save state
  const handlePlayerSync = useCallback((syncedPlayer: PlayerState, timeOfDay: number) => {
    playerRef.current = syncedPlayer;
    setPlayer(syncedPlayer);
    if (currentWorldRef.current) {
      currentWorldRef.current.timeOfDay = timeOfDay;
    }
  }, []);

  // Block placement / breaking callback
  const handleBlockChange = useCallback((x: number, y: number, z: number, newType: BlockType, isBreak: boolean) => {
    setCurrentWorld((prev) => {
      if (!prev) return prev;

      const cx = Math.floor(x / 16);
      const cz = Math.floor(z / 16);
      const chunkKey = `${cx},${cz}`;
      const lx = ((x % 16) + 16) % 16;
      const lz = ((z % 16) + 16) % 16;
      const localKey = `${lx},${y},${lz}`;

      const newMod = { ...prev.modifiedBlocks };
      if (!newMod[chunkKey]) newMod[chunkKey] = {};
      newMod[chunkKey][localKey] = newType;

      // Update player stats
      const stats = {
        ...prev.stats,
        blocksBroken: prev.stats.blocksBroken + (isBreak ? 1 : 0),
        blocksPlaced: prev.stats.blocksPlaced + (isBreak ? 0 : 1),
      };

      // In survival mode, placing consumes item, breaking gathers item into inventory
      let updatedHotbar = [...prev.hotbar];
      let updatedInventory = [...prev.inventory];

      if (prev.gameMode === 'survival') {
        if (!isBreak) {
          // Placing: decrement selected item count
          const activeItem = updatedHotbar[selectedHotbarIndex];
          if (activeItem && activeItem.count > 0) {
            const nextCount = activeItem.count - 1;
            if (nextCount <= 0) {
              updatedHotbar[selectedHotbarIndex] = null;
            } else {
              updatedHotbar[selectedHotbarIndex] = { ...activeItem, count: nextCount };
            }
          }
        } else if (newType !== BlockType.AIR && newType !== BlockType.BEDROCK) {
          // Breaking: collect broken item into hotbar or inventory
          let added = false;
          // 1. Try stacking in hotbar
          for (let i = 0; i < updatedHotbar.length; i++) {
            const item = updatedHotbar[i];
            if (item && item.blockType === newType && item.count < 64) {
              updatedHotbar[i] = { ...item, count: item.count + 1 };
              added = true;
              break;
            }
          }
          // 2. Try stacking in inventory
          if (!added) {
            for (let i = 0; i < updatedInventory.length; i++) {
              const item = updatedInventory[i];
              if (item && item.blockType === newType && item.count < 64) {
                updatedInventory[i] = { ...item, count: item.count + 1 };
                added = true;
                break;
              }
            }
          }
          // 3. Try empty slot in hotbar
          if (!added) {
            const emptyHotbarIdx = updatedHotbar.findIndex((x) => x === null);
            if (emptyHotbarIdx !== -1) {
              updatedHotbar[emptyHotbarIdx] = { blockType: newType, count: 1 };
              added = true;
            }
          }
          // 4. Try empty slot in inventory
          if (!added) {
            const emptyInvIdx = updatedInventory.findIndex((x) => x === null);
            if (emptyInvIdx !== -1) {
              updatedInventory[emptyInvIdx] = { blockType: newType, count: 1 };
              added = true;
            }
          }
        }
      }

      return {
        ...prev,
        modifiedBlocks: newMod,
        stats,
        hotbar: updatedHotbar,
        inventory: updatedInventory,
      };
    });
  }, [selectedHotbarIndex]);

  // Handle auto-picking up dropped items from mobs or world
  const handleCollectItem = useCallback((blockType: BlockType, count: number = 1) => {
    setCurrentWorld((prev) => {
      if (!prev) return prev;

      let updatedHotbar = [...prev.hotbar];
      let updatedInventory = [...prev.inventory];
      let added = false;

      // 1. Try stacking in hotbar
      for (let i = 0; i < updatedHotbar.length; i++) {
        const item = updatedHotbar[i];
        if (item && item.blockType === blockType && item.count < 64) {
          const newCount = Math.min(64, item.count + count);
          const remainder = count - (newCount - item.count);
          updatedHotbar[i] = { ...item, count: newCount };
          count = remainder;
          if (count <= 0) {
            added = true;
            break;
          }
        }
      }

      // 2. Try stacking in inventory
      if (!added && count > 0) {
        for (let i = 0; i < updatedInventory.length; i++) {
          const item = updatedInventory[i];
          if (item && item.blockType === blockType && item.count < 64) {
            const newCount = Math.min(64, item.count + count);
            const remainder = count - (newCount - item.count);
            updatedInventory[i] = { ...item, count: newCount };
            count = remainder;
            if (count <= 0) {
              added = true;
              break;
            }
          }
        }
      }

      // 3. Try empty slot in hotbar
      if (!added && count > 0) {
        const emptyHotbarIdx = updatedHotbar.findIndex((x) => x === null);
        if (emptyHotbarIdx !== -1) {
          updatedHotbar[emptyHotbarIdx] = { blockType, count };
          added = true;
        }
      }

      // 4. Try empty slot in inventory
      if (!added && count > 0) {
        const emptyInvIdx = updatedInventory.findIndex((x) => x === null);
        if (emptyInvIdx !== -1) {
          updatedInventory[emptyInvIdx] = { blockType, count };
          added = true;
        }
      }

      return {
        ...prev,
        hotbar: updatedHotbar,
        inventory: updatedInventory,
      };
    });
  }, []);

  // Get currently held active block
  const activeBlock = currentWorld?.hotbar[selectedHotbarIndex]?.blockType || BlockType.AIR;

  // World manager callbacks
  const handleLoadWorld = async (worldId: string) => {
    setIsLoadingWorld(true);
    const loaded = await worldStorage.loadWorld(worldId);
    if (loaded) {
      setCurrentWorld(loaded);
      setPlayer(loaded.player);
    }
    setIsLoadingWorld(false);
  };

  const handleCreateWorld = async (
    name: string,
    type: 'default' | 'flat' | 'mountains' | 'islands',
    seed: number,
    gameMode: 'survival' | 'creative'
  ) => {
    setIsLoadingWorld(true);
    const newWorld = worldStorage.createDefaultWorld(name, type, seed);
    newWorld.gameMode = gameMode;
    newWorld.player.gameMode = gameMode;
    await worldStorage.saveWorld(newWorld);
    setCurrentWorld(newWorld);
    setPlayer(newWorld.player);
    setIsLoadingWorld(false);
  };

  const handleImportWorld = async (worldData: SavedWorldData) => {
    setIsLoadingWorld(true);
    await worldStorage.saveWorld(worldData);
    setCurrentWorld(worldData);
    setPlayer(worldData.player);
    setIsLoadingWorld(false);
  };

  // Toggle Creative Fly
  const handleToggleFly = () => {
    if (voxelCanvasRef.current) {
      const isFlying = voxelCanvasRef.current.toggleFly();
      setPlayer((prev) => ({ ...prev, isFlying }));
    }
  };

  // Switch Game Mode
  const handleToggleGameMode = () => {
    setCurrentWorld((prev) => {
      if (!prev) return prev;
      const nextMode = prev.gameMode === 'survival' ? 'creative' : 'survival';
      return {
        ...prev,
        gameMode: nextMode,
        player: { ...prev.player, gameMode: nextMode },
      };
    });
    voxelCanvasRef.current?.setPlayerState((prev) => ({
      ...prev,
      gameMode: prev.gameMode === 'survival' ? 'creative' : 'survival',
      isFlying: false,
    }));
    setPlayer((prev) => ({
      ...prev,
      gameMode: prev.gameMode === 'survival' ? 'creative' : 'survival',
      isFlying: false,
    }));
  };

  if (isLoadingWorld || !currentWorld) {
    return (
      <div className="w-full h-screen bg-neutral-950 flex flex-col items-center justify-center text-neutral-100 font-mono">
        <div className="w-12 h-12 border-4 border-amber-500 border-t-transparent rounded-full animate-spin mb-4" />
        <h1 className="text-xl font-bold tracking-wider">GENERATING VOXEL WORLD...</h1>
        <p className="text-neutral-500 text-xs mt-2">Sculpting terrain, seeding biomes & loading chunks</p>
      </div>
    );
  }

  return (
    <div className="relative w-full h-screen overflow-hidden bg-sky-400 select-none">
      {/* 3D Voxel Canvas */}
      <VoxelCanvas
        ref={voxelCanvasRef}
        worldData={{
          seed: currentWorld.seed,
          worldType: currentWorld.worldType,
          modifiedBlocks: currentWorld.modifiedBlocks,
          timeOfDay: currentWorld.timeOfDay,
        }}
        initialPlayer={player}
        movementInputRef={movementInputRef}
        activeBlock={activeBlock}
        settings={settings}
        onBlockChange={handleBlockChange}
        onTargetBlockChange={setTargetHit}
        onPointerLockChange={setIsPointerLocked}
        onPlayerSync={handlePlayerSync}
        onFpsUpdate={setFps}
        actionTrigger={actionTrigger}
        onRegisterWorld={(world) => {
          worldInstanceRef.current = world;
        }}
        onCollectItem={handleCollectItem}
      />

      {/* Minecraft HUD Overlay */}
      <HUDOverlay
        worldName={currentWorld.name}
        seed={currentWorld.seed}
        player={player}
        targetHit={targetHit}
        settings={settings}
        fps={fps}
        isPointerLocked={isPointerLocked}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenSaveManager={() => setIsSaveManagerOpen(true)}
        onQuickSave={saveCurrentWorld}
        isTouchControlsVisible={isTouchControlsVisible}
        onToggleTouchControls={() => setIsTouchControlsVisible((v) => !v)}
        saveFeedback={saveFeedback}
      />

      {/* Minecraft PE On-Screen Touch Buttons */}
      {isTouchControlsVisible && (
        <TouchControls
          onMovementChange={(updater) => {
            movementInputRef.current = updater(movementInputRef.current);
          }}
          onLookDelta={handleLookDelta}
          onStartMining={() => voxelCanvasRef.current?.startMining()}
          onStopMining={() => voxelCanvasRef.current?.stopMining()}
          onStartPlacing={() => voxelCanvasRef.current?.startPlacing()}
          onStopPlacing={() => voxelCanvasRef.current?.stopPlacing()}
          onWorldTap={(x, y) => voxelCanvasRef.current?.interactAtScreenCoord(x, y, 'auto')}
          onActionTrigger={(type) => {
            if (type === 'break') {
              voxelCanvasRef.current?.breakBlock();
            } else {
              voxelCanvasRef.current?.placeBlock();
            }
          }}
          onOpenInventory={() => {
            setIsInventoryOpen(true);
            if (document.pointerLockElement) {
              document.exitPointerLock();
            }
          }}
          isFlying={player.isFlying}
          onToggleFly={handleToggleFly}
          isSneaking={player.isSneaking}
          isSprinting={player.isSprinting}
          gameMode={currentWorld.gameMode}
          touchSensitivity={settings.touchSensitivity}
        />
      )}

      {/* 9-Slot Hotbar & Status Bars */}
      <Hotbar
        slots={currentWorld.hotbar}
        selectedIndex={selectedHotbarIndex}
        onSelectSlot={(idx) => {
          soundManager.playUiClick();
          setSelectedHotbarIndex(idx);
        }}
        health={player.health}
        maxHealth={player.maxHealth}
        hunger={player.hunger}
        maxHunger={player.maxHunger}
        gameMode={currentWorld.gameMode}
      />

      {/* Inventory & Crafting Modal */}
      <InventoryModal
        isOpen={isInventoryOpen}
        onClose={() => setIsInventoryOpen(false)}
        hotbar={currentWorld.hotbar}
        inventory={currentWorld.inventory}
        onUpdateSlots={(newHotbar, newInventory) => {
          setCurrentWorld((prev) => (prev ? { ...prev, hotbar: newHotbar, inventory: newInventory } : null));
        }}
        gameMode={currentWorld.gameMode}
        selectedHotbarIndex={selectedHotbarIndex}
        onSelectHotbarIndex={setSelectedHotbarIndex}
      />

      {/* Persistent Save Manager Modal */}
      <SaveManagerModal
        isOpen={isSaveManagerOpen}
        onClose={() => setIsSaveManagerOpen(false)}
        currentWorld={currentWorld}
        onSaveCurrentWorld={saveCurrentWorld}
        onLoadWorld={handleLoadWorld}
        onCreateWorld={handleCreateWorld}
        onImportWorld={handleImportWorld}
      />

      {/* Settings & Pause Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={settings}
        onUpdateSettings={(newSettings) => setSettings((s) => ({ ...s, ...newSettings }))}
        timeOfDay={currentWorld.timeOfDay}
        onUpdateTimeOfDay={(t) => setCurrentWorld((prev) => (prev ? { ...prev, timeOfDay: t } : null))}
        gameMode={currentWorld.gameMode}
        onToggleGameMode={handleToggleGameMode}
        onOpenSaveManager={() => {
          setIsSettingsOpen(false);
          setIsSaveManagerOpen(true);
        }}
      />
    </div>
  );
}
