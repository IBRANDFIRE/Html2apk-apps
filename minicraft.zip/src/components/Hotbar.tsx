import React from 'react';
import { InventoryItem } from '../types';
import { BLOCK_REGISTRY } from '../game/blocks';
import { Heart, Drumstick } from 'lucide-react';

interface HotbarProps {
  slots: (InventoryItem | null)[];
  selectedIndex: number;
  onSelectSlot: (index: number) => void;
  health: number;
  maxHealth: number;
  hunger: number;
  maxHunger: number;
  gameMode: 'survival' | 'creative';
}

export const Hotbar: React.FC<HotbarProps> = ({
  slots,
  selectedIndex,
  onSelectSlot,
  health,
  maxHealth,
  hunger,
  maxHunger,
  gameMode,
}) => {
  // Render health hearts (10 hearts total, 2 HP per heart)
  const renderHearts = () => {
    const totalHearts = Math.ceil(maxHealth / 2);
    const hearts = [];
    for (let i = 0; i < totalHearts; i++) {
      const heartValue = (i + 1) * 2;
      const isFull = health >= heartValue;
      const isHalf = health === heartValue - 1;

      hearts.push(
        <div key={i} className="relative w-4 h-4 flex items-center justify-center">
          <Heart
            className={`w-4 h-4 ${
              isFull
                ? 'fill-red-500 text-red-700'
                : isHalf
                ? 'fill-red-400 text-red-600 opacity-75'
                : 'text-neutral-600'
            }`}
          />
        </div>
      );
    }
    return hearts;
  };

  // Render hunger drumsticks (10 total, 2 points each)
  const renderHunger = () => {
    const totalDrumsticks = Math.ceil(maxHunger / 2);
    const drumsticks = [];
    for (let i = 0; i < totalDrumsticks; i++) {
      const value = (i + 1) * 2;
      const isFull = hunger >= value;

      drumsticks.push(
        <div key={i} className="relative w-4 h-4 flex items-center justify-center">
          <Drumstick
            className={`w-4 h-4 ${
              isFull ? 'fill-amber-600 text-amber-800' : 'text-neutral-600'
            }`}
          />
        </div>
      );
    }
    return drumsticks;
  };

  return (
    <div
      id="minecraft-hud"
      className="absolute bottom-2 left-1/2 -translate-x-1/2 z-30 flex flex-col items-center gap-1.5 pointer-events-none select-none"
    >
      {/* Status bars (Health & Hunger in Survival) */}
      {gameMode === 'survival' && (
        <div className="flex items-center justify-between w-full max-w-sm px-2 text-xs font-mono drop-shadow-md">
          <div className="flex items-center gap-0.5">{renderHearts()}</div>
          <div className="flex items-center gap-0.5">{renderHunger()}</div>
        </div>
      )}

      {/* 9 Hotbar Slots container */}
      <div
        id="hotbar-slots-container"
        className="flex items-center gap-0.5 sm:gap-1 p-1 bg-neutral-900/90 backdrop-blur-xs rounded-xl border-2 border-neutral-700 shadow-2xl pointer-events-auto max-w-[96vw] overflow-x-auto"
      >
        {slots.slice(0, 9).map((item, index) => {
          const isSelected = index === selectedIndex;
          const config = item ? BLOCK_REGISTRY[item.blockType] : null;

          return (
            <button
              key={index}
              id={`hotbar-slot-${index}`}
              onPointerDown={(e) => {
                e.stopPropagation();
                onSelectSlot(index);
              }}
              onClick={(e) => {
                e.stopPropagation();
                onSelectSlot(index);
              }}
              className={`relative w-8 h-8 sm:w-10 sm:h-10 md:w-12 md:h-12 rounded-lg flex items-center justify-center transition-all shrink-0 ${
                isSelected
                  ? 'bg-neutral-700/90 border-2 border-white ring-2 ring-yellow-400 scale-105 shadow-md'
                  : 'bg-neutral-800/80 border border-neutral-700 hover:bg-neutral-700/60'
              }`}
            >
              {/* Slot number index */}
              <span className="absolute top-0.5 left-0.5 sm:left-1 text-[8px] sm:text-[9px] font-mono text-neutral-400 font-bold">
                {index + 1}
              </span>

              {/* Item visualization */}
              {item && config ? (
                <div className="flex flex-col items-center justify-center">
                  <div
                    className="w-4 h-4 sm:w-5 sm:h-5 md:w-6 md:h-6 rounded-xs shadow-xs border border-black/30"
                    style={{ backgroundColor: config.color }}
                  />
                  {/* Stack count */}
                  {item.count > 1 && (
                    <span className="absolute bottom-0.5 right-0.5 sm:right-1 text-[9px] sm:text-[10px] md:text-xs font-mono font-bold text-white drop-shadow-[0_1.2px_1.2px_rgba(0,0,0,0.8)]">
                      {item.count}
                    </span>
                  )}
                </div>
              ) : null}
            </button>
          );
        })}
      </div>

      {/* Selected item label tooltip */}
      {slots[selectedIndex] && (
        <div className="text-white text-xs font-mono font-bold tracking-wide drop-shadow-[0_1.5px_2px_rgba(0,0,0,0.9)] bg-neutral-950/70 px-2 py-0.5 rounded">
          {BLOCK_REGISTRY[slots[selectedIndex]!.blockType]?.name}
        </div>
      )}
    </div>
  );
};
