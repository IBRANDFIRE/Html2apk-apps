import React, { useState, useEffect } from 'react';
import { SavedWorldData } from '../types';
import { worldStorage } from '../game/storage';
import { soundManager } from '../game/audio';
import { Play, Plus, Trash2, RotateCw, Globe, Sparkles, Shield, Compass } from 'lucide-react';

interface MainMenuProps {
  onStartGame: (world: SavedWorldData) => void;
}

export const MainMenu: React.FC<MainMenuProps> = ({ onStartGame }) => {
  const [tab, setTab] = useState<'main' | 'new' | 'load'>('main');
  const [savedWorlds, setSavedWorlds] = useState<{ id: string; name: string; lastPlayedAt: number; seed: number; gameMode: string }[]>([]);

  // New world form state
  const [worldName, setWorldName] = useState('New Voxel World');
  const [seedInput, setSeedInput] = useState('');
  const [worldType, setWorldType] = useState<'default' | 'flat' | 'mountains' | 'amplified' | 'desert' | 'islands' | 'cherry' | 'snowy' | 'ocean' | 'badlands' | 'swamp'>('default');
  const [gameMode, setGameMode] = useState<'survival' | 'creative'>('survival');
  const [isLoading, setIsLoading] = useState(false);

  // Load saved worlds list
  const refreshWorldsList = async () => {
    try {
      const list = await worldStorage.listWorlds();
      setSavedWorlds(list);
    } catch (e) {
      console.error('Failed to load worlds list', e);
    }
  };

  useEffect(() => {
    refreshWorldsList();
  }, []);

  const handleQuickPlay = async () => {
    soundManager.playUiClick();
    setIsLoading(true);
    const activeId = worldStorage.getActiveWorldId();
    let loaded: SavedWorldData | null = null;
    if (activeId) {
      loaded = await worldStorage.loadWorld(activeId);
    }
    if (!loaded && savedWorlds.length > 0) {
      loaded = await worldStorage.loadWorld(savedWorlds[0].id);
    }
    if (!loaded) {
      loaded = worldStorage.createDefaultWorld('My Voxel Realm', 'default');
      await worldStorage.saveWorld(loaded);
    }
    setIsLoading(false);
    onStartGame(loaded);
  };

  const handleCreateNewWorld = async (e: React.FormEvent) => {
    e.preventDefault();
    soundManager.playUiClick();
    setIsLoading(true);

    let parsedSeed: number;
    if (!seedInput.trim()) {
      parsedSeed = Math.floor(Math.random() * 900000) + 100000;
    } else {
      const num = parseInt(seedInput.trim(), 10);
      if (isNaN(num)) {
        // String hash seed
        let hash = 0;
        for (let i = 0; i < seedInput.length; i++) {
          hash = (hash << 5) - hash + seedInput.charCodeAt(i);
          hash |= 0;
        }
        parsedSeed = Math.abs(hash) || 12345;
      } else {
        parsedSeed = Math.abs(num) || 12345;
      }
    }

    const newWorld = worldStorage.createDefaultWorld(
      worldName.trim() || 'Voxel World',
      worldType,
      parsedSeed
    );
    newWorld.gameMode = gameMode;
    newWorld.player.gameMode = gameMode;

    await worldStorage.saveWorld(newWorld);
    setIsLoading(false);
    onStartGame(newWorld);
  };

  const handleLoadSpecificWorld = async (id: string) => {
    soundManager.playUiClick();
    setIsLoading(true);
    const loaded = await worldStorage.loadWorld(id);
    setIsLoading(false);
    if (loaded) {
      onStartGame(loaded);
    }
  };

  const handleDeleteWorld = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    soundManager.playUiClick();
    if (window.confirm('Are you sure you want to delete this world?')) {
      await worldStorage.deleteWorld(id);
      await refreshWorldsList();
    }
  };

  const handleRandomSeed = () => {
    soundManager.playUiClick();
    setSeedInput(String(Math.floor(Math.random() * 900000) + 100000));
  };

  return (
    <div className="relative w-full h-screen overflow-hidden bg-neutral-950 flex items-center justify-center select-none font-sans text-white">
      {/* Dynamic Animated Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-sky-950 via-slate-900 to-stone-950 opacity-95" />
      <div 
        className="absolute inset-0 opacity-20"
        style={{
          backgroundImage: `radial-gradient(#38bdf8 1px, transparent 1px), radial-gradient(#fbbf24 1px, transparent 1px)`,
          backgroundSize: '40px 40px',
          backgroundPosition: '0 0, 20px 20px',
        }}
      />

      {/* Main Container */}
      <div className="relative z-10 w-full max-w-lg p-6 flex flex-col items-center">
        {/* Game Title */}
        <div className="flex flex-col items-center mb-8 text-center">
          <div className="flex items-center gap-2 mb-1">
            <span className="text-4xl sm:text-5xl font-extrabold tracking-widest text-transparent bg-clip-text bg-gradient-to-b from-amber-300 via-amber-400 to-amber-600 drop-shadow-[0_4px_10px_rgba(245,158,11,0.5)]">
              VOXELCRAFT
            </span>
          </div>
          <span className="text-xs sm:text-sm font-mono tracking-widest text-sky-400 uppercase font-semibold">
            Light Engine &bull; Infinite World &bull; Sandbox
          </span>
        </div>

        {/* Navigation / Screen Switcher */}
        {tab === 'main' && (
          <div className="w-full flex flex-col gap-3.5 animate-fadeIn">
            <button
              onClick={handleQuickPlay}
              disabled={isLoading}
              className="w-full py-4 px-6 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-lg rounded-xl shadow-lg border border-emerald-400/40 flex items-center justify-center gap-3 active:scale-98 transition-all"
            >
              <Play className="w-6 h-6 fill-current" />
              <span>{isLoading ? 'LOADING WORLD...' : 'PLAY GAME'}</span>
            </button>

            <button
              onClick={() => {
                soundManager.playUiClick();
                setTab('new');
              }}
              className="w-full py-3.5 px-6 bg-neutral-800/90 hover:bg-neutral-700 text-white font-semibold rounded-xl border border-neutral-600 shadow-md flex items-center justify-center gap-3 active:scale-98 transition-all"
            >
              <Plus className="w-5 h-5 text-amber-400" />
              <span>CREATE NEW WORLD</span>
            </button>

            <button
              onClick={() => {
                soundManager.playUiClick();
                refreshWorldsList();
                setTab('load');
              }}
              className="w-full py-3.5 px-6 bg-neutral-800/90 hover:bg-neutral-700 text-white font-semibold rounded-xl border border-neutral-600 shadow-md flex items-center justify-center gap-3 active:scale-98 transition-all"
            >
              <Globe className="w-5 h-5 text-sky-400" />
              <span>SAVED WORLDS ({savedWorlds.length})</span>
            </button>
          </div>
        )}

        {/* Create New World Form */}
        {tab === 'new' && (
          <form onSubmit={handleCreateNewWorld} className="w-full bg-neutral-900/90 border border-neutral-700/80 p-5 rounded-2xl shadow-2xl backdrop-blur-md animate-fadeIn flex flex-col gap-4">
            <h2 className="text-xl font-bold text-amber-400 flex items-center gap-2">
              <Sparkles className="w-5 h-5" />
              <span>Create New World</span>
            </h2>

            {/* World Name */}
            <div>
              <label className="block text-xs font-mono text-neutral-400 mb-1">WORLD NAME</label>
              <input
                type="text"
                value={worldName}
                onChange={(e) => setWorldName(e.target.value)}
                required
                className="w-full px-3 py-2 bg-neutral-950 border border-neutral-700 rounded-lg text-white text-sm focus:outline-none focus:border-amber-400"
                placeholder="My Adventure"
              />
            </div>

            {/* Seed Input */}
            <div>
              <div className="flex justify-between items-center mb-1">
                <label className="text-xs font-mono text-neutral-400">WORLD SEED</label>
                <button
                  type="button"
                  onClick={handleRandomSeed}
                  className="text-xs text-amber-400 hover:text-amber-300 flex items-center gap-1 font-mono"
                >
                  <RotateCw className="w-3 h-3" /> Random
                </button>
              </div>
              <input
                type="text"
                value={seedInput}
                onChange={(e) => setSeedInput(e.target.value)}
                placeholder="Leave blank for random seed"
                className="w-full px-3 py-2 bg-neutral-950 border border-neutral-700 rounded-lg text-white text-sm font-mono focus:outline-none focus:border-amber-400"
              />
            </div>

            {/* World Type */}
            <div>
              <label className="block text-xs font-mono text-neutral-400 mb-1">GENERATOR BIOME</label>
              <div className="grid grid-cols-3 sm:grid-cols-4 gap-1.5 max-h-36 overflow-y-auto pr-1">
                {[
                  { id: 'default', label: 'Default' },
                  { id: 'cherry', label: '🌸 Cherry' },
                  { id: 'snowy', label: '❄️ Snowy' },
                  { id: 'ocean', label: '🌊 Ocean' },
                  { id: 'badlands', label: '🏜️ Badlands' },
                  { id: 'swamp', label: '🌿 Swamp' },
                  { id: 'mountains', label: '⛰️ Mountains' },
                  { id: 'amplified', label: '⚡ Amplified' },
                  { id: 'desert', label: '🌵 Desert' },
                  { id: 'islands', label: '🏝️ Islands' },
                  { id: 'plains', label: '🌾 Plains' },
                  { id: 'flat', label: '🟩 Flat' },
                ].map((type) => (
                  <button
                    key={type.id}
                    type="button"
                    onClick={() => {
                      soundManager.playUiClick();
                      setWorldType(type.id as any);
                    }}
                    className={`py-1.5 px-1.5 text-xs font-semibold rounded-lg border transition-all truncate ${
                      worldType === type.id
                        ? 'bg-amber-500 text-black border-amber-300 shadow-md font-bold'
                        : 'bg-neutral-950 border-neutral-800 text-neutral-300 hover:bg-neutral-800'
                    }`}
                  >
                    {type.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Game Mode */}
            <div>
              <label className="block text-xs font-mono text-neutral-400 mb-1">GAME MODE</label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => {
                    soundManager.playUiClick();
                    setGameMode('survival');
                  }}
                  className={`py-2.5 px-3 rounded-lg border text-xs font-bold flex items-center justify-center gap-2 transition-all ${
                    gameMode === 'survival'
                      ? 'bg-emerald-600 border-emerald-400 text-white'
                      : 'bg-neutral-950 border-neutral-800 text-neutral-400'
                  }`}
                >
                  <Shield className="w-4 h-4 text-emerald-300" />
                  Survival
                </button>
                <button
                  type="button"
                  onClick={() => {
                    soundManager.playUiClick();
                    setGameMode('creative');
                  }}
                  className={`py-2.5 px-3 rounded-lg border text-xs font-bold flex items-center justify-center gap-2 transition-all ${
                    gameMode === 'creative'
                      ? 'bg-sky-600 border-sky-400 text-white'
                      : 'bg-neutral-950 border-neutral-800 text-neutral-400'
                  }`}
                >
                  <Compass className="w-4 h-4 text-sky-300" />
                  Creative
                </button>
              </div>
            </div>

            {/* Buttons */}
            <div className="flex items-center gap-2 mt-2">
              <button
                type="button"
                onClick={() => {
                  soundManager.playUiClick();
                  setTab('main');
                }}
                className="w-1/3 py-2.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 font-semibold rounded-xl text-sm"
              >
                Back
              </button>
              <button
                type="submit"
                disabled={isLoading}
                className="w-2/3 py-2.5 bg-amber-500 hover:bg-amber-400 text-black font-bold rounded-xl text-sm shadow-lg flex items-center justify-center gap-2"
              >
                <Plus className="w-4 h-4" />
                <span>{isLoading ? 'Creating...' : 'Create World'}</span>
              </button>
            </div>
          </form>
        )}

        {/* Load Saved Worlds */}
        {tab === 'load' && (
          <div className="w-full bg-neutral-900/90 border border-neutral-700/80 p-5 rounded-2xl shadow-2xl backdrop-blur-md animate-fadeIn flex flex-col gap-3">
            <h2 className="text-xl font-bold text-sky-400 flex items-center justify-between">
              <span className="flex items-center gap-2">
                <Globe className="w-5 h-5" />
                <span>Select World</span>
              </span>
              <button
                onClick={() => {
                  soundManager.playUiClick();
                  setTab('new');
                }}
                className="text-xs bg-amber-500/20 text-amber-300 border border-amber-500/40 px-2 py-1 rounded-lg hover:bg-amber-500/30 flex items-center gap-1 font-mono"
              >
                <Plus className="w-3 h-3" /> New
              </button>
            </h2>

            <div className="max-h-64 overflow-y-auto flex flex-col gap-2 pr-1 custom-scrollbar">
              {savedWorlds.length === 0 ? (
                <div className="py-8 text-center text-neutral-400 text-xs font-mono">
                  No saved worlds found. Create a new one!
                </div>
              ) : (
                savedWorlds.map((w) => (
                  <div
                    key={w.id}
                    onClick={() => handleLoadSpecificWorld(w.id)}
                    className="p-3 bg-neutral-950/80 hover:bg-neutral-800/90 border border-neutral-800 hover:border-sky-500/60 rounded-xl cursor-pointer transition-all flex items-center justify-between group"
                  >
                    <div>
                      <div className="font-bold text-sm text-white group-hover:text-sky-300">
                        {w.name}
                      </div>
                      <div className="text-[11px] font-mono text-neutral-400 flex items-center gap-2 mt-0.5">
                        <span className="text-amber-400 capitalize">{w.gameMode || 'survival'}</span>
                        <span>&bull;</span>
                        <span>Seed: {w.seed}</span>
                        <span>&bull;</span>
                        <span>{new Date(w.lastPlayedAt).toLocaleDateString()}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={(e) => handleDeleteWorld(w.id, e)}
                        className="p-1.5 text-neutral-500 hover:text-rose-400 rounded-lg hover:bg-neutral-900 transition-colors"
                        title="Delete World"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleLoadSpecificWorld(w.id)}
                        className="p-2 bg-sky-600 hover:bg-sky-500 text-white rounded-lg transition-transform active:scale-95"
                        title="Play World"
                      >
                        <Play className="w-4 h-4 fill-current" />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>

            <button
              onClick={() => {
                soundManager.playUiClick();
                setTab('main');
              }}
              className="w-full mt-2 py-2.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 font-semibold rounded-xl text-sm"
            >
              Back to Main Menu
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
