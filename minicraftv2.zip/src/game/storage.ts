import { BlockType, SavedWorldData, WorldMetadata, InventoryItem } from '../types';

const DB_NAME = 'VoxelCraftDB';
const STORE_WORLDS = 'worlds';
const STORE_ACTIVE_KEY = 'activeWorldId';
const DB_VERSION = 1;

class WorldStorage {
  private dbPromise: Promise<IDBDatabase> | null = null;

  private getDB(): Promise<IDBDatabase> {
    if (this.dbPromise) return this.dbPromise;

    this.dbPromise = new Promise((resolve, reject) => {
      if (typeof window === 'undefined' || !window.indexedDB) {
        reject(new Error('IndexedDB not supported'));
        return;
      }

      const request = indexedDB.open(DB_NAME, DB_VERSION);

      request.onupgradeneeded = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;
        if (!db.objectStoreNames.contains(STORE_WORLDS)) {
          db.createObjectStore(STORE_WORLDS, { keyPath: 'id' });
        }
      };

      request.onsuccess = () => {
        resolve(request.result);
      };

      request.onerror = () => {
        reject(request.error);
      };
    });

    return this.dbPromise;
  }

  // Get all saved worlds metadata
  public async listWorlds(): Promise<WorldMetadata[]> {
    try {
      const db = await this.getDB();
      return new Promise((resolve, reject) => {
        const tx = db.transaction(STORE_WORLDS, 'readonly');
        const store = tx.objectStore(STORE_WORLDS);
        const request = store.getAll();

        request.onsuccess = () => {
          const list = (request.result as SavedWorldData[]).map((w) => {
            // Strip large modifiedBlocks for list view
            // eslint-disable-next-line @typescript-eslint/no-unused-vars
            const { modifiedBlocks, ...meta } = w;
            return meta as WorldMetadata;
          });
          list.sort((a, b) => b.lastPlayedAt - a.lastPlayedAt);
          resolve(list);
        };

        request.onerror = () => reject(request.error);
      });
    } catch {
      // Fallback to localStorage
      return this.listWorldsFallback();
    }
  }

  // Load a complete world by ID
  public async loadWorld(id: string): Promise<SavedWorldData | null> {
    try {
      const db = await this.getDB();
      return new Promise((resolve, reject) => {
        const tx = db.transaction(STORE_WORLDS, 'readonly');
        const store = tx.objectStore(STORE_WORLDS);
        const request = store.get(id);

        request.onsuccess = () => {
          if (request.result) {
            localStorage.setItem(STORE_ACTIVE_KEY, id);
            const w = request.result as SavedWorldData;
            if (
              !w.player ||
              !Number.isFinite(w.player.x) ||
              !Number.isFinite(w.player.y) ||
              !Number.isFinite(w.player.z)
            ) {
              w.player = this.createDefaultWorld().player;
            }
            if (!Number.isFinite(w.player.yaw)) w.player.yaw = 0;
            if (!Number.isFinite(w.player.pitch)) w.player.pitch = 0;
            if (!Number.isFinite(w.timeOfDay)) w.timeOfDay = 6000;
            resolve(w);
          } else {
            resolve(this.loadWorldFallback(id));
          }
        };

        request.onerror = () => reject(request.error);
      });
    } catch {
      return this.loadWorldFallback(id);
    }
  }

  // Save or update a world
  public async saveWorld(world: SavedWorldData): Promise<void> {
    try {
      world.lastPlayedAt = Date.now();
      const db = await this.getDB();
      return new Promise((resolve, reject) => {
        const tx = db.transaction(STORE_WORLDS, 'readwrite');
        const store = tx.objectStore(STORE_WORLDS);
        const request = store.put(world);

        request.onsuccess = () => {
          localStorage.setItem(STORE_ACTIVE_KEY, world.id);
          resolve();
        };

        request.onerror = () => reject(request.error);
      });
    } catch {
      this.saveWorldFallback(world);
    }
  }

  // Delete a world
  public async deleteWorld(id: string): Promise<void> {
    try {
      const db = await this.getDB();
      return new Promise((resolve, reject) => {
        const tx = db.transaction(STORE_WORLDS, 'readwrite');
        const store = tx.objectStore(STORE_WORLDS);
        const request = store.delete(id);

        request.onsuccess = () => {
          if (localStorage.getItem(STORE_ACTIVE_KEY) === id) {
            localStorage.removeItem(STORE_ACTIVE_KEY);
          }
          resolve();
        };

        request.onerror = () => reject(request.error);
      });
    } catch {
      this.deleteWorldFallback(id);
    }
  }

  public getActiveWorldId(): string | null {
    return localStorage.getItem(STORE_ACTIVE_KEY);
  }

  public setActiveWorldId(id: string) {
    localStorage.setItem(STORE_ACTIVE_KEY, id);
  }

  // Create a default initial world
  public createDefaultWorld(name: string = 'New World', worldType: 'default' | 'flat' | 'plains' | 'mountains' | 'amplified' | 'desert' | 'islands' = 'default', seed?: number): SavedWorldData {
    const id = 'world_' + Date.now() + '_' + Math.floor(Math.random() * 1000);
    const actualSeed = seed !== undefined ? seed : Math.floor(Math.random() * 1000000);

    const defaultHotbar: (InventoryItem | null)[] = [
      { blockType: BlockType.GRASS, count: 64 },
      { blockType: BlockType.DIRT, count: 64 },
      { blockType: BlockType.STONE, count: 64 },
      { blockType: BlockType.COBBLESTONE, count: 64 },
      { blockType: BlockType.OAK_LOG, count: 64 },
      { blockType: BlockType.OAK_PLANKS, count: 64 },
      { blockType: BlockType.GLASS, count: 64 },
      { blockType: BlockType.CRAFTING_TABLE, count: 1 },
      { blockType: BlockType.TNT, count: 16 },
    ];

    const defaultInventory: (InventoryItem | null)[] = new Array(27).fill(null);
    defaultInventory[0] = { blockType: BlockType.SAND, count: 64 };
    defaultInventory[1] = { blockType: BlockType.BRICK, count: 64 };
    defaultInventory[2] = { blockType: BlockType.GLOWSTONE, count: 32 };
    defaultInventory[3] = { blockType: BlockType.DIAMOND_ORE, count: 16 };

    return {
      id,
      name,
      seed: actualSeed,
      createdAt: Date.now(),
      lastPlayedAt: Date.now(),
      gameMode: 'survival',
      worldType,
      timeOfDay: 6000, // Noon
      player: {
        x: 0,
        y: 22,
        z: 0,
        pitch: 0,
        yaw: 0,
        isGrounded: false,
        isFlying: false,
        isSneaking: false,
        isSprinting: false,
        health: 20,
        maxHealth: 20,
        hunger: 20,
        maxHunger: 20,
        gameMode: 'survival',
      },
      hotbar: defaultHotbar,
      inventory: defaultInventory,
      stats: {
        blocksPlaced: 0,
        blocksBroken: 0,
        timePlayedMinutes: 0,
      },
      modifiedBlocks: {},
    };
  }

  // Export world to downloadable JSON string
  public exportWorldJSON(world: SavedWorldData): string {
    return JSON.stringify(world, null, 2);
  }

  // Import world from JSON string
  public importWorldJSON(jsonStr: string): SavedWorldData {
    const data = JSON.parse(jsonStr) as SavedWorldData;
    if (!data.id || !data.name || data.seed === undefined) {
      throw new Error('Invalid VoxelCraft world file format.');
    }
    // Give imported world unique id to prevent collision
    data.id = 'world_imported_' + Date.now();
    data.name = `${data.name} (Imported)`;
    data.lastPlayedAt = Date.now();
    return data;
  }

  // Fallbacks for environments where IndexedDB might be blocked
  private listWorldsFallback(): WorldMetadata[] {
    const listJson = localStorage.getItem('vc_worlds_meta');
    if (!listJson) return [];
    try {
      return JSON.parse(listJson);
    } catch {
      return [];
    }
  }

  private loadWorldFallback(id: string): SavedWorldData | null {
    const worldJson = localStorage.getItem(`vc_world_${id}`);
    if (!worldJson) return null;
    try {
      const data = JSON.parse(worldJson) as SavedWorldData;
      if (
        !data.player ||
        !Number.isFinite(data.player.x) ||
        !Number.isFinite(data.player.y) ||
        !Number.isFinite(data.player.z)
      ) {
        data.player = this.createDefaultWorld().player;
      }
      if (!Number.isFinite(data.player.yaw)) data.player.yaw = 0;
      if (!Number.isFinite(data.player.pitch)) data.player.pitch = 0;
      if (!Number.isFinite(data.timeOfDay)) data.timeOfDay = 6000;
      return data;
    } catch {
      return null;
    }
  }

  private saveWorldFallback(world: SavedWorldData) {
    try {
      localStorage.setItem(`vc_world_${world.id}`, JSON.stringify(world));
      const metaList = this.listWorldsFallback().filter((w) => w.id !== world.id);
      // eslint-disable-next-line @typescript-eslint/no-unused-vars
      const { modifiedBlocks, ...meta } = world;
      metaList.unshift(meta);
      localStorage.setItem('vc_worlds_meta', JSON.stringify(metaList));
    } catch {
      // LocalStorage quota might be exceeded for very large worlds
    }
  }

  private deleteWorldFallback(id: string) {
    localStorage.removeItem(`vc_world_${id}`);
    const metaList = this.listWorldsFallback().filter((w) => w.id !== id);
    localStorage.setItem('vc_worlds_meta', JSON.stringify(metaList));
  }
}

export const worldStorage = new WorldStorage();
