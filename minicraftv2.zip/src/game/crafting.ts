import { BlockType } from '../types';

export interface CraftingRecipe {
  id: string;
  name: string;
  gridSize: 2 | 3;
  // Matrix row by row, null = empty
  pattern: (BlockType | null)[];
  result: {
    blockType: BlockType;
    count: number;
  };
}

export const CRAFTING_RECIPES: CraftingRecipe[] = [
  {
    id: 'planks_from_oak_log',
    name: 'Oak Planks',
    gridSize: 2,
    pattern: [BlockType.OAK_LOG, null, null, null],
    result: { blockType: BlockType.OAK_PLANKS, count: 4 },
  },
  {
    id: 'planks_from_birch_log',
    name: 'Birch Planks',
    gridSize: 2,
    pattern: [BlockType.BIRCH_LOG, null, null, null],
    result: { blockType: BlockType.BIRCH_PLANKS, count: 4 },
  },
  {
    id: 'planks_from_cherry_log',
    name: 'Cherry Planks',
    gridSize: 2,
    pattern: [BlockType.CHERRY_LOG, null, null, null],
    result: { blockType: BlockType.CHERRY_PLANKS, count: 4 },
  },
  {
    id: 'planks_from_dark_oak_log',
    name: 'Dark Oak Planks',
    gridSize: 2,
    pattern: [BlockType.DARK_OAK_LOG, null, null, null],
    result: { blockType: BlockType.DARK_OAK_PLANKS, count: 4 },
  },
  {
    id: 'crafting_table',
    name: 'Crafting Table',
    gridSize: 2,
    pattern: [
      BlockType.OAK_PLANKS, BlockType.OAK_PLANKS,
      BlockType.OAK_PLANKS, BlockType.OAK_PLANKS,
    ],
    result: { blockType: BlockType.CRAFTING_TABLE, count: 1 },
  },
  {
    id: 'stone_bricks',
    name: 'Stone Bricks',
    gridSize: 2,
    pattern: [
      BlockType.STONE, BlockType.STONE,
      BlockType.STONE, BlockType.STONE,
    ],
    result: { blockType: BlockType.STONE_BRICKS, count: 4 },
  },
  {
    id: 'sandstone',
    name: 'Sandstone',
    gridSize: 2,
    pattern: [
      BlockType.SAND, BlockType.SAND,
      BlockType.SAND, BlockType.SAND,
    ],
    result: { blockType: BlockType.SANDSTONE, count: 4 },
  },
  {
    id: 'iron_block',
    name: 'Block of Iron',
    gridSize: 2,
    pattern: [
      BlockType.IRON_ORE, BlockType.IRON_ORE,
      BlockType.IRON_ORE, BlockType.IRON_ORE,
    ],
    result: { blockType: BlockType.IRON_BLOCK, count: 1 },
  },
  {
    id: 'gold_block',
    name: 'Block of Gold',
    gridSize: 2,
    pattern: [
      BlockType.GOLD_ORE, BlockType.GOLD_ORE,
      BlockType.GOLD_ORE, BlockType.GOLD_ORE,
    ],
    result: { blockType: BlockType.GOLD_BLOCK, count: 1 },
  },
  {
    id: 'diamond_block',
    name: 'Block of Diamond',
    gridSize: 2,
    pattern: [
      BlockType.DIAMOND_ORE, BlockType.DIAMOND_ORE,
      BlockType.DIAMOND_ORE, BlockType.DIAMOND_ORE,
    ],
    result: { blockType: BlockType.DIAMOND_BLOCK, count: 1 },
  },
  {
    id: 'emerald_block',
    name: 'Block of Emerald',
    gridSize: 2,
    pattern: [
      BlockType.EMERALD_ORE, BlockType.EMERALD_ORE,
      BlockType.EMERALD_ORE, BlockType.EMERALD_ORE,
    ],
    result: { blockType: BlockType.EMERALD_BLOCK, count: 1 },
  },
  {
    id: 'bricks',
    name: 'Bricks',
    gridSize: 2,
    pattern: [
      BlockType.COBBLESTONE, BlockType.COBBLESTONE,
      BlockType.COBBLESTONE, BlockType.COBBLESTONE,
    ],
    result: { blockType: BlockType.BRICK, count: 4 },
  },
  {
    id: 'packed_ice',
    name: 'Packed Ice',
    gridSize: 2,
    pattern: [
      BlockType.ICE, BlockType.ICE,
      BlockType.ICE, BlockType.ICE,
    ],
    result: { blockType: BlockType.PACKED_ICE, count: 1 },
  },
  {
    id: 'bookshelf',
    name: 'Bookshelf',
    gridSize: 3,
    pattern: [
      BlockType.OAK_PLANKS, BlockType.OAK_PLANKS, BlockType.OAK_PLANKS,
      BlockType.GLASS, BlockType.GLASS, BlockType.GLASS,
      BlockType.OAK_PLANKS, BlockType.OAK_PLANKS, BlockType.OAK_PLANKS,
    ],
    result: { blockType: BlockType.BOOKSHELF, count: 1 },
  },
  {
    id: 'tnt',
    name: 'TNT',
    gridSize: 3,
    pattern: [
      BlockType.SAND, BlockType.COAL_ORE, BlockType.SAND,
      BlockType.COAL_ORE, BlockType.SAND, BlockType.COAL_ORE,
      BlockType.SAND, BlockType.COAL_ORE, BlockType.SAND,
    ],
    result: { blockType: BlockType.TNT, count: 1 },
  },
];

export function findMatchingRecipe(grid: (BlockType | null)[], size: 2 | 3): CraftingRecipe['result'] | null {
  // First check direct match
  for (const recipe of CRAFTING_RECIPES) {
    if (recipe.gridSize === size) {
      const match = recipe.pattern.every((expected, index) => {
        const actual = grid[index] || null;
        return (expected || null) === actual;
      });
      if (match) return recipe.result;
    }
  }

  // Also check single item anywhere in grid for single item recipes
  const nonNullItems = grid.filter((b) => b !== null && b !== BlockType.AIR);
  if (nonNullItems.length === 1) {
    const item = nonNullItems[0];
    if (item === BlockType.OAK_LOG) return { blockType: BlockType.OAK_PLANKS, count: 4 };
    if (item === BlockType.BIRCH_LOG) return { blockType: BlockType.BIRCH_PLANKS, count: 4 };
    if (item === BlockType.CHERRY_LOG) return { blockType: BlockType.CHERRY_PLANKS, count: 4 };
    if (item === BlockType.DARK_OAK_LOG) return { blockType: BlockType.DARK_OAK_PLANKS, count: 4 };
  }

  return null;
}
