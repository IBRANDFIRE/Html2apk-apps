import React, { useRef, useState, useEffect, useCallback } from 'react';
import {
  ChevronUp,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Circle,
  Hammer,
  Box,
  Feather,
  Shield,
  Package,
  ArrowUp,
  ArrowDown,
} from 'lucide-react';
import { MovementInput } from '../game/physics';

interface TouchControlsProps {
  onMovementChange: (updater: (prev: MovementInput) => MovementInput) => void;
  onLookDelta: (deltaYaw: number, deltaPitch: number) => void;
  onStartMining: () => void;
  onStopMining: () => void;
  onStartPlacing: () => void;
  onStopPlacing: () => void;
  onWorldTap: (clientX: number, clientY: number) => void;
  onActionTrigger?: (action: 'break' | 'place') => void;
  onOpenInventory: () => void;
  isFlying: boolean;
  onToggleFly: () => void;
  isSneaking: boolean;
  isSprinting: boolean;
  gameMode: 'survival' | 'creative';
  touchSensitivity?: number;
}

export const TouchControls: React.FC<TouchControlsProps> = ({
  onMovementChange,
  onLookDelta,
  onStartMining,
  onStopMining,
  onStartPlacing,
  onStopPlacing,
  onWorldTap,
  onActionTrigger,
  onOpenInventory,
  isFlying,
  onToggleFly,
  isSneaking,
  isSprinting,
  gameMode,
  touchSensitivity = 0.004,
}) => {
  // Joystick / D-pad state
  const dpadContainerRef = useRef<HTMLDivElement>(null);
  const [knobPos, setKnobPos] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [activeDirections, setActiveDirections] = useState({
    forward: false,
    backward: false,
    left: false,
    right: false,
  });
  const dpadTouchIdRef = useRef<number | null>(null);

  // Look tracking state
  const lookTouchIdRef = useRef<number | null>(null);
  const lookStartPosRef = useRef<{ x: number; y: number; time: number }>({ x: 0, y: 0, time: 0 });
  const lookLastPosRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const lookHasMovedRef = useRef<boolean>(false);

  // Update movement helper
  const updateMovement = useCallback(
    (
      dirs: { forward: boolean; backward: boolean; left: boolean; right: boolean },
      analog?: { x: number; z: number }
    ) => {
      setActiveDirections(dirs);
      onMovementChange((m) => ({
        ...m,
        forward: dirs.forward,
        backward: dirs.backward,
        left: dirs.left,
        right: dirs.right,
        analogX: analog ? analog.x : 0,
        analogZ: analog ? analog.z : 0,
      }));
    },
    [onMovementChange]
  );

  // Process touch on D-pad joystick
  const handleDpadPointerMove = useCallback(
    (clientX: number, clientY: number) => {
      if (!dpadContainerRef.current) return;
      const rect = dpadContainerRef.current.getBoundingClientRect();
      const centerX = rect.left + rect.width / 2;
      const centerY = rect.top + rect.height / 2;

      const rawDx = clientX - centerX;
      const rawDy = clientY - centerY;
      const dist = Math.hypot(rawDx, rawDy);
      const maxRadius = rect.width * 0.38;

      const clampedDist = Math.min(dist, maxRadius);
      const angle = Math.atan2(rawDy, rawDx);
      const knobX = Math.cos(angle) * clampedDist;
      const knobY = Math.sin(angle) * clampedDist;

      setKnobPos({ x: knobX, y: knobY });

      // Threshold for directional activation
      const threshold = maxRadius * 0.18;
      let analogX = 0;
      let analogZ = 0;

      if (dist > threshold) {
        analogX = rawDx / maxRadius;
        analogZ = rawDy / maxRadius;
      }

      const dirs = {
        forward: rawDy < -maxRadius * 0.25,
        backward: rawDy > maxRadius * 0.25,
        left: rawDx < -maxRadius * 0.25,
        right: rawDx > maxRadius * 0.25,
      };

      updateMovement(dirs, { x: analogX, z: analogZ });
    },
    [updateMovement]
  );

  const handleDpadTouchStart = (e: React.TouchEvent) => {
    e.stopPropagation();
    if (dpadTouchIdRef.current !== null) return;
    const touch = e.changedTouches[0];
    dpadTouchIdRef.current = touch.identifier;
    handleDpadPointerMove(touch.clientX, touch.clientY);
  };

  const handleDpadTouchMove = (e: React.TouchEvent) => {
    e.stopPropagation();
    for (let i = 0; i < e.changedTouches.length; i++) {
      const touch = e.changedTouches[i];
      if (touch.identifier === dpadTouchIdRef.current) {
        handleDpadPointerMove(touch.clientX, touch.clientY);
        break;
      }
    }
  };

  const handleDpadTouchEnd = (e: React.TouchEvent) => {
    e.stopPropagation();
    for (let i = 0; i < e.changedTouches.length; i++) {
      const touch = e.changedTouches[i];
      if (touch.identifier === dpadTouchIdRef.current) {
        dpadTouchIdRef.current = null;
        setKnobPos({ x: 0, y: 0 });
        updateMovement({ forward: false, backward: false, left: false, right: false }, { x: 0, z: 0 });
        break;
      }
    }
  };

  // Full-screen Look & Tap Handlers (captures touches outside UI controls)
  const handleLookTouchStart = (e: React.TouchEvent) => {
    for (let i = 0; i < e.changedTouches.length; i++) {
      const touch = e.changedTouches[i];
      // Don't steal the D-Pad touch
      if (touch.identifier === dpadTouchIdRef.current) continue;

      if (lookTouchIdRef.current === null) {
        lookTouchIdRef.current = touch.identifier;
        lookStartPosRef.current = { x: touch.clientX, y: touch.clientY, time: Date.now() };
        lookLastPosRef.current = { x: touch.clientX, y: touch.clientY };
        lookHasMovedRef.current = false;
        break;
      }
    }
  };

  const handleLookTouchMove = (e: React.TouchEvent) => {
    if (lookTouchIdRef.current === null) return;

    for (let i = 0; i < e.changedTouches.length; i++) {
      const touch = e.changedTouches[i];
      if (touch.identifier === lookTouchIdRef.current) {
        const dx = touch.clientX - lookLastPosRef.current.x;
        const dy = touch.clientY - lookLastPosRef.current.y;
        lookLastPosRef.current = { x: touch.clientX, y: touch.clientY };

        const totalDist = Math.hypot(
          touch.clientX - lookStartPosRef.current.x,
          touch.clientY - lookStartPosRef.current.y
        );
        if (totalDist > 8) {
          lookHasMovedRef.current = true;
        }

        onLookDelta(-dx * touchSensitivity, -dy * touchSensitivity);
        break;
      }
    }
  };

  const handleLookTouchEnd = (e: React.TouchEvent) => {
    if (lookTouchIdRef.current === null) return;

    for (let i = 0; i < e.changedTouches.length; i++) {
      const touch = e.changedTouches[i];
      if (touch.identifier === lookTouchIdRef.current) {
        const duration = Date.now() - lookStartPosRef.current.time;
        const totalDist = Math.hypot(
          touch.clientX - lookStartPosRef.current.x,
          touch.clientY - lookStartPosRef.current.y
        );

        // Detect tap to place/mine (< 280ms duration & < 12px drag)
        if (!lookHasMovedRef.current && totalDist < 12 && duration < 280) {
          onWorldTap(touch.clientX, touch.clientY);
        }

        lookTouchIdRef.current = null;
        lookHasMovedRef.current = false;
        break;
      }
    }
  };

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      onMovementChange(() => ({
        forward: false,
        backward: false,
        left: false,
        right: false,
        jump: false,
        sneak: false,
        sprint: false,
      }));
    };
  }, [onMovementChange]);

  return (
    <div id="touch-controls-container" className="absolute inset-0 select-none overflow-hidden pointer-events-none z-20">
      {/* 1. Interactive Look & Tap Surface (excludes top HUD & bottom Hotbar) */}
      <div
        id="touch-look-surface"
        className="absolute inset-x-0 top-12 bottom-20 pointer-events-auto touch-none z-10"
        onTouchStart={handleLookTouchStart}
        onTouchMove={handleLookTouchMove}
        onTouchEnd={handleLookTouchEnd}
        onTouchCancel={handleLookTouchEnd}
      />

      {/* 2. Bottom-Left: Compact Translucent Virtual D-Pad */}
      <div className="absolute bottom-14 left-2 sm:left-4 pointer-events-auto z-30 flex flex-col items-center">
        {/* Outer D-Pad Base */}
        <div
          ref={dpadContainerRef}
          id="touch-dpad-pad"
          onTouchStart={handleDpadTouchStart}
          onTouchMove={handleDpadTouchMove}
          onTouchEnd={handleDpadTouchEnd}
          onTouchCancel={handleDpadTouchEnd}
          className="relative w-28 h-28 sm:w-32 sm:h-32 rounded-full bg-black/40 border border-white/15 backdrop-blur-xs shadow-lg flex items-center justify-center touch-none select-none opacity-80 hover:opacity-100 transition-opacity"
        >
          {/* Directional Indicator Arrows */}
          <div
            className={`absolute top-1 left-1/2 -translate-x-1/2 transition-colors ${
              activeDirections.forward ? 'text-amber-400 scale-110 drop-shadow-[0_0_6px_rgba(251,191,36,0.8)]' : 'text-white/30'
            }`}
          >
            <ChevronUp className="w-6 h-6" />
          </div>
          <div
            className={`absolute bottom-1 left-1/2 -translate-x-1/2 transition-colors ${
              activeDirections.backward ? 'text-amber-400 scale-110 drop-shadow-[0_0_6px_rgba(251,191,36,0.8)]' : 'text-white/30'
            }`}
          >
            <ChevronDown className="w-6 h-6" />
          </div>
          <div
            className={`absolute left-1 top-1/2 -translate-y-1/2 transition-colors ${
              activeDirections.left ? 'text-amber-400 scale-110 drop-shadow-[0_0_6px_rgba(251,191,36,0.8)]' : 'text-white/30'
            }`}
          >
            <ChevronLeft className="w-6 h-6" />
          </div>
          <div
            className={`absolute right-1 top-1/2 -translate-y-1/2 transition-colors ${
              activeDirections.right ? 'text-amber-400 scale-110 drop-shadow-[0_0_6px_rgba(251,191,36,0.8)]' : 'text-white/30'
            }`}
          >
            <ChevronRight className="w-6 h-6" />
          </div>

          {/* Analog Thumb Knob Indicator */}
          <div
            id="dpad-thumb-knob"
            style={{
              transform: `translate(${knobPos.x}px, ${knobPos.y}px)`,
              transition: knobPos.x === 0 && knobPos.y === 0 ? 'transform 0.15s ease-out' : 'none',
            }}
            className="w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-neutral-800/80 border border-white/30 shadow-md flex items-center justify-center pointer-events-none"
          >
            <div className="w-3 h-3 rounded-full bg-white/50" />
          </div>
        </div>

        {/* Sneak / Crouch Toggle Button */}
        <button
          id="btn-touch-sneak"
          onClick={() => onMovementChange((m) => ({ ...m, sneak: !m.sneak }))}
          className={`mt-1.5 px-2 py-0.5 rounded-md text-[10px] font-mono font-bold border transition-all shadow-xs active:scale-95 flex items-center gap-1 opacity-80 hover:opacity-100 ${
            isSneaking
              ? 'bg-amber-500/90 border-amber-300 text-black shadow-amber-500/30'
              : 'bg-black/50 border-white/20 text-neutral-300'
          }`}
          title="Toggle Sneak / Crouch"
        >
          <Circle className="w-2.5 h-2.5 fill-current" />
          <span>SNEAK</span>
        </button>
      </div>

      {/* 4. Bottom-Right: Compact Action Cluster */}
      <div className="absolute bottom-14 right-2 sm:right-4 pointer-events-auto z-30 flex flex-col items-end gap-1.5 opacity-85 hover:opacity-100 transition-opacity">
        {/* Auxiliary Controls (Sprint & Dedicated Fly Button) */}
        <div className="flex items-center gap-1.5">
          {/* Dedicated Fly Button */}
          <button
            id="btn-touch-fly"
            onClick={onToggleFly}
            className={`w-9 h-9 rounded-xl flex items-center justify-center border shadow-md transition-all active:scale-95 ${
              isFlying
                ? 'bg-sky-500 border-sky-300 text-white shadow-sky-500/50 animate-pulse'
                : 'bg-black/60 border-white/20 text-neutral-300 hover:text-white'
            }`}
            title="Toggle Flying Mode"
          >
            <Feather className="w-4 h-4 text-sky-300" />
          </button>

          {/* Sprint Toggle */}
          <button
            id="btn-touch-sprint"
            onClick={() => onMovementChange((m) => ({ ...m, sprint: !m.sprint }))}
            className={`w-9 h-9 rounded-xl flex items-center justify-center border shadow-md transition-all active:scale-95 ${
              isSprinting
                ? 'bg-amber-600/90 border-amber-300 text-white shadow-amber-500/30'
                : 'bg-black/50 border-white/20 text-neutral-300'
            }`}
            title="Toggle Sprint"
          >
            <Shield className="w-4 h-4 text-amber-300" />
          </button>
        </div>

        {/* Flying Ascend / Descend Row (when flying) */}
        {isFlying && (
          <div className="flex items-center gap-1.5">
            {/* Fly Up */}
            <button
              id="btn-touch-fly-up"
              onPointerDown={(e) => {
                e.stopPropagation();
                onMovementChange((m) => ({ ...m, jump: true }));
              }}
              onPointerUp={(e) => {
                e.stopPropagation();
                onMovementChange((m) => ({ ...m, jump: false }));
              }}
              onPointerCancel={() => onMovementChange((m) => ({ ...m, jump: false }))}
              className="w-9 h-9 rounded-lg bg-sky-700/80 hover:bg-sky-600 border border-sky-400 text-white flex flex-col items-center justify-center shadow-md active:scale-90 text-[9px] font-bold"
              title="Fly Up"
            >
              <ArrowUp className="w-4 h-4" />
            </button>

            {/* Fly Down */}
            <button
              id="btn-touch-fly-down"
              onPointerDown={(e) => {
                e.stopPropagation();
                onMovementChange((m) => ({ ...m, sneak: true }));
              }}
              onPointerUp={(e) => {
                e.stopPropagation();
                onMovementChange((m) => ({ ...m, sneak: false }));
              }}
              onPointerCancel={() => onMovementChange((m) => ({ ...m, sneak: false }))}
              className="w-9 h-9 rounded-lg bg-sky-800/80 hover:bg-sky-700 border border-sky-400 text-white flex flex-col items-center justify-center shadow-md active:scale-90 text-[9px] font-bold"
              title="Fly Down"
            >
              <ArrowDown className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Primary Action Buttons: MINE & PLACE */}
        <div className="flex items-center gap-1.5">
          {/* Break / Mine Block Button */}
          <button
            id="btn-touch-mine"
            onPointerDown={(e) => {
              e.preventDefault();
              e.stopPropagation();
              onStartMining();
              onActionTrigger?.('break');
              if (navigator.vibrate) navigator.vibrate(15);
            }}
            onPointerUp={(e) => {
              e.preventDefault();
              e.stopPropagation();
              onStopMining();
            }}
            onPointerCancel={() => onStopMining()}
            onPointerLeave={() => onStopMining()}
            className="w-11 h-11 rounded-xl bg-rose-700/80 hover:bg-rose-600 border border-rose-400/80 text-white flex flex-col items-center justify-center shadow-lg active:scale-90 transition-transform"
            aria-label="Mine Block"
          >
            <Hammer className="w-4 h-4" />
            <span className="text-[8px] font-bold tracking-tight">MINE</span>
          </button>

          {/* Place Block Button */}
          <button
            id="btn-touch-place"
            onPointerDown={(e) => {
              e.preventDefault();
              e.stopPropagation();
              onStartPlacing();
              onActionTrigger?.('place');
              if (navigator.vibrate) navigator.vibrate(10);
            }}
            onPointerUp={(e) => {
              e.preventDefault();
              e.stopPropagation();
              onStopPlacing();
            }}
            onPointerCancel={() => onStopPlacing()}
            onPointerLeave={() => onStopPlacing()}
            className="w-11 h-11 rounded-xl bg-emerald-700/80 hover:bg-emerald-600 border border-emerald-400/80 text-white flex flex-col items-center justify-center shadow-lg active:scale-90 transition-transform"
            aria-label="Place Block"
          >
            <Box className="w-4 h-4" />
            <span className="text-[8px] font-bold tracking-tight">PLACE</span>
          </button>
        </div>

        {/* Compact Jump Button */}
        <button
          id="btn-touch-jump"
          onPointerDown={(e) => {
            e.preventDefault();
            e.stopPropagation();
            onMovementChange((m) => ({ ...m, jump: true }));
          }}
          onPointerUp={(e) => {
            e.preventDefault();
            e.stopPropagation();
            onMovementChange((m) => ({ ...m, jump: false }));
          }}
          onPointerCancel={() => onMovementChange((m) => ({ ...m, jump: false }))}
          className="w-24 h-10 rounded-xl bg-black/60 hover:bg-neutral-800/80 border border-white/20 text-white flex items-center justify-center gap-1 shadow-lg active:scale-95 transition-all"
          aria-label="Jump"
        >
          <ChevronUp className="w-5 h-5 text-white" />
          <span className="text-[10px] font-bold tracking-wide">JUMP</span>
        </button>
      </div>
    </div>
  );
};

